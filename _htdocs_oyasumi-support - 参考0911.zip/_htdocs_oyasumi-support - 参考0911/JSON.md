``` javascript

// JSON設計
const appDate = {
  'entryTopScreenMode': sleep, // sleep | report
  //  トップ画面（睡眠設定）
  'topSleepSettings': {
    state: true, // true | false
  },
  //  トップ画面（レポート）
  'topReport': {
  },
  //  エアコン設定画面
  'acSettings': {
    state: true, // true | false おやすみ自動運転
    settingMode: easy, // easy | custom　かんたん設定、こだわり設定
    coolingTemperature: '28.0', // 冷房温度
    heatingTemperature: '20.0', // 暖房温度
    

  },
  //  エアコンのこだわり画面
  'acPreference': {
  },
  //  おやすみ音楽設定画面
  'sleepMusicSettings': {
  },
  //  メニュー画面
  'menu': {
  },
}

```