const initiAppData = {
  currentPage: "mymuPlus", //
  topPageMode: "settings", // settings | report
  acSettingsPageMode: "standard", // standard | custom
  easySetup: "easy", // easy | custom

//  ↓ここから新規
  'entryTopScreenMode': 'sleep', // sleep | report
  //  トップ画面（睡眠設定）
  'topSleepSettings': {
    state: true, // true | false
    audio: 'stop', // stop | play | pause
  },
  //  トップ画面（レポート）
  'topReport': {
  },
  //  エアコン設定画面
  'acSettings': {
    state: true, // true | false おやすみ自動運転
    settingMode: 'easy', // easy | custom　かんたん設定、こだわり設定
    coolingTemperature: '28.0', // 冷房温度
    heatingTemperature: '20.0', // 暖房温度
  },
  //  エアコンのこだわり画面
  'acPreference': {
  },
  //  おやすみ音楽設定画面
  'sleepMusicSettings': {
  },
  //  メニュー画面
  'menu': {
  },
};

const headerSet = {
  // MyMU＋
  mymuPlus: {
    left: {
      type: "drawer",
    },
    title: "MyMU",
    right: {
      text: '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="9" stroke="black" stroke-width="1.5"/><circle cx="10" cy="8" r="3" fill="white"/><path fill-rule="evenodd" clip-rule="evenodd" d="M5 17C5 14.2386 7.23858 12 10 12C12.7614 12 15 14.2386 15 17V17.3846L12.5 18.4615L10 19C10 19 8.45714 18.7708 7.5 18.4615C6.54286 18.1523 5 17.3846 5 17.3846V17Z" fill="white"/></svg>',
      visible: true,
      action: "mymu",
    },
  },
  // トップ画面（睡眠設定）
  topSleepSettings: {
    left: {
      type: "backToMyMUPlusScreen",
    },
    title: "おやすみサポート",
    right: {
      text: '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="1" y="2" width="18" height="2.5" rx="1.25" fill="white"/><rect x="1" y="9" width="18" height="2.5" rx="1.25" fill="white"/><rect x="1" y="16" width="18" height="2.5" rx="1.25" fill="white"/></svg>',
      visible: true,
      action: "drawer",
    },
  },
  // トップ画面（レポート）
  topReport: {
    left: {
      type: "backToMyMUPlusScreen",
    },
    title: "おやすみサポート",
    right: {
      text: '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="9" stroke="black" stroke-width="1.5"/><circle cx="10" cy="8" r="3" fill="black"/><path fill-rule="evenodd" clip-rule="evenodd" d="M5 17C5 14.2386 7.23858 12 10 12C12.7614 12 15 14.2386 15 17V17.3846L12.5 18.4615L10 19C10 19 8.45714 18.7708 7.5 18.4615C6.54286 18.1523 5 17.3846 5 17.3846V17Z" fill="black"/></svg>',
      visible: true,
      action: "drawer",
    },
  },
  // エアコン設定画面
  acSettings: {
    left: {
      type: "backToTopSleepSettingsScreen",
    },
    title: "エアコン設定",
    right: {
      visible: false,
    },
  },
  // エアコンのこだわり設定画面
  acCustomSettings: {
    left: {
      type: "acCustomSettings",
    },
    title: "エアコンのこだわり設定",
    right: {
      text: '完了',
      visible: true,
      action: "xxxx",
    },
  },
  // おやすみ音楽設定画面
  sleepMusicSettings: {
    left: {
      type: "backToTopSleepSettingsScreen",
    },
    title: "おやすみ音楽設定",
    right: {
      text: '完了',
      visible: true,
      action: "xxxx",
    },
  },
  // かんたん設定画面
  easySetup: {
    left: {
      type: "easySetup",
    },
    title: "",
    right: {
      text: '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="9" stroke="black" stroke-width="1.5"/><circle cx="10" cy="8" r="3" fill="black"/><path fill-rule="evenodd" clip-rule="evenodd" d="M5 17C5 14.2386 7.23858 12 10 12C12.7614 12 15 14.2386 15 17V17.3846L12.5 18.4615L10 19C10 19 8.45714 18.7708 7.5 18.4615C6.54286 18.1523 5 17.3846 5 17.3846V17Z" fill="black"/></svg>',
      visible: false,
      action: "",
    },
  },

};

// セッションストレージに展開
function storeJsonData() {
  try {
    sessionStorage.setItem("appData", JSON.stringify(initiAppData));
    sessionStorage.setItem("appDataEdit", JSON.stringify(initiAppData));
    sessionStorage.setItem("headerSet", JSON.stringify(headerSet));
  } catch (error) {
    showAlert("JSONデータの保存に失敗しました。", "error");
  }
}
