/******************************************
 * テンプレートファイル読み込み
 ******************************************/
document.addEventListener("DOMContentLoaded", async () => {
  try {
    const [alert, header, footer, modal, drawer] = await Promise.all([
      fetch("../../partials/alert.txt").then((r) => r.text()),
      fetch("../../partials/header.txt").then((r) => r.text()),
      fetch("../../partials/footer.txt").then((r) => r.text()),
      fetch("../../partials/modal.txt").then((r) => r.text()),
      fetch("../../partials/drawer-menu.txt").then((r) => r.text()),
    ]);

    document.querySelector(".content-alert").innerHTML = alert;
    document.querySelector(".content-header").innerHTML = header;
    document.querySelector(".content-footer").innerHTML = footer;
    document.querySelector(".content-modal").innerHTML = modal;
    document.querySelector(".content-drawer").innerHTML = drawer;
    initUI();
  } catch (err) {
    console.error("Failed to load partials:", err);
  }
});

function initUI() {
  // モーダル
  // initModalDriveModeSelectButtons();
  initFooterButtons();
  initFooterButtonsState();
  initHeader();
  // 基本機能 画面
  // renderDriveModeSwitchBtnAndSettingPanelOperation();
}

/******************************************
 * JSON取得（ブラケット版）
 ******************************************/
const getJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }

  if (!data) return undefined;

  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }

  return current;
};

/******************************************
 * JSON更新（ブラケット版）
 ******************************************/
const setJsonValue = (propertyPath, value) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : {};
  } catch (e) {
    data = {};
  }

  // ブラケット記法をドット記法に変換
  // "buttons[0].label" → "buttons.0.label"
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let i = 0; i < props.length - 1; i++) {
    const prop = props[i];

    // 数字 → 配列アクセス
    const index = Number(prop);
    const isIndex = !isNaN(index);

    if (isIndex) {
      if (!Array.isArray(current)) {
        current = [];
      }
      if (current[index] === undefined) {
        current[index] = {};
      }
      current = current[index];
    } else {
      if (!current[prop] || typeof current[prop] !== "object") {
        current[prop] = {};
      }
      current = current[prop];
    }
  }

  // 最終プロパティ
  const lastProp = props[props.length - 1];
  const lastIndex = Number(lastProp);

  if (!isNaN(lastIndex)) {
    if (!Array.isArray(current)) current = [];
    current[lastIndex] = value;
  } else {
    current[lastProp] = value;
  }

  // 確認用ログ
  sessionStorage.setItem("appData", JSON.stringify(data));
  // console.log(data.automation.items["auto-1"].actions[0]);
};

/******************************************
 * JSON取得（ブラケット版）ヘッダー用
 ******************************************/
const getHeaderJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("headerSet");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }

  if (!data) return undefined;

  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }

  return current;
};

/******************************************
 * JSON更新（ブラケット版）ヘッダー用
 ******************************************/
const setHeaderJsonValue = (propertyPath, value) => {
  const storedJson = sessionStorage.getItem("headerSet");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : {};
  } catch (e) {
    data = {};
  }

  // ブラケット記法をドット記法に変換
  // "buttons[0].label" → "buttons.0.label"
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let i = 0; i < props.length - 1; i++) {
    const prop = props[i];

    // 数字 → 配列アクセス
    const index = Number(prop);
    const isIndex = !isNaN(index);

    if (isIndex) {
      if (!Array.isArray(current)) {
        current = [];
      }
      if (current[index] === undefined) {
        current[index] = {};
      }
      current = current[index];
    } else {
      if (!current[prop] || typeof current[prop] !== "object") {
        current[prop] = {};
      }
      current = current[prop];
    }
  }

  // 最終プロパティ
  const lastProp = props[props.length - 1];
  const lastIndex = Number(lastProp);

  if (!isNaN(lastIndex)) {
    if (!Array.isArray(current)) current = [];
    current[lastIndex] = value;
  } else {
    current[lastProp] = value;
  }

  // 確認用ログ
  sessionStorage.setItem("headerSet", JSON.stringify(data));
  // console.log(data.automation.items["new"].triggers[0].days);
};


/******************************************
 * ユーティリティ：ヘッダーのアイテムを設定する
 * 対象：各画面のヘッダー
 * アクション：ヘッダー要素の初期化
 ******************************************/
function initHeader() {
  // ==============================
  // DOM取得
  // ==============================
  const headerDom = {
    leftBtn: document.getElementById("headerLeftBtn"),
    title: document.getElementById("headerTitle"),
    rightBtn: document.getElementById("headerRightBtn"),
  };

  if (!headerDom.leftBtn || !headerDom.title || !headerDom.rightBtn) {
    console.warn("header DOM がまだ準備できていません");
    return;
  }

  // ==============================
  // headerSetBodyKeyキー取得
  // ==============================
  const currentHeaderSetKey = document.body.dataset.appHeaderSet;
  if (!currentHeaderSetKey) {
    console.warn("data-app-header-set が指定されていません");
    return;
  }

  // ==============================
  // headerSetJson 取得
  // ==============================
  const headerSetJson = getHeaderJsonValue(`${currentHeaderSetKey}`);
  if (!headerSetJson) {
    console.warn(`headerSet.${currentHeaderSetKey} が見つかりません`);
    return;
  }

  // ==============================
  // タイトル
  // ==============================
  headerDom.title.innerHTML = headerSetJson.title;

  // ==============================
  // 左ボタン
  // ==============================
  renderLeftButton(headerSetJson.left?.type, headerDom.leftBtn);
  headerDom.leftBtn.onclick = () =>
    handleHeaderLeftAction(headerSetJson.left?.type);

  // ==============================
  // 右ボタン
  // ==============================
  renderRightButton(headerSetJson.right, headerDom.rightBtn);
  headerDom.rightBtn.onclick = () =>
    handleHeaderRightAction(headerSetJson.right?.action);
}

// ==============================
// 左ボタン描画
// ==============================
// リセット
function renderLeftButton(type, btn) {
  btn.innerHTML = "";
  btn.classList.remove("d-none");
  // アイコン設定
  switch (type) {
    case "back":
      btn.innerHTML = '<i class="bi bi-chevron-left"></i>';
      break;
    case "drawer":
      btn.innerHTML = '<i class="bi bi-list"></i>';
      break;
    default:
      btn.classList.add("d-none");
  }
}

// ==============================
// 左アクション処理
// ==============================
function handleHeaderLeftAction(type) {
  switch (type) {
    case "back":
      // document.addEventListener("DOMContentLoaded", syncToggleFromStorage);
      // window.addEventListener("pageshow", syncToggleFromStorage);
      window.history.back();
      break;

    case "drawer":
      const bsOffcanvas = new bootstrap.Offcanvas("#appOffcanvas");
      bsOffcanvas.show();
      break;
  }
}

// ==============================
// 右ボタン描画
// ==============================
function renderRightButton(headerSetJsonRight, headerDomRight) {
  // 右ボタンのプロパティチェック
  if (!headerSetJsonRight || !headerSetJsonRight.visible) {
    headerDomRight.classList.add("d-none");
    headerDomRight.onclick = null;
    return;
  }

  // 表示
  headerDomRight.classList.remove("d-none");

  // text / icon / svg すべて対応
  headerDomRight.innerHTML = headerSetJsonRight.text || "";

  // クリック処理（あれば）
  headerDomRight.onclick = () => {
    handleHeaderRightAction(headerSetJsonRight.action, headerSetJsonRight);
  };
}

// ==============================
// 右アクション処理（完了/done | 設定/set | リンク/link | 編集/edit | 決定/ok）
// ==============================
function handleHeaderRightAction(action) {
  switch (action) {
    // JSON更新後、前の画面へ戻る
    case "done":
      window.history.back();
      break;

    // 電気代チェック画面へ遷移
    case "set":
      window.history.back();
      break;

    // 指定リンクへ遷移
    case "link":
      const rightBtn = document.getElementById("headerRightBtn");
      const target = getJsonValue(
        "headerSet.electricityBillCheck.right.target",
      );
      if (rightBtn) {
        rightBtn.href = target;
      }
      break;

    // 現在の画面が編集可能になるtouch-airflow-back
    case "edit":
      window.history.back();
      break;

    // タッチ気流、窓位置設定のポインターがロックされる
    case "ok":
      window.history.back();
      break;

    // アラート表示schedule-done
    case "alert":
      alert(
        "デモアプリではこのボタンは操作できません。＜ ボタンで戻ってください",
      );
      break;

    // スケジュール画面で完了
    case "schedule-done":
      setJsonValue("isAutoMationSetDone", true);
      window.location.href = "../schedule/";
      break;

    // アラート表示
    case "touch-airflow-back":
      alert(
        "風向を設定しました。やり直す場合は画像をダブルタップしてください。",
      );
      break;
  }
}

/******************************************
 * イニシャライズ：フッター
 * 対象：フッターのアイコン
 * アクション：JSON更新(currentPage)
 ******************************************/
const initFooterButtons = () => {
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      setJsonValue("currentPage", btn.dataset.appPage);
    });
  });
};

/******************************************
 * レンダリング：フッターアイコン表示更新
 * 対象：フッターのアイコン
 * アクション：アクティブページのフッターアイコンの表示更新
 ******************************************/
const initFooterButtonsState = () => {
  // フッターが存在しない画面
  const footerElement = document.getElementsByClassName("content-footer")[0];
  if (footerElement.className.includes("d-none")) {
    return;
  }
  // スタイルリセット
  const currentPage = getJsonValue("currentPage");
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.classList.remove("active");
  });
  // レンダリング
  footerButtons.forEach((btn) => {
    const page = btn.dataset.appPage;
    if (page === currentPage) {
      btn.classList.add("active");
    }
  });
};

/******************************************
 * ユーティリティ：全画面
 * 対象：トグルスイッチ（button要素内にあるスイッチ）
 * アクション：クリック時の伝播を防ぐ
 ******************************************/
document.querySelectorAll(".form-check-input").forEach((toggle) => {
  toggle.addEventListener("click", (e) => {
    e.stopPropagation();
  });
});

/******************************************
 * ユーティリティ：全画面
 * 対象：button要素、スイッチ要素
 * アクション：「デモアプリではこのボタンは操作できません。」を表示する
 ******************************************/
document.addEventListener("click", (e) => {
  const target = e.target.closest(".demo-toggle-alert");
  if (!target) return;

  // 現在の状態を保持（クリック後の状態）
  const currentChecked = target.checked;
  e.stopPropagation();

  alert("デモアプリではこのボタンは操作できません。");

  // 元の状態に戻す
  target.checked = !currentChecked;
});

/******************************************
 * アクション：オートメーションIDをJSONに保存して、編集画面へ遷移する
 ******************************************/
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".js-automation-id");
  if (!btn) return;

  const key = btn.dataset.appKey;
  let draftMode;

  if (key === "new") {
    draftMode = {
      automationId: key, // new
    };
  } else if (key.startsWith("temp-")) {
    draftMode = {
      automationId: key, // temp-1, temp-2...temp-6
    };
  } else {
    draftMode = {
      automationId: key, // auto-1, auto-2, auto-3
    };
  }

  // automationId と mode（create | template | edit） を保存
  setJsonValue("entryId", draftMode.automationId);
  window.location.href = "../edit-automation/";
});

// オートメーション編集画面のレンダリング
const renderEditAutomationScreen = () => {
  // 変数をセット（オートメーションID、初期表示トリガーイベント）
  const entryId = getJsonValue("entryId");
  const entryTrigger =  getJsonValue(`${entryId}.entryTrigger`);

  // トリガーイベントボタンのアクティブ状態を設定
  const setActiveTriggerEvent = (entryTrigger) => {
    const buttons = document.querySelectorAll(".js-trigger-event");

    buttons.forEach((btn) => {
      const key = btn.dataset.appKey;

      if (key === entryTrigger) {
        btn.classList.add("active");
        btn.setAttribute("aria-pressed", "true");
      } else {
        btn.classList.remove("active");
        btn.setAttribute("aria-pressed", "false");
      }
    });

    // JSONと同期
    // customAutomationJson.currentTrigger = entryTrigger;
  };

  // トリガーイベントセクションの表示制御
  const renderTriggerSection = (triggerKey) => {
    const sections = document.querySelectorAll(".trigger-section");

    sections.forEach((section) => {
      if (section.dataset.appKey === triggerKey) {
        section.style.display = "";
      } else {
        section.style.display = "none";
      }
    });
  };

  // オートメーション名を代入
  const renderAutomationName = (entryId) => {
    const el = document.getElementById("autoName");
    const automationName = getJsonValue(`${entryId}.name`);

    if (!el) return;
    const name = automationName?.trim();
    if (name) {
      el.textContent = name;
    } else {
      el.textContent = "オートメーション名（未設定）";
    }
  };

  // 時間を代入
  const renderScheduleStartTime = (entryId) => {
    const el = document.getElementById("autoStartTime");
    const automationTime = getJsonValue(`${entryId}.triggers.schedule.time`);

    if (!el) return;
    const time = automationTime?.trim();
    if (time) {
      el.textContent = time;
    } else {
      el.textContent = "開始時間（未設定）";
    }
  };

  // 曜日を代入
  const renderScheduleDays = (entryId) => {
    const dayButtons = document.querySelectorAll(".day-of-the-week");
    if (!dayButtons.length) return;

    // schedule.days を安全に取得
    const days = getJsonValue(`${entryId}.triggers.schedule.days`) ?? [];

    dayButtons.forEach((button) => {
      const day = button.dataset.appScheduleDay;
      const isActive = days.includes(day);

      button.classList.toggle("active", isActive);
      button.setAttribute("aria-pressed", String(isActive));
    });
  };

  // 曜日説明文を代入
  const renderScheduleDescription = (entryId) => {
    const updateScheduleDescription = (days) => {
      const allDays = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
      const dayNames = {
        sun: "日",
        mon: "月",
        tue: "火",
        wed: "水",
        thu: "木",
        fri: "金",
        sat: "土",
      };
      let description = "";
      if (days.length === 0) {
        // 何も選択されていない：一度だけ実行
        description = "一度だけ実行します";
      } else if (days.length === 7) {
        // 全て選択：毎日実行
        description = "毎日実行します";
      } else {
        // 一部選択：選択された曜日に実行
        const selectedDayNames = days
          .sort((a, b) => allDays.indexOf(a) - allDays.indexOf(b))
          .map((day) => dayNames[day])
          .join("");
        description = `毎週${selectedDayNames}曜日に実行します`;
      }
      // 説明文を表示する要素を探して更新
      const descriptionElement = document.getElementById("scheduleText");
      if (descriptionElement) {
        descriptionElement.textContent = description;
      }
    };

    const scheduleTrigger = getJsonValue(`${entryId}.triggers.schedule`);
    if (!scheduleTrigger) return;
    const days = scheduleTrigger.days ?? [];
    updateScheduleDescription(days);
  };

  // 通知するユーザーを代入
  const renderLocationUsers = (entryId) => {
    // location セクション内の checkbox を取得
    const checkboxes = document.querySelectorAll(
      '[data-app-key="location"] input[type="checkbox"]',
    );
    if (!checkboxes.length) return;

    // location trigger を取得
    const locationTrigger = getJsonValue(`${entryId}.triggers.location`);
    if (!locationTrigger) return;

    const selectedUsers = locationTrigger.users || [];

    checkboxes.forEach((checkbox) => {
      const userName = checkbox.value;

      const isChecked = selectedUsers.includes(userName);
      checkbox.checked = isChecked;
    });
  };

  // 位置条件のイベントを代入
  const renderLocationCondition = (entryId) => {
    const selectedCondition = getJsonValue(
      `${entryId}.triggers.location.event`,
    );

    function renderLocationCondition(selectedCondition) {
      // location 条件ボタンをすべて取得
      const buttons = document.querySelectorAll(".js-location-condition");

      buttons.forEach((btn) => {
        const condition = btn.dataset.appLocationCondition;

        if (condition === selectedCondition) {
          // 選択中
          btn.setAttribute("aria-pressed", "true");
          btn.classList.add("active");
        } else {
          // 非選択
          btn.setAttribute("aria-pressed", "false");
          btn.classList.remove("active");
        }
      });
    }

    const locationCondition = getJsonValue(
      `${entryId}.triggers.location.event`,
    ); // close / away

    renderLocationCondition(locationCondition);
  };

  // 機器の状態を代入
  const renderDeviceTrigger = (entryId) => {
    const deviceTrigger = getJsonValue(`${entryId}.triggers.devices`);
    const container = document.getElementById("roomTemperatureThresholdButton");
    if (!container) return;

    // 未設定なら非表示
    if (!deviceTrigger || !deviceTrigger.id) {
      container.classList.add("d-none");
      return;
    }

    // 表示
    container.classList.remove("d-none");

    const button = container.querySelector("button");
    if (!button) return;

    // JSON → HTML
    button.querySelector(".name").textContent = deviceTrigger.id || "";

    button.querySelector(".description").textContent =
      deviceTrigger.condition || "";

    button.querySelector(".temperature").textContent =
      deviceTrigger.threshold != null ? `温度 ${deviceTrigger.threshold}℃` : "";
  };

  // アクションを描画
const renderActions = (entryId) => {

  const actions = getJsonValue(`${entryId}.actions`) ?? [];

  const container = document.getElementById("actionButtonsContainer");
  const template = document.getElementById("actionTemplate");
  if (!container || !template) return;

  // 先に関数を定義
  const getDeviceName = (action) => {
    return action.deviceName ?? action.id ?? "エアコン";
  };

  const getDeviceDescription = (action) => {
    if (action.drive === "on") return "運転開始";
    if (action.drive === "off") return "運転停止";
    return "";
  };

  const setActionButtonContent = (button, action) => {
    const nameEl = button.querySelector(".name");
    const descEl = button.querySelector(".description");
    const tempEl = button.querySelector(".temperature");
    const imgEl = button.querySelector(".source");

    if (action.type === "devices") {
      nameEl.textContent = getDeviceName(action);
      descEl.textContent = getDeviceDescription(action);
      tempEl.textContent = action.temp ? `${action.temp}℃` : "";
      imgEl.src = "../assets/img/icon_AC_40pt.svg";
    }

    if (action.type === "notify") {
      nameEl.textContent = "通知";
      descEl.textContent = action.target;
      tempEl.textContent = "";
      imgEl.src = "../assets/img/icon_Notifications_40.svg";
    }
  };

  // 既存削除（テンプレート除外）
  container
    .querySelectorAll(".action-item:not(#actionTemplate)")
    .forEach((el) => el.remove());

  actions.forEach((action) => {
    const button = template.cloneNode(true);
    button.removeAttribute("id");
    button.style.display = "";

    setActionButtonContent(button, action);
    container.appendChild(button);
  });
};

  // 実行する関数
  setActiveTriggerEvent(entryTrigger);
  renderTriggerSection(entryTrigger);
  renderAutomationName(entryId);
  renderScheduleStartTime(entryId);
  renderScheduleDays(entryId);
  renderScheduleDescription(entryId);
  renderLocationUsers(entryId);
  renderLocationCondition(entryId);
  renderDeviceTrigger(entryId);
  renderActions(entryId);
  // トリガーイベントボタン クリック処理
  const initTriggerEventButtons = () => {
    const buttons = document.querySelectorAll(".js-trigger-event");
    if (!buttons.length) return;

    buttons.forEach((btn) => {
      btn.addEventListener("click", () => {
        const entryId = getJsonValue("entryId");
        const triggerKey = btn.dataset.appKey;

        // JSONを書き換える
        setJsonValue(`${entryId}.entryTrigger`, triggerKey);


        // 再描画
        renderEditAutomationScreen();
      });
    });
  };
    initTriggerEventButtons();
};

// 描画は何度でもOK
renderEditAutomationScreen();






/******************************************
 * イニシャライズ：オートメーション 画面
 * 対象：＋ボタン
 * アクション：新規オートメーション画面へ遷移する
 ******************************************/
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".js-add-automation");
  if (!btn) return;
  window.location.href = "../proposal-automation/";
});

// 機器の「状態」を追加 ⇒ trigger-event-product"
document.addEventListener("click", (e) => {
  // const btn = e.target.closest(".trigger-event-section");
  // if (!btn) return;
  // const key = btn.dataset.appKey;
  // const automationDraftMode = JSON.parse(sessionStorage.getItem("automationDraftMode") || "{}");
  // automationDraftMode.sourceButton = key;
  // sessionStorage.setItem("automationDraftMode", JSON.stringify(automationDraftMode));
  // window.location.href = "../select-device/";
});

// 機器の「操作」を追加 ⇒ 
document.addEventListener("click", (e) => {
  // const btn = e.target.closest(".js-trigger-event");
  // if (!btn) return;
  // const key = btn.dataset.appKey;
  // const automationDraftMode = JSON.parse(sessionStorage.getItem("automationDraftMode") || "{}");
  // automationDraftMode.sourceButton = key;
  // sessionStorage.setItem("automationDraftMode", JSON.stringify(automationDraftMode));
  // // window.location.href = "../select-device/";
});




























// const demoList = [
//   {
//     icon: "../assets/img/icon_AC_40pt.svg",
//     name: "寝室のエアコン",
//     description: "室温がしきい値を超えたとき",
//     temperature: "28℃"
//   },
//   {
//     icon: "../assets/img/icon_AC_40pt.svg",
//     name: "リビングのエアコン",
//     description: "室温がしきい値を下回ったとき",
//     temperature: "15℃"
//   }
// ];
// function renderButtons(list) {
//   const container = document.getElementById("actionButtonsContainer");
//   const template = document.getElementById("actionTemplate");

//   // 既存表示をクリア（テンプレート以外）
//   container.querySelectorAll(".generated").forEach(el => el.remove());

//   list.forEach(item => {
//     const clone = template.cloneNode(true);

//     clone.style.display = "";
//     clone.removeAttribute("id");
//     clone.classList.add("generated");

//     clone.querySelector(".source").src = item.icon || "";
//     clone.querySelector(".name").textContent = item.name || "";
//     clone.querySelector(".description").textContent = item.description || "";
//     clone.querySelector(".temperature").textContent = item.temperature || "";

//     container.appendChild(clone);
//   });
// }


// function applyTriggerToButton(button, data) {
//   button.querySelector(".source").src = data.icon || "";
//   button.querySelector(".name").textContent = data.title || "";
//   button.querySelector(".description").textContent =
//     (data.descParts || []).join(" ");
// }

// // 家電シェアユーザーを取得する
// function updateSelectedUsers() {
//   const checked = document.querySelectorAll('input[type="checkbox"]:checked');
//   const checkedUsers = Array.from(checked).map(cb => cb.value);
//   const targetPath = `customData.triggers.location.users`;
//   setJsonValue(targetPath, checkedUsers)
//   // customAutomationJson.actions[2].notificationSettings.notification = users;
// }

// updateSelectedUsers();

// // const btn = document.querySelector(".trigger-event-section");
// // applyTriggerToButton(btn, trigger);