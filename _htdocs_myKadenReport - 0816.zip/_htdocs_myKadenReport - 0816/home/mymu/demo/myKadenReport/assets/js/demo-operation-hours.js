// 月ごとの運転時間データを保持する配列。
// 各要素は「年」「月」「月の日数」「その月の運転時間」を表し、
// 2025年1月から2027年9月までの月別データを時系列順に並べている。
const operationData = [
    // 2025年
    { year: 2025, month: 1, days: 31, hours: 206 },
    { year: 2025, month: 2, days: 28, hours: 219 },
    { year: 2025, month: 3, days: 31, hours: 174 },
    { year: 2025, month: 4, days: 30, hours: 32 },
    { year: 2025, month: 5, days: 31, hours: 63 },
    { year: 2025, month: 6, days: 30, hours: 186 },
    { year: 2025, month: 7, days: 31, hours: 228 },
    { year: 2025, month: 8, days: 31, hours: 218 },
    { year: 2025, month: 9, days: 30, hours: 121 },
    { year: 2025, month: 10, days: 31, hours: 35 },
    { year: 2025, month: 11, days: 30, hours: 161 },
    { year: 2025, month: 12, days: 31, hours: 195 },
    // 2026年
    { year: 2026, month: 1, days: 31, hours: 206 },
    { year: 2026, month: 2, days: 28, hours: 219 },
    { year: 2026, month: 3, days: 31, hours: 174 },
    { year: 2026, month: 4, days: 30, hours: 32 },
    { year: 2026, month: 5, days: 31, hours: 63 },
    { year: 2026, month: 6, days: 30, hours: 186 },
    { year: 2026, month: 7, days: 31, hours: 228 },
    { year: 2026, month: 8, days: 31, hours: 218 },
    { year: 2026, month: 9, days: 30, hours: 121 },
    { year: 2026, month: 10, days: 31, hours: 35 },
    { year: 2026, month: 11, days: 30, hours: 161 },
    { year: 2026, month: 12, days: 31, hours: 195 },
    // 2027年
    { year: 2027, month: 1, days: 31, hours: 239 },
    { year: 2027, month: 2, days: 28, hours: 228 },
    { year: 2027, month: 3, days: 31, hours: 179 },
    { year: 2027, month: 4, days: 30, hours: 31 },
    { year: 2027, month: 5, days: 31, hours: 43 },
    { year: 2027, month: 6, days: 30, hours: 230 },
    { year: 2027, month: 7, days: 31, hours: 249 },
    { year: 2027, month: 8, days: 31, hours: 239 },
    { year: 2027, month: 9, days: 30, hours: 39 }
];

// 累計運転時間を求める関数

/**
 * 2025/1/1から指定日までの累積運転時間を取得する。
 * 指定日は含めず、その前日までの合計時間を返す。
 *
 * 例: 2025/1/15 の時点では 2025/1/1 〜 2025/1/14 までの合計
 *
 * @param {Date} targetDate
 * @returns {number}
 */
function getOperationHours(targetDate) {

    // 基準とするデータ開始日を定義。
    const baseYear = 2025;
    const baseMonth = 1;

    // Date オブジェクトから対象年月日を取り出す。
    const year = targetDate.getFullYear();
    const month = targetDate.getMonth() + 1;
    const day = targetDate.getDate();

    // 2025/1/1 を基準にして、対象月が配列の何番目に対応するかを計算する。
    // 例: 2025/3/1 -> (2025-2025)*12 + (3-1) = 2
    const monthIndex = (year - baseYear) * 12 + (month - baseMonth);

    // 対象日がデータの開始日より前の場合は計算不能。
    if (monthIndex < 0) {
        throw new Error("指定日は2025年1月1日以降を指定してください。");
    }

    // 2027/9月以降のデータがないため、範囲外を防ぐ。
    if (monthIndex > operationData.length) {
        throw new Error("指定日はoperationDataの範囲外です。");
    }

    // 累積合計を保持する変数。
    let total = 0;

    // 対象月の直前までの各月の運転時間を累積する。
    // 例: 2025/3/1 を指定した場合、1月と2月の合計が加算される。
    for (let i = 0; i < Math.min(monthIndex, operationData.length); i++) {
        total += operationData[i].hours;
    }

    // 現在の月に入った場合は、月内の経過日数に応じて日割りで加算する。
    // 「指定日は含めない」ため day - 1 を使う。
    if (monthIndex < operationData.length) {
        const current = operationData[monthIndex];
        total += current.hours * ((day - 1) / current.days);
    }

    return total;
}

/**
 * 指定期間の累積運転時間を取得する。
 * 開始日は含み、終了日は含まない区間の差分を返す。
 *
 * 例）
 * 2026/9/1 ～ 2027/9/30 の期間は
 * start = new Date(2026,8,1)
 * end   = new Date(2027,9,1)
 * のように計算する
 *
 * @param {Date} startDate
 * @param {Date} endDate
 * @returns {number}
 */
function getOperationHoursBetween(startDate, endDate) {

    // 入力値が Date オブジェクトであるかを検証し、不正な値を弾く。
    if (!(startDate instanceof Date) || isNaN(startDate)) {
        throw new Error("startDateが不正です。");
    }

    if (!(endDate instanceof Date) || isNaN(endDate)) {
        throw new Error("endDateが不正です。");
    }

    // 開始日が終了日より後ろにならないよう検証する。
    if (startDate > endDate) {
        throw new Error("開始日は終了日以前を指定してください。");
    }

    // 期間の終端までの累計から開始日の累計を引いて、区間の運転時間を算出する。
    return getOperationHours(endDate) - getOperationHours(startDate);
}

// 使用例
// const target = new Date(2027, 8, 9); // 2027/9/9（※月は0始まり）
// const start = new Date(2026, 8, 1);
// const end = new Date(2027, 9, 1);

// const hours = getOperationHoursBetween(start, end);

// 1989
// console.log(hours);    