8/23
クリック⇒ clicked の設定まで


左下　leftDown
左やや下　leftSlightlyDown
左中　leftCenter
左やや上　leftSlightlyUp
左上　leftUp
左自動　leftAuto
左スイング　leftSwing
左自動　leftAutoMark
左スイング　leftSwingMark


右下　 rightDown
右やや下　 rightSlightlyDown
右中　 rightCenter
右やや上　 rightSlightlyUp
右上　 rightUp
右自動　 rightAuto
右スイング　 rightSwing
右自動　rightAutoMark
右スイング　rightSwingMark
