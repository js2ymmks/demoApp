# 残件

# 残件（8/17）
- [x] 判定⇒ 本日を初期マーク（月）
- [ ] 判定⇒ 2025年1月1日を活性化
- [ ] 判定⇒ 開始日から本日を活性化、それ以外は非活性化
- [x] 判定⇒ 開始月から当月を活性化、それ以外は非活性化
- [x] 判定⇒ 決定ボタンの活性化と非活性化
- [ ] 調整⇒ 矢印アイコンの活性化と非活性化


## 最終チェック
### メンテナンス後の時間経過
- JSONから読み取る `operatingHoursAfterMaintenance`
- HTMLへ書き込む `updateOperatingHours()`
- JSONへ書き込む `setOperatingHours`

###  グラフ `maintenanceHoursGraph`
###  最後にメンテナンスした日 `js-last-maintenance-year` 年 `js-last-maintenance-month` 月 `js-last-maintenance-day` 日 

## 8/13にやること
- モーダルの決定ボタンをクリックした時にレポート画面がアップデートされること
- 各DOMが更新されるようにする
- 月カレンダーと年カレンダーとの操作

## モーダル
- [ ] 決定ボタンをクリック -> メンテナンス日を登録
- [ ] 初期表示を月カレンダーにする -> どこかのタイミングで mode を day にする
- [x] 月カレンダーで選択マークの初期化
- [x] 決定ボタンでState –> JSON

## メンテンナス日の関数
- [ ] 関数を完成させる
- [x] JSONを見直し

## レポート画面ビュー
- [x] 5,000時間到達時のエアコン画面を更新する
- [x] メンテナンス後の運転時間を更新する仕組み
- [x] メンテンナス後のグラフ描画
- [x] 最後にメンテナンスした日を更新

## 最終チェック
- [ ] 不要なコードを削除する

## 起動ファイル
http://127.0.0.1:5501/home/mymu/demo/myKadenReport/

## コンソール
console.log(calendarState.selectedDate.year);
console.log(calendarState.selectedDate.month);
console.log(calendarState.selectedDate.day);
console.log('clicked');


``` js
// JSON
  lastMaintenanceDate: {
    year: 2025,
    month: 9,
    day: 23
  },

// カレンダー｜設定情報｜最小日付・最大日付
const calendarConfig = {
  minDate: {
    year: 2025,
    month: 1,
    day: 1
  },
  maxDate: {
    year: 2027,
    month: 9,
    day: 15
  }
};
// 状態管理｜初期表示｜メンテナンス日
let calendarState = {
  mode: "month", // month | year
  displayYear: 2027,
  displayMonth: 9,
  selectedDate: {
    year: 2026,
    month: 9,
    day: 1
  }
};


```



開始日と現在日付をどのJSON形式で受け取るかに合わせて、呼び出し方を具体的に示します。まず対象の計算関数がどこで定義されているかを確認して、引数の渡し方をその実装に合わせて説明します。

Searched for regex `lastMaintenanceDate|todayDate|calculate.*Hours|累積.*時間|operatingHoursAfterMaintenance|total.*Hours` (`**/*.js`), 30 results

Read 

Read , lines 520 to 720

## 引数の渡し方

この関数は `demo-operation-hours.js` の `getOperationHoursBetween(startDate, endDate)` に定義されていて、引数は必ず `Date` オブジェクトです。

JSONの `lastMaintenanceDate` と `todayDate` は次のような形なので、まず `Date` に変換します。

```javascript
const appData = JSON.parse(sessionStorage.getItem("appData"));

const start = appData.lastMaintenanceDate;
const today = appData.todayDate;

// Date へ変換（month は 0始まりなので -1 する）
const startDate = new Date(start.year, start.month - 1, start.day);
const todayDate = new Date(today.year, today.month - 1, today.day);
```

その後、関数に渡します。

```javascript
const totalHours = getOperationHoursBetween(startDate, todayDate);
```

---

## ここが重要: 終了日は含まない

コメントにもある通り、`getOperationHoursBetween` は

- 開始日: 含む
- 終了日: 含まない

という仕様です。

そのため、「開始日から現在日まで」を含めて計算したい場合は、現在日を `+1` 日した日を渡します。

```javascript
const endExclusive = new Date(today.year, today.month - 1, today.day + 1);

const totalHours = getOperationHoursBetween(startDate, endExclusive);
```

これが「開始日から今日まで」を含めた累積時間の正しい渡し方です。

---

## 例

今回の値だと次のようになります。

```javascript
const appData = {
  todayDate: { year: 2027, month: 9, day: 15 },
  lastMaintenanceDate: { year: 2025, month: 9, day: 23 }
};

const startDate = new Date(2025, 8, 23); // 2025/9/23
const todayDate = new Date(2027, 8, 15); // 2027/9/15
const endExclusive = new Date(2027, 8, 16); // 2027/9/16

const totalHours = getOperationHoursBetween(startDate, endExclusive);
console.log(totalHours);
```

> つまり、`todayDate` そのものではなく、`todayDate + 1日` を渡すのが正しいです。

必要なら次に、JSONから直接読み取る「完全な実装コード」をそのまま貼れる形でまとめます。




<svg xmlns="http://www.w3.org/2000/svg">
  <style>
    .bar {
      transform-box: fill-box;
      transform-origin: bottom;
      animation: growUp 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards;
    }

    @keyframes growUp {
      0% {
        transform: scaleY(0);
      }
      100% {
        transform: scaleY(1);
      }
    }
  </style>

  <rect class="bar" id="Rectangle 27" x="74" y="1173" width="8" height="162" fill="#BFDDFF"/>
  <rect class="bar" id="Rectangle 41" x="147" y="1298" width="8" height="37" fill="#BFDDFF"/>
  <rect class="bar" id="Rectangle 28" x="68" y="1197" width="6" height="138" fill="#E6E6E6"/>
  <rect class="bar" id="Rectangle 29" x="98" y="1190" width="8" height="145" fill="#BFDDFF"/>
  <rect class="bar" id="Rectangle 42" x="170" y="1302" width="8" height="33" fill="#BFDDFF"/>
  <rect class="bar" id="Rectangle 30" x="92" y="1182" width="6" height="153" fill="#E6E6E6"/>
  <rect class="bar" id="Rectangle 31" x="122" y="1214" width="8" height="121" fill="#BFDDFF"/>
  <rect class="bar" id="Rectangle 43" x="194" y="1294" width="8" height="41" fill="#0872ED"/>
  <rect class="bar" id="Rectangle 32" x="116" y="1204" width="6" height="131" fill="#E6E6E6"/>
  <rect class="bar" id="Rectangle 33" x="141" y="1315" width="6" height="20" fill="#E6E6E6"/>
  <rect class="bar" id="Rectangle 34" x="164" y="1311" width="6" height="24" fill="#E6E6E6"/>
  <rect class="bar" id="Rectangle 35" x="188" y="1283" width="6" height="52" fill="#E6E6E6"/>
  <rect class="bar" id="Rectangle 36" x="212" y="1276" width="6" height="59" fill="#E6E6E6"/>
  <rect class="bar" id="Rectangle 37" x="236" y="1173" width="6" height="162" fill="#E6E6E6"/>
  <rect class="bar" id="Rectangle 38" x="260" y="1189" width="6" height="146" fill="#E6E6E6"/>
  <rect class="bar" id="Rectangle 39" x="284" y="1215" width="6" height="120" fill="#E6E6E6"/>
  <rect class="bar" id="Rectangle 40" x="308" y="1290" width="6" height="45" fill="#E6E6E6"/>
  <rect class="bar" id="Rectangle 26" x="332" y="1173" width="6" height="162" fill="#E6E6E6"/>
</svg>

```javascript
// 内容は未完成のため、チェックが必要
// maintenanceDayで代用したので、不要となった

// 判定｜初期表示で本日ならマークする
function isToday(n) {
  const displayedDate = new Date(
    calendarState.displayYear,
    calendarState.displayMonth,
    n
  );
  if (
    displayedDate.getFullYear() === todayDate.getFullYear() &&
    displayedDate.getMonth()  === todayDate.getMonth() &&
    displayedDate.getMonth() === Number(n)
  ) {
    return true;
  }
  return false;

  console.log(displayedDate.getFullYear(), displayedDate.getMonth(), displayedDate.getDate());

}

isToday(15);
```
