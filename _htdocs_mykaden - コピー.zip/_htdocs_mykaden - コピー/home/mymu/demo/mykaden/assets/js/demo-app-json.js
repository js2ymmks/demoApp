const initiAppData = {
  currentPage: "mymuPlus", // 現在表示されているページのID
  currentMaintenanceMode: "normal", // normal | reached5kHours | reached10kHours
  operatingHoursAfterMaintenance: 1989, // 初期値 1989
  reached5kHoursDate: {
    year: 2025,
    month: 1,
    day: 1
  },
  todayDate: {
    year: 2027,
    month: 9,
    day: 9
  },
  lastMaintenanceDate: {
    year: 2026,
    month: 9,
    day: 15
  },
  entryDeviceId: null, // 
  "rac-1": {
    status: true,
  },
  "rac-2": {
    status: true,
  },
};

const headerSet = {
  home: {
    left: {
      type: "drawer",
    },
    title: "MyMU",
    right: {
      text: '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="9" stroke="black" stroke-width="1.5"/><circle cx="10" cy="8" r="3" fill="black"/><path fill-rule="evenodd" clip-rule="evenodd" d="M5 17C5 14.2386 7.23858 12 10 12C12.7614 12 15 14.2386 15 17V17.3846L12.5 18.4615L10 19C10 19 8.45714 18.7708 7.5 18.4615C6.54286 18.1523 5 17.3846 5 17.3846V17Z" fill="black"/></svg>',
      visible: true,
      action: "mymu",
    },
  },
  mymuPlus: {
    left: {
      type: "drawer",
    },
    title: "MyMU",
    right: {
      text: '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="9" stroke="black" stroke-width="1.5"/><circle cx="10" cy="8" r="3" fill="black"/><path fill-rule="evenodd" clip-rule="evenodd" d="M5 17C5 14.2386 7.23858 12 10 12C12.7614 12 15 14.2386 15 17V17.3846L12.5 18.4615L10 19C10 19 8.45714 18.7708 7.5 18.4615C6.54286 18.1523 5 17.3846 5 17.3846V17Z" fill="black"/></svg>',
      visible: true,
      action: "mymu",
    },
  },
  selectDevice: {
    left: {
      type: "backToMyMUPlusScreen",
    },
    title: "My家電レポート",
    right: {
      visible: false,
    },
  },
  report: {
    left: {
      type: "backToSelectDeviceScreen",
    },
    title: "MyMU",
    right: {
      text: '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"><rect x="1" y="2" width="18" height="2.5" rx="1.25" fill="black"/><rect x="1" y="9" width="18" height="2.5" rx="1.25" fill="black"/><rect x="1" y="16" width="18" height="2.5" rx="1.25" fill="black"/></svg>',
      visible: true,
      action: "drawer",
    },
  },
};

// セッションストレージに展開
function storeJsonData() {
  try {
    sessionStorage.setItem("appData", JSON.stringify(initiAppData));
    sessionStorage.setItem("appDataEdit", JSON.stringify(initiAppData));
    sessionStorage.setItem("headerSet", JSON.stringify(headerSet));
  } catch (error) {
    showAlert("JSONデータの保存に失敗しました。", "error");
  }
}
