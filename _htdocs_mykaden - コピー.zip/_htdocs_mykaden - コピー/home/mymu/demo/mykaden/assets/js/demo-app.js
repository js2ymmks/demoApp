﻿/******************************************
 * テンプレートファイル読み込み
 ******************************************/
document.addEventListener("DOMContentLoaded", async () => {
  try {
    const [alert, header, footer, modal, drawer] = await Promise.all([
      fetch("../partials/alert.txt").then((r) => r.text()),
      fetch("../partials/header.txt").then((r) => r.text()),
      fetch("../partials/footer.txt").then((r) => r.text()),
      fetch("../partials/modal.txt").then((r) => r.text()),
      fetch("../partials/drawer-menu.txt").then((r) => r.text()),

      // 本番環境では下記を使用する
      // fetch("/home/mymu/demo/mymu/partials/alert.txt").then((r) => r.text()),
      // fetch("/home/mymu/demo/mymu/partials/header.txt").then((r) => r.text()),
      // fetch("/home/mymu/demo/mymu/partials/footer.txt").then((r) => r.text()),
      // fetch("/home/mymu/demo/mymu/partials/modal.txt").then((r) => r.text()),
      // fetch("/home/mymu/demo/mymu/partials/drawer-menu.txt").then((r) => r.text()),
    ]);

    document.querySelector(".content-alert").innerHTML = alert;
    document.querySelector(".content-header").innerHTML = header;
    document.querySelector(".content-footer").innerHTML = footer;
    document.querySelector(".content-modal").innerHTML = modal;
    document.querySelector(".content-drawer").innerHTML = drawer;
    initUI();
  } catch (err) {
    console.error("Failed to load partials:", err);
  }
});

/******************************************
 * ユーティリティ：JSON取得（ブラケット版）
 ******************************************/
const getJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("appDataEdit");
  let data;
  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }
  if (!data) return undefined;
  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");
  const props = normalizedPath.split(".");
  let current = data;
  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }
  return current;
};

/******************************************
 * ユーティリティ：JSON更新（ブラケット版）
 ******************************************/
const setJsonValue = (propertyPath, value) => {
  const storedJson = sessionStorage.getItem("appDataEdit");
  let data;
  try {
    data = storedJson ? JSON.parse(storedJson) : {};
  } catch (e) {
    data = {};
  }
  // ブラケット記法をドット記法に変換
  // "buttons[0].label" → "buttons.0.label"
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");
  const props = normalizedPath.split(".");
  let current = data;
  for (let i = 0; i < props.length - 1; i++) {
    const prop = props[i];
    // 数字 → 配列アクセス
    const index = Number(prop);
    const isIndex = !isNaN(index);
    if (isIndex) {
      if (!Array.isArray(current)) {
        current = [];
      }
      if (current[index] === undefined) {
        current[index] = {};
      }
      current = current[index];
    } else {
      if (!current[prop] || typeof current[prop] !== "object") {
        current[prop] = {};
      }
      current = current[prop];
    }
  }
  // 最終プロパティ
  const lastProp = props[props.length - 1];
  const lastIndex = Number(lastProp);
  if (!isNaN(lastIndex)) {
    if (!Array.isArray(current)) current = [];
    current[lastIndex] = value;
  } else {
    current[lastProp] = value;
  }
  sessionStorage.setItem("appDataEdit", JSON.stringify(data));
};

/******************************************
 * ユーティリティ：JSON取得（ブラケット版）ヘッダー用
 ******************************************/
const getHeaderJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("headerSet");
  let data;
  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }
  if (!data) return undefined;
  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");
  const props = normalizedPath.split(".");
  let current = data;
  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }
  return current;
};

/******************************************
 * ユーティリティ：ヘッダーのアイテムを設定する
 ******************************************/
function initHeader() {
  // ==============================
  // DOM取得
  // ==============================
  const headerDom = {
    leftBtn: document.getElementById("headerLeftBtn"),
    title: document.getElementById("headerTitle"),
    rightBtn: document.getElementById("headerRightBtn"),
  };

  if (!headerDom.leftBtn || !headerDom.title || !headerDom.rightBtn) {
    console.warn("header DOM がまだ準備できていません");
    return;
  }

  // ==============================
  // headerSetBodyKeyキー取得
  // ==============================
  const currentHeaderSetKey = document.body.dataset.appHeaderSet;
  if (!currentHeaderSetKey) {
    console.warn("data-app-header-set が指定されていません");
    return;
  }

  // ==============================
  // headerSetJson 取得
  // ==============================
  const headerSetJson = getHeaderJsonValue(`${currentHeaderSetKey}`);
  if (!headerSetJson) {
    console.warn(`headerSet.${currentHeaderSetKey} が見つかりません`);
    return;
  }

  // ==============================
  // タイトル
  // ==============================
  headerDom.title.innerHTML = headerSetJson.title;

  // ==============================
  // 左ボタン
  // ==============================
  renderLeftButton(headerSetJson.left?.type, headerDom.leftBtn);
  headerDom.leftBtn.onclick = () =>
    handleHeaderLeftAction(headerSetJson.left?.type);

  // ==============================
  // 右ボタン
  // ==============================
  renderRightButton(headerSetJson.right, headerDom.rightBtn);
  headerDom.rightBtn.onclick = () =>
    handleHeaderRightAction(headerSetJson.right?.action);
}

function initUI() {
  initFooterButtons();
  initFooterButtonsState();
  initHeader();
}

// ==============================
// 左ボタン描画
// ==============================
// リセット
function renderLeftButton(type, btn) {
  btn.innerHTML = "";
  btn.classList.remove("d-none");
  // アイコン設定
  switch (type) {
    case "backToMyMUPlusScreen":
      btn.innerHTML = '<div class="d-flex align-items-center gap-1"><i class="bi bi-chevron-left"></i> <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M18.5 19.4364H1.5C0.68 19.4364 0.01 18.8048 0 18.008V7.81488C0.05 6.93064 0.5 6.10469 1.21 5.56054L8.79 0.342524C9.53 -0.114175 10.48 -0.114175 11.22 0.342524L18.79 5.55083C19.51 6.10469 19.95 6.92092 20 7.80516V18.008C19.99 18.8048 19.32 19.4364 18.5 19.4267V19.4364ZM11.09 12.3333V15.7537C11.06 16.2104 11.15 16.6573 11.34 17.0752C11.77 17.8039 12.61 18.2023 13.47 18.1052C14.12 18.144 14.76 17.9303 15.25 17.5124C15.67 17.0266 15.87 16.4047 15.82 15.7731V12.343H14.81V15.6176C14.83 15.9091 14.81 16.1909 14.72 16.4727C14.56 17.0071 14.04 17.357 13.47 17.3084C13.07 17.3278 12.68 17.1723 12.42 16.8711C12.17 16.5213 12.07 16.0938 12.13 15.6759V12.3527H11.09V12.3333ZM3.95 12.3333V17.9594H4.92V14.8014C4.9 14.0921 4.87 13.4313 4.85 12.9454V12.926C5.06 13.4799 5.16 13.7714 5.26 14.0532L5.3 14.1698C5.32 14.2378 5.34 14.3058 5.36 14.3544V14.403C5.41 14.5099 5.43 14.5876 5.45 14.6168L6.68 17.9594H7.64L9.09 13.9366C9.09 13.9366 9.11 13.8783 9.12 13.8394C9.15 13.752 9.19 13.6256 9.24 13.4799C9.24 13.4604 9.26 13.4119 9.28 13.3633L9.31 13.2758C9.34 13.1787 9.39 13.0523 9.43 12.926V13.2175C9.42 13.9754 9.42 14.0532 9.41 14.4224V14.8694V17.9691H10.44V12.3333H8.62L7.58 15.569L7.46 15.948L7.3 16.4144C7.28 16.4727 7.25 16.5893 7.19 16.7934L7.17 16.7059C7.15 16.6282 7.13 16.5504 7.1 16.4727C7.07 16.3853 7.04 16.3075 7.01 16.2201V16.1909C6.98 16.1326 6.96 16.0743 6.94 16.016L6.72 15.3164L5.72 12.3333H3.95ZM11.69 10.5454L11.62 11.245C11.85 11.3033 12.09 11.3324 12.33 11.3421C12.72 11.3421 13.1 11.2061 13.39 10.9535C13.67 10.6328 13.89 10.2538 14.02 9.84573L15.78 5.37592H14.79L13.94 7.81488C13.82 8.16469 13.74 8.42705 13.65 8.77686C13.57 8.52422 13.54 8.42705 13.48 8.26186V8.23271C13.44 8.15498 13.41 8.06752 13.37 7.9412L12.45 5.3662H11.37L13.11 9.78743C13.06 9.92347 13 10.0498 12.92 10.1664C12.75 10.4482 12.43 10.6134 12.1 10.5745C11.97 10.5745 11.83 10.5648 11.71 10.5259L11.69 10.5454ZM3.94 5.38564V11.0118H4.91V7.85375C4.89 7.14441 4.86 6.48366 4.84 5.99781V5.97837C5.05 6.53224 5.15 6.82375 5.25 7.10554L5.29 7.22215C5.31 7.29016 5.33 7.35818 5.35 7.40677V7.45535C5.4 7.56224 5.42 7.63998 5.44 7.66913L6.67 11.0118H7.63L9.08 6.97922C9.08 6.97922 9.1 6.92092 9.11 6.88205C9.14 6.7946 9.18 6.66828 9.23 6.52252C9.24 6.48366 9.27 6.40592 9.3 6.32818L9.32 6.26988C9.35 6.18243 9.39 6.07554 9.42 5.97837V6.26988C9.41 7.02781 9.41 7.10554 9.4 7.47479V7.92177V11.0215H10.43V5.38564H8.62L7.58 8.62139L7.46 9.00035L7.3 9.46677C7.28 9.52507 7.25 9.65139 7.19 9.84573L7.17 9.75828C7.15 9.68054 7.13 9.60281 7.1 9.52507C7.07 9.43762 7.04 9.35988 7.02 9.27243C7 9.18498 6.97 9.13639 6.95 9.06837L6.73 8.36875L5.73 5.38564H3.97H3.94Z" fill="black"/></svg></div>';
      break;
    case "drawer":
      btn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"><rect x="1" y="2" width="18" height="2.5" rx="1.25" fill="black"/><rect x="1" y="9" width="18" height="2.5" rx="1.25" fill="black"/><rect x="1" y="16" width="18" height="2.5" rx="1.25" fill="black"/></svg>';
      break;
    case "backToSelectDeviceScreen":
      btn.innerHTML = '<i class="bi bi-chevron-left"></i>';
      const d = getJsonValue("entryDeviceId");
      const headerTitleEl = document.getElementById('headerTitle');
      // ヘッダー書き換え処理
      headerTitleEl.textContent = MASTER_DEVICES[d === "d1" ? "d1" : "d2"].name;
      break;
    default:
      btn.classList.add("d-none");
  }
}

// ==============================
// 左アクション処理
// ==============================
function handleHeaderLeftAction(type) {
  switch (type) {
    case "backToMyMUPlusScreen":
      alert("デモアプリではこのボタンは操作できません。フッターのMyMU＋タブをタップしてMyMU＋画面へ戻ってください。");
      break;
    case "backToSelectDeviceScreen":
      window.location.href = "../select-device/";
      break;
    case "drawer":
      const bsOffcanvas = new bootstrap.Offcanvas("#appOffcanvas");
      bsOffcanvas.show();
      break;
  }
}

// ==============================
// 右ボタン描画　headerTitle
// ==============================
function renderRightButton(headerSetJsonRight, headerDomRight) {
  // 右ボタンのプロパティチェック
  if (!headerSetJsonRight || !headerSetJsonRight.visible) {
    headerDomRight.classList.add("d-none");
    headerDomRight.onclick = null;
    return;
  }

  // 表示
  headerDomRight.classList.remove("d-none");
  // text / icon / svg すべて対応
  headerDomRight.innerHTML = headerSetJsonRight.text || "";
  if (headerSetJsonRight.action === "drawer") {
    headerDomRight.disabled = false;
    headerDomRight.classList.remove("disabled");
    headerDomRight.classList.remove("js-complete-btn");
    headerDomRight.setAttribute("aria-disabled", "false");
  }

  // クリック処理（あれば）
  headerDomRight.onclick = () => {
    handleHeaderRightAction(headerSetJsonRight.action, headerSetJsonRight);
  };
}

// ==============================
// 右アクション処理
// ==============================
function handleHeaderRightAction(action) {
  switch (action) {
    // メニュー表示
    case "drawer":
      const bsOffcanvas = new bootstrap.Offcanvas("#appOffcanvas");
      bsOffcanvas.show();
      break;

    // アラート表示
    case "alert":
      alert(
        "デモアプリではこのボタンは操作できません。＜ ボタンで戻ってください",
      );
      break;

    // MyMUボタン
    case "mymu":
      const headerEl = document.querySelector(".app-header");
      headerEl.addEventListener("click", (e) => {
        const btn = e.target.closest("#headerRightBtn");
        if (!btn) return;
        alert("デモアプリではこのボタンは操作できません。");
      });
      break;
    // シーン
    case "":
      break;
  }
}

/******************************************
 * ユーティリティ：モーダル表示
 ******************************************/
function showModal(modalId) {
  const modalEl = document.getElementById(modalId);
  if (!modalEl) return;

  const modal = new bootstrap.Modal(modalEl);
  modal.show();
}

/******************************************
 * イニシャライズ：フッター
 ******************************************/
const initFooterButtons = () => {
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const currentHeaderSetKey = document.body.dataset.appHeaderSet;
      // MyMU＋アイコンのみ処理する
      if (btn.dataset.appPage !== "mymuPlus") { return; }
      if (
        currentHeaderSetKey === "editAutomation" &&
        btn.dataset.appPage === "automation"
      ) {
        setJsonValue("navigationMode", "back");
      }
      setJsonValue("currentPage", btn.dataset.appPage);
    });
  });
};

/******************************************
 * レンダリング：フッターアイコン表示更新
 ******************************************/
const initFooterButtonsState = () => {
  // フッターが存在しない画面
  const footerElement = document.getElementsByClassName("content-footer")[0];
  if (footerElement.className.includes("d-none")) {
    return;
  }
  // スタイルリセット
  const currentPage = getJsonValue("currentPage");
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.classList.remove("active");
  });
  // レンダリング
  footerButtons.forEach((btn) => {
    const page = btn.dataset.appPage;
    if (page === currentPage) {
      btn.classList.add("active");
    }
  });
};

/******************************************
 * マスターデータ
 ******************************************/
// 機器マスター
const MASTER_DEVICES = {
  "d1": {
    name: "リビング",
  },
  "d2": {
    name: "寝室",
  }
}

// RACイラストマスター｜正常時・5,000時間到達時・10,000時間到達時のイラストSVGのデータ
const MASTER_RAC_ILLUSTRATION = {
  normal: '<path id="shadow" opacity="0.1" d="M319.663 40H67.3375C63.5767 40 60.5 43.16 60.5 47.0219V113.375L67.3375 134H319.663L326.5 113.375V47.0219C326.5 43.16 323.423 40 319.663 40Z" fill="#0872ED"/><g id="main_2"><path id="Vector" d="M313.663 32H61.3375C57.5767 32 54.5 35.16 54.5 39.0219V105.375L61.3375 126H313.663L320.5 105.375V39.0219C320.5 35.16 317.423 32 313.663 32Z" fill="#FBFBFC"/><g id="Vector_2" style="mix-blend-mode:multiply"><path d="M54.5 105H320.5L313.663 126H61.3375L54.5 105Z" fill="#0872ED" fill-opacity="0.1"/></g><path id="Vector (Stroke)" d="M320 39.0215C320 35.4232 317.134 32.5 313.662 32.5H61.3379C57.8659 32.5 55.0002 35.4232 55 39.0215V105.294L61.6992 125.5H313.301L320 105.294V39.0215ZM321 105.375C321 105.428 320.991 105.482 320.975 105.533L314.137 126.157C314.069 126.362 313.878 126.5 313.662 126.5H61.3379C61.1224 126.5 60.9311 126.362 60.8633 126.157L54.0254 105.533C54.0086 105.482 54 105.428 54 105.375V39.0215C54.0002 34.8962 57.2887 31.5 61.3379 31.5H313.662C317.711 31.5 321 34.8962 321 39.0215V105.375Z" fill="#0872ED"/><path id="Vector (Stroke)_2" d="M316.5 104.6C316.721 104.6 316.9 104.779 316.9 105C316.9 105.221 316.721 105.4 316.5 105.4H58.5C58.2791 105.4 58.0996 105.221 58.0996 105C58.0996 104.779 58.2791 104.6 58.5 104.6H316.5Z" fill="#0872ED"/><path id="Vector (Stroke)_3" d="M312.5 111.6C312.628 111.6 312.748 111.661 312.823 111.765C312.898 111.868 312.92 112.001 312.881 112.122L308.383 126.122C308.315 126.332 308.09 126.448 307.88 126.381C307.67 126.313 307.554 126.088 307.621 125.878L311.951 112.4H63.0742L68.0459 125.861C68.1224 126.068 68.0166 126.298 67.8096 126.375C67.6024 126.452 67.3725 126.346 67.2959 126.139L62.125 112.139C62.0797 112.016 62.0971 111.879 62.1719 111.771C62.2467 111.664 62.3692 111.6 62.5 111.6H312.5Z" fill="#0872ED"/><path id="Vector (Stroke)_4" d="M187.9 112V126H187.1V112H187.9Z" fill="#0872ED"/></g>',
  // 5000時間
  reached5kHours: '<path id="Rectangle 690" d="M-170.5 31C-170.5 32.1046 -169.605 33 -168.5 33L204.39 33C206.21 33 207.084 30.7666 205.747 29.5313L197.566 21.9687C196.709 21.1769 196.709 19.8231 197.566 19.0313L205.747 11.4687C207.084 10.2333 206.21 8 204.39 8L-168.5 8.00003C-169.605 8.00003 -170.5 8.89546 -170.5 10L-170.5 31Z" fill="#0872ED"/><text id="&#228;&#187;&#138;&#230;&#156;&#136;&#227;&#129;&#174;Tips&#227;&#130;&#146;&#227;&#131;&#129;&#227;&#130;&#167;&#227;&#131;&#131;&#227;&#130;&#175;&#239;&#188;&#129;" fill="white" style="white-space: pre" xml:space="preserve" font-family="Noto Sans JP" font-size="13" letter-spacing="0px"><tspan x="39.5" y="25.7">&#x4eca;&#x6708;&#x306e;Tips&#x3092;&#x30c1;&#x30a7;&#x30c3;&#x30af;&#xff01;</tspan></text><text id="&#230;&#142;&#165;&#231;&#182;&#154;&#230;&#150;&#185;&#230;&#179;&#149;&#227;&#129;&#174;&#233;&#129;&#184;&#230;&#138;&#158;" fill="#0872ED" fill-opacity="0.8" style="white-space: pre" xml:space="preserve" font-family="Noto Sans JP" font-size="20" font-weight="bold" letter-spacing="0px"><tspan x="40.5" y="126">&#x904b;&#x8ee2;&#x3057;&#x307e;&#x3057;&#x305f;&#xff01;</tspan></text><text id="&#230;&#142;&#165;&#231;&#182;&#154;&#230;&#150;&#185;&#230;&#179;&#149;&#227;&#129;&#174;&#233;&#129;&#184;&#230;&#138;&#158;_2" fill="#0872ED" fill-opacity="0.5" stroke="#0872ED" style="white-space: pre" stroke-linejoin="round" xml:space="preserve" font-family="Noto Sans JP" font-size="48" font-weight="bold" letter-spacing="0px"><tspan x="27" y="92.184">5 000</tspan></text><text id="&#230;&#142;&#165;&#231;&#182;&#154;&#230;&#150;&#185;&#230;&#179;&#149;&#227;&#129;&#174;&#233;&#129;&#184;&#230;&#138;&#158;_3" fill="#0872ED" fill-opacity="0.5" stroke="#0872ED" style="white-space: pre" stroke-linejoin="round" xml:space="preserve" font-family="Noto Sans JP" font-size="36" font-weight="bold" letter-spacing="-1px"><tspan x="55" y="91.388">,</tspan></text><text id="&#230;&#142;&#165;&#231;&#182;&#154;&#230;&#150;&#185;&#230;&#179;&#149;&#227;&#129;&#174;&#233;&#129;&#184;&#230;&#138;&#158;_4" fill="#0872ED" fill-opacity="0.8" style="white-space: pre" xml:space="preserve" font-family="Noto Sans JP" font-size="20" font-weight="bold" letter-spacing="0px"><tspan x="154" y="92">&#x6642;&#x9593;</tspan></text><path id="shadow" opacity="0.1" d="M486.663 40H234.337C230.577 40 227.5 43.16 227.5 47.0219V113.375L234.337 134H486.663L493.5 113.375V47.0219C493.5 43.16 490.423 40 486.663 40Z" fill="#0872ED"/><g id="main_2"><path id="Vector" d="M480.663 32H228.337C224.577 32 221.5 35.16 221.5 39.0219V105.375L228.337 126H480.663L487.5 105.375V39.0219C487.5 35.16 484.423 32 480.663 32Z" fill="#FBFBFC"/><g id="Vector_2" style="mix-blend-mode:multiply"><path d="M221.5 105H487.5L480.663 126H228.337L221.5 105Z" fill="#0872ED" fill-opacity="0.1"/></g><path id="Vector (Stroke)" d="M487 39.0215C487 35.4232 484.134 32.5 480.662 32.5H228.338C224.866 32.5 222 35.4232 222 39.0215V105.294L228.699 125.5H480.301L487 105.294V39.0215ZM488 105.375C488 105.428 487.991 105.482 487.975 105.533L481.137 126.157C481.069 126.362 480.878 126.5 480.662 126.5H228.338C228.122 126.5 227.931 126.362 227.863 126.157L221.025 105.533C221.009 105.482 221 105.428 221 105.375V39.0215C221 34.8962 224.289 31.5 228.338 31.5H480.662C484.711 31.5 488 34.8962 488 39.0215V105.375Z" fill="#0872ED"/><path id="Vector (Stroke)_2" d="M483.5 104.6C483.721 104.6 483.9 104.779 483.9 105C483.9 105.221 483.721 105.4 483.5 105.4H225.5C225.279 105.4 225.1 105.221 225.1 105C225.1 104.779 225.279 104.6 225.5 104.6H483.5Z" fill="#0872ED"/><path id="Vector (Stroke)_3" d="M479.5 111.6C479.628 111.6 479.748 111.661 479.823 111.765C479.898 111.868 479.92 112.001 479.881 112.122L475.383 126.122C475.315 126.332 475.09 126.448 474.88 126.381C474.67 126.313 474.554 126.088 474.621 125.878L478.951 112.4H230.074L235.046 125.861C235.122 126.068 235.017 126.298 234.81 126.375C234.602 126.452 234.373 126.346 234.296 126.139L229.125 112.139C229.08 112.016 229.097 111.879 229.172 111.771C229.247 111.664 229.369 111.6 229.5 111.6H479.5Z" fill="#0872ED"/><path id="Vector (Stroke)_4" d="M354.9 112V126H354.1V112H354.9Z" fill="#0872ED"/></g>',
  // 10000時間
  reached10kHours: '<path id="Rectangle 690" d="M-170.5 31C-170.5 32.1046 -169.605 33 -168.5 33L204.39 33C206.21 33 207.084 30.7666 205.747 29.5313L197.566 21.9687C196.709 21.1769 196.709 19.8231 197.566 19.0313L205.747 11.4687C207.084 10.2333 206.21 8 204.39 8L-168.5 8.00003C-169.605 8.00003 -170.5 8.89546 -170.5 10L-170.5 31Z" fill="#0872ED"/><text id="&#228;&#187;&#138;&#230;&#156;&#136;&#227;&#129;&#174;Tips&#227;&#130;&#146;&#227;&#131;&#129;&#227;&#130;&#167;&#227;&#131;&#131;&#227;&#130;&#175;&#239;&#188;&#129;" fill="white" style="white-space: pre" xml:space="preserve" font-family="Noto Sans JP" font-size="13" letter-spacing="0px"><tspan x="39.5" y="25.7">&#x4eca;&#x6708;&#x306e;Tips&#x3092;&#x30c1;&#x30a7;&#x30c3;&#x30af;&#xff01;</tspan></text><text id="&#230;&#142;&#165;&#231;&#182;&#154;&#230;&#150;&#185;&#230;&#179;&#149;&#227;&#129;&#174;&#233;&#129;&#184;&#230;&#138;&#158;" fill="#0872ED" fill-opacity="0.8" style="white-space: pre" xml:space="preserve" font-family="Noto Sans JP" font-size="20" font-weight="bold" letter-spacing="0px"><tspan x="40.5" y="126">&#x904b;&#x8ee2;&#x3057;&#x307e;&#x3057;&#x305f;&#xff01;</tspan></text><text id="&#230;&#142;&#165;&#231;&#182;&#154;&#230;&#150;&#185;&#230;&#179;&#149;&#227;&#129;&#174;&#233;&#129;&#184;&#230;&#138;&#158;_2" fill="#0872ED" fill-opacity="0.5" stroke="#0872ED" style="white-space: pre" stroke-linejoin="round" xml:space="preserve" font-family="Noto Sans JP" font-size="48" font-weight="bold" letter-spacing="0px"><tspan x="13.5" y="92.184">10 000</tspan></text><text id="&#230;&#142;&#165;&#231;&#182;&#154;&#230;&#150;&#185;&#230;&#179;&#149;&#227;&#129;&#174;&#233;&#129;&#184;&#230;&#138;&#158;_3" fill="#0872ED" fill-opacity="0.5" stroke="#0872ED" style="white-space: pre" stroke-linejoin="round" xml:space="preserve" font-family="Noto Sans JP" font-size="36" font-weight="bold" letter-spacing="-1px"><tspan x="69.5" y="91.388">,</tspan></text><text id="&#230;&#142;&#165;&#231;&#182;&#154;&#230;&#150;&#185;&#230;&#179;&#149;&#227;&#129;&#174;&#233;&#129;&#184;&#230;&#138;&#158;_4" fill="#0872ED" fill-opacity="0.8" style="white-space: pre" xml:space="preserve" font-family="Noto Sans JP" font-size="20" font-weight="bold" letter-spacing="0px"><tspan x="168.5" y="92">&#x6642;&#x9593;</tspan></text><path id="shadow" opacity="0.1" d="M486.663 40H234.337C230.577 40 227.5 43.16 227.5 47.0219V113.375L234.337 134H486.663L493.5 113.375V47.0219C493.5 43.16 490.423 40 486.663 40Z" fill="#0872ED"/><g id="main_2"><path id="Vector" d="M480.663 32H228.337C224.577 32 221.5 35.16 221.5 39.0219V105.375L228.337 126H480.663L487.5 105.375V39.0219C487.5 35.16 484.423 32 480.663 32Z" fill="#FBFBFC"/><g id="Vector_2" style="mix-blend-mode:multiply"><path d="M221.5 105H487.5L480.663 126H228.337L221.5 105Z" fill="#0872ED" fill-opacity="0.1"/></g><path id="Vector (Stroke)" d="M487 39.0215C487 35.4232 484.134 32.5 480.662 32.5H228.338C224.866 32.5 222 35.4232 222 39.0215V105.294L228.699 125.5H480.301L487 105.294V39.0215ZM488 105.375C488 105.428 487.991 105.482 487.975 105.533L481.137 126.157C481.069 126.362 480.878 126.5 480.662 126.5H228.338C228.122 126.5 227.931 126.362 227.863 126.157L221.025 105.533C221.009 105.482 221 105.428 221 105.375V39.0215C221 34.8962 224.289 31.5 228.338 31.5H480.662C484.711 31.5 488 34.8962 488 39.0215V105.375Z" fill="#0872ED"/><path id="Vector (Stroke)_2" d="M483.5 104.6C483.721 104.6 483.9 104.779 483.9 105C483.9 105.221 483.721 105.4 483.5 105.4H225.5C225.279 105.4 225.1 105.221 225.1 105C225.1 104.779 225.279 104.6 225.5 104.6H483.5Z" fill="#0872ED"/><path id="Vector (Stroke)_3" d="M479.5 111.6C479.628 111.6 479.748 111.661 479.823 111.765C479.898 111.868 479.92 112.001 479.881 112.122L475.383 126.122C475.315 126.332 475.09 126.448 474.88 126.381C474.67 126.313 474.554 126.088 474.621 125.878L478.951 112.4H230.074L235.046 125.861C235.122 126.068 235.017 126.298 234.81 126.375C234.602 126.452 234.373 126.346 234.296 126.139L229.125 112.139C229.08 112.016 229.097 111.879 229.172 111.771C229.247 111.664 229.369 111.6 229.5 111.6H479.5Z" fill="#0872ED"/><path id="Vector (Stroke)_4" d="M354.9 112V126H354.1V112H354.9Z" fill="#0872ED"/></g>',
}

/******************************************
 * グローバル変数
 ******************************************/
  // 本日をオブジェクト化
  const todayDate = new Date(
    getJsonValue('todayDate.year'),
    getJsonValue('todayDate.month') ,
    getJsonValue('todayDate.day')
  );

  // 5,000時間をオブジェクト化
  const reached5kHoursDate = new Date(
    getJsonValue('reached5kHoursDate.year'),
    getJsonValue('reached5kHoursDate.month') ,
    getJsonValue('reached5kHoursDate.day')
  );

/******************************************
 * クリックイベント｜レポート画面
 ******************************************/
document.addEventListener("click", (e) => {
  const el = e.target;

  // MyMU＋画面｜My家電レポートカード｜機器選択画面へ遷移
  const appCardBtn = el.closest(".js-app-card");
  if (appCardBtn) {
    window.location.href = "../select-device/";
  }

  // My家電レポート画面｜機器選択でIDをJSONに保存
  const selectDeviceBtn = el.closest(".js-select-device");
  if (selectDeviceBtn) {
    const deviceId = selectDeviceBtn.dataset.deviceId;
    setJsonValue("entryDeviceId", deviceId);
    window.location.href = "../report/";
  }

  // MyMU＋画面｜ハウスクリーニング｜くらトクへ遷移
  const banner = el.closest(`#banner`);
  if (banner) {
    window.open('https://kuratoku.lcx.mitsubishielectric.co.jp/house-cleaning/');
  }

  // モーダル｜カレンダー月日
const maintenanceDateUpdateBtn = el.closest("#maintenanceDateUpdateBtn");
if (maintenanceDateUpdateBtn) {
  syncCalendarStateFromJson();
  calendarState.mode = "month";

  const yearCalendar = document.querySelector(".calendarYear");
  const monthCalendar = document.querySelector(".calendarMonth");
  const arrowSet = document.querySelector(".arrow-set");
  const calendarArrow = document.querySelector(".js-calendar-arrow");

  if (yearCalendar) yearCalendar.classList.add("d-none");
  if (monthCalendar) monthCalendar.classList.remove("d-none");
  if (arrowSet) arrowSet.classList.remove("d-none");
  if (calendarArrow) calendarArrow.classList.remove("is-open");

  renderCalendar();
  showModal("calenderModal");
}

  // 全画面｜アラート表示
  const showAlertBtn = el.closest(".js-show-alert");
  if (showAlertBtn) {
    alert("デモアプリではこのボタンは操作できません。");
  }

  // 全画面｜アラート表示
  const bannerBtn = el.closest("#js-banner-btn");
  if (bannerBtn) {
    window.open('https://kuratoku.lcx.mitsubishielectric.co.jp/professional/airconditioner/#anc2');
  }

  // ↑ クリックイベントの処理はここまで
});

/******************************************
 * ユーティリティ
 ******************************************/
// モーダルを閉じたときにフォーカスを外す
window.addEventListener("hide.bs.modal", () => {
  document.activeElement.blur();
});


/******************************************
 * レンダリング｜レポート画面
 ******************************************/
// MyMU＋画面｜エアコン名を更新｜リビング・寝室
function renderSelectDeviceScreen() {
  let i = 1;
  document.querySelectorAll(".js-device-name").forEach((deviceNameElement) => {
    const deviceName = MASTER_DEVICES[`d${i}`]?.name || "";
    deviceNameElement.textContent = deviceName;
    i++;
  });
}

// レポート画面｜メンテナンスした日を更新 operatingTimeAfterMaintenance
function renderReportScreen() {
  // メンテナンス後のDOM表示を更新｜運転時間・メンテナンス日・グラフ
  updateDetailsContainer();
  // RACのイラストを表示
  selectRacIllustration(); // normal｜reached5kHours｜reached10kHours）
}

// アップデート｜メンテナンス後の運転時間
function updateOperatingHours() {
  const elm = document.querySelector(".operatingHoursAfterMaintenance");
  elm.textContent = getJsonValue('operatingHoursAfterMaintenance').toLocaleString('ja-JP');
}

// アップデート｜最後にメンテナンスした日
function updateLastMaintenanceDate() {
  const elmYear = document.querySelector(".js-last-maintenance-year");
  const elmMonth = document.querySelector(".js-last-maintenance-month");
  const elmDay = document.querySelector(".js-last-maintenance-day");
  elmYear.textContent = getJsonValue('lastMaintenanceDate.year');
  elmMonth.textContent = String(getJsonValue('lastMaintenanceDate.month'))?.padStart(2, '0');
  elmDay.textContent = String(getJsonValue('lastMaintenanceDate.day'))?.padStart(2, '0');
};

// レポート画面｜機器のイラストを更新する
function selectRacIllustration() {
  const hours = getJsonValue("operatingHoursAfterMaintenance");
  const container = document.getElementById("illustration");
  if (!container) return;
  if (hours <= 4999) {
  // コンテナを初期化
  container.innerHTML = MASTER_RAC_ILLUSTRATION.normal;
  } else {
  // コンテナを初期化
  container.innerHTML = MASTER_RAC_ILLUSTRATION.reached5kHours;
  } 
}

// レポート画面｜グラフ描画｜メンテナンス後の運転
function updateMaintenanceHoursGraph() {
  const value = getJsonValue('operatingHoursAfterMaintenance');
  const newHeight = value * 0.0272;
  const rect = document.getElementById('maintenanceHoursGraph');
  rect.setAttribute('height', newHeight);
}

/******************************************
 * カレンダー処理
 * 月カレンダー
 * 年カレンダー
 ******************************************/
// カレンダー｜設定情報｜最小日付・最大日付
const calendarConfig = {
  minDate: {
    year: 2025,
    month: 1,
    day: 1
  },
  maxDate: {
    year: getJsonValue('todayDate.year'),
    month: getJsonValue('todayDate.month'),
    day: getJsonValue('todayDate.day'),
    // year: getJsonValue('todayDate.year'),
    // month: getJsonValue('todayDate.month'),
    // day: getJsonValue('todayDate.day'),
  }
};
// 状態管理｜初期表示｜メンテナンス日
let calendarState = {
  mode: "month", // month | year
  displayYear: 2027,
  displayMonth: 9,
  selectedDate: {
    year: getJsonValue('todayDate.year'),
    month: getJsonValue('todayDate.month'),
    day: getJsonValue('todayDate.day'),
  },
  lastMaintenanceDate: {
    year: getJsonValue('lastMaintenanceDate.year'),
    month: getJsonValue('lastMaintenanceDate.month'),
    day: getJsonValue('lastMaintenanceDate.day'),
  }
};

function syncCalendarStateFromJson() {
  const lastMaintenanceDate = {
    year: Number(getJsonValue("lastMaintenanceDate.year")),
    month: Number(getJsonValue("lastMaintenanceDate.month")),
    day: Number(getJsonValue("lastMaintenanceDate.day")),
  };

  calendarState.lastMaintenanceDate = { ...lastMaintenanceDate };
  calendarState.selectedDate = { ...lastMaintenanceDate };
  calendarState.displayYear = Number(getJsonValue("todayDate.year"));
  calendarState.displayMonth = Number(getJsonValue("todayDate.month"));
}

// カレンダー｜レンダリング
function renderCalendar() {
  // レンダリング｜ヘッダー部（年月表示）
  renderCalenderHeader(calendarState.displayYear, calendarState.displayMonth - 1);
  if (calendarState.mode === "month") {
    renderMonthCalendar();
    // 年カレンダー
  } else {
    renderYearCalendar();
  }
  // ボタンの状態をチェック|非活性・無効化
  isBtnDisable(); 
  // 決定ボタン｜有効化・無効化
  canExcute();
  // 月カレンダー
}

/******************************************
 * ビュー
 ******************************************/
// 矢印ボタン｜無効化する（disabled・グレー色）
function disableButton(selector) {
  const btn = document.querySelector(selector);
  if (!btn) return;

  btn.setAttribute("aria-disabled", "true");
  btn.classList.add("is-disabled");
  btn.style.pointerEvents = "none";

  const svgPath = btn.querySelector("svg path");
  if (svgPath) {
    svgPath.setAttribute("fill", "#E6E6E6");
  }
}

// 矢印ボタン｜有効化する（有効化・元の青色）
function enableButton(selector) {
  const btn = document.querySelector(selector);
  if (!btn) return;

  btn.setAttribute("aria-disabled", "false");
  btn.classList.remove("is-disabled");
  btn.style.pointerEvents = "";

  const svgPath = btn.querySelector("svg path");
  if (svgPath) {
    svgPath.setAttribute("fill", "#967AEB");
  }
}

// 決定ボタンの状態操作
function canExcute() {
  const storagedDate = getJsonValue('lastMaintenanceDate');
  const selectedDate = calendarState.selectedDate
  const btn = document.querySelector('.calenderExcuteBtn');
  if (
    (storagedDate.year === selectedDate.year) &&
    (storagedDate.month === selectedDate.month) &&
    (storagedDate.day === selectedDate.day)
  ) {
    btn.classList.add('disabled') ?? "";
  } else {
    btn.classList.remove('disabled')
  }
}

/******************************************
 * 月カレンダー
 ******************************************/
// レンダリング｜月カレンダー｜
function renderMonthCalendar() {
  // レンダリング｜月カレンダ｜カレンダーデータ作成（HTML・日にちデータ）
  createMonthCalendarHtml(calendarState.displayYear, calendarState.displayMonth - 1);
  // メンテナンス日をマーク
  // const selectedYear = calendarState.selectedDate.year
  // const selectedMonth = calendarState.selectedDate.month
  // const selectedDay = calendarState.selectedDate.day
}

// レンダリング｜月・年カレンダー｜共通（ヘッダー）
function renderCalenderHeader(year, month) {
  document.querySelector(".js-calendar-month-label").textContent =
    `${calendarState.displayYear}年 ${String(calendarState.displayMonth).padStart(2, "0")}月`;
}

// HTML作成｜月カレンダー｜
function createMonthCalendarHtml(year, month) {
  // カレンダーデータを取得
  const calendar = createMonthCalendarData(year, month);
  // 表示先
  const container = document.getElementById("monthCalendar");

  if (!container) return;
  // カレンダーを初期化
  let html = "";
  // データ属性用の変数
  let n = 1;
  // 42セルをループ
for (let i = 0; i < 42; i++) {
  if (calendar.days[i] === null) {
    html += `<button class="bg-transparent border border-0 js-calendar-day invisible"></button>`;
  // 最終メンテナンス日より前、または本日より後の日付は選択不可
  } else if (!isWithinDateRange(n)) {
    html += `<button class="bg-transparent border border-0 fc-disabled js-calendar-day" disabled data-key="${n}">${calendar.days[i]}</button>`;
    n++;
  // 本日はマークする
  } else if (!isMaintenanceDay(n)) {
    html += `<button class="bg-transparent border border-0 js-calendar-day" data-key="${n}">${calendar.days[i]}</button>`;
    n++;
  } else {
    html += `<button class="bg-transparent border border-0 js-calendar-day active" data-key="${n}">${calendar.days[i]}</button>`;
    n++;
  }
}
  container.innerHTML = html;
  document.querySelector('.calenderExcuteBtn ').classList.remove('disabled') ?? "";
}

// データ作成｜月カレンダー
function createMonthCalendarData(year, month) {
  // 1日の曜日
  const firstWeek = new Date(year, month, 1).getDay();
  // 月末日
  const lastDate = new Date(year, month + 1, 0).getDate();
  // 42セル
  const days = Array(42).fill(null);
  // 日付を配置
  for (let day = 1; day <= lastDate; day++) {
    days[firstWeek + day - 1] = day;
  }
  return {
    year,
    month,
    firstWeek,
    lastDate,
    days
  };
}

// メンテナンス日をチェック
function isMaintenanceDay(n) {
  const displayYear = Number(calendarState.displayYear);
  const displayMonth = Number(calendarState.displayMonth);
  const selectedYear = Number(getJsonValue('todayDate.year'));
  const selectedMonth = Number(getJsonValue('todayDate.month'));
  const selectedDay = Number(getJsonValue('todayDate.day'));
  // const selectedYear = Number(getJsonValue('lastMaintenanceDate.year'));
  // const selectedMonth = Number(getJsonValue('lastMaintenanceDate.month'));
  // const selectedDay = Number(getJsonValue('lastMaintenanceDate.day'));

  if (
    displayYear === selectedYear &&
    displayMonth === selectedMonth &&
    selectedDay === Number(n)
  ) {
    return true;
  }
  return false;
}

// メンテナンス月をチェック
function isMaintenanceMonth(n) {
  const displayYear = Number(calendarState.displayYear);
  const displayMonth = Number(calendarState.displayMonth);
  const selectedYear = Number(getJsonValue('lastMaintenanceDate.year'));
  const selectedMonth = Number(getJsonValue('lastMaintenanceDate.month'));
  const selectedDay = Number(getJsonValue('lastMaintenanceDate.day'));

  if (
    displayYear === selectedYear &&
    selectedMonth === Number(n)
  ) {
    return true;
  }
  return false;
}

/******************************************
 * 年カレンダー
 ******************************************/
// レンダリング｜年カレンダー｜
function renderYearCalendar() {
  // レンダリング｜年カレンダー｜西暦表示
  renderYearCalendarHeader(calendarState.displayYear);
  // レンダリング｜月カレンダ｜カレンダーデータ作成（HTML・月データ）
  createYearCalendarHtml(calendarState.displayYear, calendarState.displayMonth - 1);
}

// レンダリング｜年カレンダー｜西暦表示部
function renderYearCalendarHeader(year) {
  document.querySelector(".js-calendar-year-label").textContent =
    `${calendarState.displayYear}`;
}

// 月カレンダー｜前月・次月の切り替え
function changeMonth(offset) {
  let year = calendarState.displayYear;
  let month = calendarState.displayMonth + offset;
  // 1月より小さい場合は12月になる
  if (month < 1) {
    month = 12;
    year--;
  }
  // 12月より大きい場合は1月になる
  if (month > 12) {
    month = 1;
    year++;
  }

  // 最小値・最大値を超えた場合
  if (!canDisplayMonth(year, month)) {
    return;
  }

  calendarState.displayYear = year;
  calendarState.displayMonth = month;

  isBtnDisable(); // ボタンの状態をチェック
  renderCalenderHeader(calendarState.displayYear, calendarState.displayMonth - 1);
  createMonthCalendarData(calendarState.displayYear, calendarState.displayMonth - 1);
}

// ボタンの状態をチェック|非活性・無効化
function isBtnDisable() {
  const year = calendarState.displayYear;
  const month = calendarState.displayMonth;
  const calenderMode = calendarState.mode;

  enableButton(".js-calendar-prev-month");
  enableButton(".js-calendar-next-month");
  enableButton(".js-calendar-prev-year");
  enableButton(".js-calendar-next-year");

  // 月カレンダーの場合
  if (calenderMode === "month") {
    if (
      year === calendarConfig.minDate.year &&
      month === calendarConfig.minDate.month
    ) {
      disableButton(".js-calendar-prev-month");
    } else if (
      year === calendarConfig.maxDate.year &&
      month === calendarConfig.maxDate.month
    ) {
      disableButton(".js-calendar-next-month");
    }
    // 年カレンダーの場合
  } else {
    if (year === calendarConfig.minDate.year) {
      disableButton(".js-calendar-prev-year");
    } else if (year === calendarConfig.maxDate.year) {
      disableButton(".js-calendar-next-year");
    }
  }
}

// 月カレンダー｜前年・翌年の切り替え
function changeYear(offset) {
  const year = calendarState.displayYear + offset;
  // 表示可能な年か確認
  if (!canDisplayYear(year)) {
    return;
  }
  calendarState.displayYear = year;
  isBtnDisable(); // ボタンの状態をチェック
  renderYearCalendar();
}

// イベントデリゲーション｜カレンダーモーダル
document.addEventListener("click", (event) => {
  // 月⇔年スイッチ｜calendarState.modeを切り替える
  if (event.target.closest(".js-calendar-switch")) {
    switchCalenderMode();
  }

  //   前月
  if (event.target.closest(".js-calendar-prev-month")) {
    changeMonth(-1); // 前月
    renderMonthCalendar(); // カレンダー表示
  }
  //   次月
  if (event.target.closest(".js-calendar-next-month")) {
    changeMonth(1); // 次月
    renderMonthCalendar(); // カレンダー表示
  }
  // 前年
  if (event.target.closest(".js-calendar-prev-year")) {
    // 処理
    changeYear(-1); // 前月
    renderYearCalendar(); // カレンダー表示
  }
  // 次年
  if (event.target.closest(".js-calendar-next-year")) {
    // 処理
    changeYear(1); // 前月
    renderYearCalendar(); // カレンダー表示
  }

  // 日にちをクリック｜JSONへ代入（日と月のみ）
  if (event.target.closest(".js-calendar-day")) {
    const dayButton = event.target.closest(".js-calendar-day");
    // 一旦リセット
    dayButton.parentElement.querySelectorAll('.js-calendar-day').forEach((btn) => {
      btn.classList.remove('active');
    });
    // 日にちをマーク
    dayButton.classList.add('active');
    // Stateへ代入
    calendarState.selectedDate.year = calendarState.displayYear;
    calendarState.selectedDate.month = calendarState.displayMonth;
    calendarState.selectedDate.day = Number(dayButton.dataset.key);
    // 決定ボタン｜有効化・無効化
    canExcute();
  }

  // 月をクリック
  if (event.target.closest(".js-calendar-month")) {
    const monthButton = event.target.closest(".js-calendar-month");
    // 一旦リセット
    monthButton.parentElement.querySelectorAll('.js-calendar-month').forEach((btn) => {
      btn.classList.remove('active');
    });
    // Stateへ代入
    // monthButton.classList.add('active');
    calendarState.selectedDate.year = calendarState.displayYear;
    calendarState.selectedDate.month = Number(monthButton.dataset.key);
    // monthButton.classList.add('active');
    // console.log("year", calendarState.selectedDate.year);
    // console.log("month", calendarState.selectedDate.month);
    // 月カレンダーへ戻ったとき、選択された月が表示されるようStateへ代入
    calendarState.displayYear = calendarState.selectedDate.year;
    calendarState.displayMonth = calendarState.selectedDate.month;
    // レンダリング｜ヘッダー部（年月表示）
    renderCalenderHeader(calendarState.selectedDate.year, calendarState.selectedDate.month);
    // レンダリング｜月カレンダ｜カレンダーデータ作成（HTML・日にちデータ）
    switchCalenderMode();
    // 決定ボタン｜有効化・無効化
    // canExcute();
  }
  
  // ↑ イベントデレゲーションここまで
});

// カレンダー｜戻る・進むボタンの最小月・最大月判定
function canDisplayMonth(year, month) {
  // 戻る・進むボタンをリセット
  enableButton('.js-calendar-prev-month');
  enableButton('.js-calendar-next-month');
  // 最小年月より前
  if (
    year < calendarConfig.minDate.year ||
    (year === calendarConfig.minDate.year &&
      month < calendarConfig.minDate.month)
  ) {
    return false;
  }
  // 最大年月より後
  if (
    year > calendarConfig.maxDate.year ||
    (year === calendarConfig.maxDate.year &&
      month > calendarConfig.maxDate.month)
  ) {
    return false;
  }
  return true;
}

// カレンダー｜戻る・進むボタンの最小年・最大々判定
function canDisplayYear(year) {
  // 戻る・進むボタンをリセット
  // enableButton('.js-calendar-prev-year button');
  // enableButton('.js-calendar-next-year button');
  // 最小年より前、または後
  if (
    year < calendarConfig.minDate.year ||
    year > calendarConfig.maxDate.year
  ) {
    return false;
  }
  return true;
}

// カレンダー｜決定ボタン —> JSONへセット
function setMaintenanceDay() {
  setJsonValue('lastMaintenanceDate.year', calendarState.selectedDate.year);
  setJsonValue('lastMaintenanceDate.month', calendarState.selectedDate.month);
  setJsonValue('lastMaintenanceDate.day', calendarState.selectedDate.day);
  syncCalendarStateFromJson();
  // modeをリセット
  calendarState.mode = "month";
  document.querySelector(".calendarYear").classList.add("d-none");
  document.querySelector(".calendarMonth").classList.remove("d-none");
   
  // レポート画面レンダリング
  renderReportScreen();
}

function updateDetailsContainer() {
  // JSONのデータからメンテナンス後の運転時間を算出⇒ JSONへセット
  calculateAndSetMaintenanceHours();
  // メンテナンス後の運転時間を更新
  updateOperatingHours();
  // 最後にメンテンナスした日を更新
  updateLastMaintenanceDate();
  // グラフを更新
  updateMaintenanceHoursGraph();
}

// JSONのデータからメンテナンス後の運転時間を算出⇒ JSONへセット
function calculateAndSetMaintenanceHours() {
  const start = getJsonValue('lastMaintenanceDate');
  const today = getJsonValue('todayDate');

  // Date へ変換（month は 0始まりなので -1 する）
  const startDate = new Date(start.year, start.month - 1, start.day);
  const todayDate = new Date(today.year, today.month - 1, today.day);

  const h = getOperationHoursBetween(startDate, todayDate);
  const totalHours = Math.round(h);
  setJsonValue('operatingHoursAfterMaintenance', totalHours); 
}

// 判定｜年カレンダー｜最終メンテナンス月から当月までを活性化、他は非活性化
// targetDate = 判定対象日
// startDate  = 最終メンテナンス月
// todayDate  = 当月
function isWithinRange(n) {
  const startYearMonth =
    Number(calendarState.lastMaintenanceDate.year) * 12 +
    Number(calendarState.lastMaintenanceDate.month);
  const targetYearMonth =
    Number(calendarState.displayYear) * 12 + Number(n);
  const todayYearMonth =
    Number(calendarConfig.maxDate.year) * 12 +
    Number(calendarConfig.maxDate.month);

  // 本日より前月だけ活性化（仕様変更のため）
  // 元に戻す場合は下記コメントを外す　
  if (targetYearMonth <= todayYearMonth) {
  // if (targetYearMonth >= startYearMonth && targetYearMonth <= todayYearMonth) {
    return true;
  }
  return false;
}

// 判定｜月カレンダー｜最終メンテナンス日から当日までを活性化、他は非活性化
function isWithinDateRange(day) {
  const startDate = new Date(
    calendarState.lastMaintenanceDate.year,
    calendarState.lastMaintenanceDate.month - 1,
    calendarState.lastMaintenanceDate.day
  );

  const targetDate = new Date(
    calendarState.displayYear,
    calendarState.displayMonth - 1,
    day
  );

  // デモ用に2025年1月1日は最終メンテナンス日より前でも選択可能にする
  if (
    targetDate.getFullYear() === 2025 &&
    targetDate.getMonth() === 0 &&
    targetDate.getDate() === 1
  ) {
    return true;
  }

  const todayDate = new Date(
    calendarConfig.maxDate.year,
    calendarConfig.maxDate.month - 1,
    calendarConfig.maxDate.day
  );

  // 本日より前日だけ活性化（仕様変更のため）
  // 元に戻す場合は下記コメントを外す　
  return targetDate <= todayDate;
  // return targetDate >= startDate && targetDate <= todayDate;
}

// カレンダー表示を切り替える
function switchCalenderMode() {
    if (calendarState.mode === "month") {
      document.querySelector('.calendarMonth').classList.add('d-none');
      renderYearCalendar();
      document.querySelector('.calendarYear').classList.remove('d-none');
      document.querySelector('.arrow-set').classList.add('d-none');
      document.querySelector('.js-calendar-arrow').classList.add('is-open');
      calendarState.mode = "year";
      isBtnDisable();
    } else {
      document.querySelector('.calendarYear').classList.add('d-none');
      renderMonthCalendar();
      document.querySelector('.calendarMonth').classList.remove('d-none');
      document.querySelector('.arrow-set').classList.remove('d-none');
      document.querySelector('.js-calendar-arrow').classList.remove('is-open');
      calendarState.mode = "month";
      isBtnDisable();
    }
}