# 残件
## 進捗（8/18）
- 次回はエアコン設定画面の「エアコンの設定変更」ボタンで表示されるモーダル


## トップ画面 睡眠設定 topSleepSettings
## トップ画面 レポート topReport
## エアコン設定画面 acSettings
## エアコンのこだわり画面 acCustomSettings
## おやすみ音楽設定画面 sleepMusicSettings
## メニュー画面

- top-sleep-settings
- top-report
- ac-settings
- ac-custom-settings
- sleep-music-settings

## 作成する画面
- [x] トップ画面 睡眠設定
- [x] トップ画面 レポート
- [x] エアコン設定画面
- [x] エアコンのこだわり画面
- [x] おやすみ音楽設定画面
- [x] メニュー画面

## memo
- 紫カラー #967AEB
- 薄い黒カラー #1C1B1B

## ヘッダーを作成する
- [] トップ画面 睡眠設定
- [] トップ画面 レポート
- [] エアコン設定画面
- [] エアコンのこだわり画面
- [] おやすみ音楽設定画面
- [] メニュー画面

## 学習したこと
- 親子階層の要素を一度に取得
- document.querySelector('.content-alert .bg-black')


