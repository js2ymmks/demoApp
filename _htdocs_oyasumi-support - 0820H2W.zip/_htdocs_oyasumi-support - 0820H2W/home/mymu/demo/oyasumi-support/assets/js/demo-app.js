﻿/******************************************
 * テンプレートファイル読み込み
 ******************************************/
document.addEventListener("DOMContentLoaded", async () => {
  try {
    const [alert, header, footer, modal, drawer] = await Promise.all([
      fetch("../partials/alert.txt").then((r) => r.text()),
      fetch("../partials/header.txt").then((r) => r.text()),
      fetch("../partials/footer.txt").then((r) => r.text()),
      fetch("../partials/modal.txt").then((r) => r.text()),
      fetch("../partials/drawer-menu.txt").then((r) => r.text()),

      // 本番環境では下記を使用する
      // fetch("/home/mymu/demo/mymu/partials/alert.txt").then((r) => r.text()),
      // fetch("/home/mymu/demo/mymu/partials/header.txt").then((r) => r.text()),
      // fetch("/home/mymu/demo/mymu/partials/footer.txt").then((r) => r.text()),
      // fetch("/home/mymu/demo/mymu/partials/modal.txt").then((r) => r.text()),
      // fetch("/home/mymu/demo/mymu/partials/drawer-menu.txt").then((r) => r.text()),
    ]);

    document.querySelector(".content-alert").innerHTML = alert;
    document.querySelector(".content-header").innerHTML = header;
    document.querySelector(".content-footer").innerHTML = footer;
    document.querySelector(".content-modal").innerHTML = modal;
    document.querySelector(".content-drawer").innerHTML = drawer;
    initUI();
  } catch (err) {
    console.error("Failed to load partials:", err);
  }
});

/******************************************
 * ユーティリティ：JSON取得（ブラケット版）
 ******************************************/
const getJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("appDataEdit");
  let data;
  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }
  if (!data) return undefined;
  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");
  const props = normalizedPath.split(".");
  let current = data;
  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }
  return current;
};

/******************************************
 * ユーティリティ：JSON更新（ブラケット版）
 ******************************************/
const setJsonValue = (propertyPath, value) => {
  const storedJson = sessionStorage.getItem("appDataEdit");
  let data;
  try {
    data = storedJson ? JSON.parse(storedJson) : {};
  } catch (e) {
    data = {};
  }
  // ブラケット記法をドット記法に変換
  // "buttons[0].label" → "buttons.0.label"
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");
  const props = normalizedPath.split(".");
  let current = data;
  for (let i = 0; i < props.length - 1; i++) {
    const prop = props[i];
    // 数字 → 配列アクセス
    const index = Number(prop);
    const isIndex = !isNaN(index);
    if (isIndex) {
      if (!Array.isArray(current)) {
        current = [];
      }
      if (current[index] === undefined) {
        current[index] = {};
      }
      current = current[index];
    } else {
      if (!current[prop] || typeof current[prop] !== "object") {
        current[prop] = {};
      }
      current = current[prop];
    }
  }
  // 最終プロパティ
  const lastProp = props[props.length - 1];
  const lastIndex = Number(lastProp);
  if (!isNaN(lastIndex)) {
    if (!Array.isArray(current)) current = [];
    current[lastIndex] = value;
  } else {
    current[lastProp] = value;
  }
  sessionStorage.setItem("appDataEdit", JSON.stringify(data));
};

/******************************************
 * ユーティリティ：JSON取得（ブラケット版）ヘッダー用
 ******************************************/
const getHeaderJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("headerSet");
  let data;
  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }
  if (!data) return undefined;
  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");
  const props = normalizedPath.split(".");
  let current = data;
  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }
  return current;
};

/******************************************
 * ユーティリティ
 ******************************************/
// モーダルを閉じたときにフォーカスを外す
window.addEventListener("hide.bs.modal", () => {
  document.activeElement.blur();
});

/******************************************
 * ユーティリティ：JSONの変更検知
 ******************************************/
function isJsonChanged() {
  const entryId = getJsonValue("entryId");
  const originalStr = sessionStorage.getItem("appData");
  const editingStr = sessionStorage.getItem("appDataEdit");
  if (!originalStr || !editingStr) return false;
  const original = JSON.parse(originalStr);
  const editing = JSON.parse(editingStr);
  const originalData = original[entryId];
  const editingData = editing[entryId];
  const isChanged =
    JSON.stringify(originalData) !== JSON.stringify(editingData);
  return isChanged;
}

/******************************************
 * ユーティリティ：ヘッダーのアイテムを設定する
 ******************************************/
function initHeader() {
  // ==============================
  // DOM取得
  // ==============================
  const headerDom = {
    leftBtn: document.getElementById("headerLeftBtn"),
    title: document.getElementById("headerTitle"),
    rightBtn: document.getElementById("headerRightBtn"),
  };

  if (!headerDom.leftBtn || !headerDom.title || !headerDom.rightBtn) {
    console.warn("header DOM がまだ準備できていません");
    return;
  }

  // ==============================
  // headerSetBodyKeyキー取得
  // ==============================
  const currentHeaderSetKey = document.body.dataset.appHeaderSet;
  if (!currentHeaderSetKey) {
    console.warn("data-app-header-set が指定されていません");
    return;
  }

  // ==============================
  // headerSetJson 取得
  // ==============================
  const headerSetJson = getHeaderJsonValue(`${currentHeaderSetKey}`);
  if (!headerSetJson) {
    console.warn(`headerSet.${currentHeaderSetKey} が見つかりません`);
    return;
  }

  // ==============================
  // タイトル
  // ==============================
  headerDom.title.innerHTML = headerSetJson.title;

  // ==============================
  // 左ボタン
  // ==============================
  renderLeftButton(headerSetJson.left?.type, headerDom.leftBtn);
  headerDom.leftBtn.onclick = () =>
    handleHeaderLeftAction(headerSetJson.left?.type);

  // ==============================
  // 右ボタン
  // ==============================
  renderRightButton(headerSetJson.right, headerDom.rightBtn);
  headerDom.rightBtn.onclick = () =>
    handleHeaderRightAction(headerSetJson.right?.action);
}

function initUI() {
  initFooterButtons();
  initFooterButtonsState();
  initHeader();
  bindScheduleTimeModal();
}

function bindScheduleTimeModal() {
  const modalEl = document.getElementById("scheduleTimeModal");
  if (!modalEl) return;
  if (modalEl.dataset.boundScheduleTimeModal === "1") return;
  modalEl.dataset.boundScheduleTimeModal = "1";

  modalEl.addEventListener("show.bs.modal", () => {
    const entryId = getJsonValue("entryId");
    renderScheduleTimeModal(entryId);
  });
}

// ==============================
// 左ボタン描画
// ==============================
// リセット
function renderLeftButton(type, btn) {
  btn.innerHTML = "";
  btn.classList.remove("d-none");
  // アイコン設定
  switch (type) {
    case "back":
      btn.innerHTML = '<i class="bi bi-chevron-left" style="color: white; font-size: 24px"></i>';
      break;
    case "backToMyMUPlusScreen":
      btn.innerHTML = '<div class="d-flex align-items-center gap-2"><img src="../assets/img/chevron-back.svg"><img src="../assets/img/icon_MyMUHeader.svg"></div>';
      break;
    case "drawer":
      btn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"><rect x="1" y="2" width="18" height="2.5" rx="1.25" fill="black"/><rect x="1" y="9" width="18" height="2.5" rx="1.25" fill="black"/><rect x="1" y="16" width="18" height="2.5" rx="1.25" fill="black"/></svg>';
      break;
    case "backToSelectDeviceScreen":
      btn.innerHTML = '<i class="bi bi-chevron-left"></i>';
      break;
    default:
      btn.classList.add("d-none");
  }
}

// ==============================
// 左アクション処理
// ==============================
function handleHeaderLeftAction(type) {
  switch (type) {
    case "backToMyMUPlusScreen":
      window.location.href = "../mymu-plus/";
      break;
    case "backToSelectDeviceScreen":
      window.location.href = "../select-device/";
      break;
    case "drawer":
      const bsOffcanvas = new bootstrap.Offcanvas("#appOffcanvas");
      bsOffcanvas.show();
      break;
  }
}

// ==============================
// 右ボタン描画　headerTitle
// ==============================
function renderRightButton(headerSetJsonRight, headerDomRight) {
  // 右ボタンのプロパティチェック
  if (!headerSetJsonRight || !headerSetJsonRight.visible) {
    headerDomRight.classList.add("d-none");
    headerDomRight.onclick = null;
    return;
  }
  // 表示
  headerDomRight.classList.remove("d-none");
  // text / icon / svg すべて対応
  headerDomRight.innerHTML = headerSetJsonRight.text || "";
  if (headerSetJsonRight.action === "drawer") {
    headerDomRight.disabled = false;
    headerDomRight.classList.remove("disabled");
    headerDomRight.classList.remove("js-complete-btn");
    headerDomRight.setAttribute("aria-disabled", "false");
  }
  
  // クリック処理（あれば）
  headerDomRight.onclick = () => {
    handleHeaderRightAction(headerSetJsonRight.action, headerSetJsonRight);
  };
}

// ==============================
// 右アクション処理（）
// ==============================
function handleHeaderRightAction(action) {
  switch (action) {
    // メニュー表示
    case "drawer":
      const bsOffcanvas = new bootstrap.Offcanvas("#appOffcanvas");
      bsOffcanvas.show();
      break;

    // アラート表示
    case "alert":
      alert(
        "デモアプリではこのボタンは操作できません。＜ ボタンで戻ってください",
      );
      break;

    // MyMUボタン
    case "mymu":
      const headerEl = document.querySelector(".app-header");
      headerEl.addEventListener("click", (e) => {
        const btn = e.target.closest("#headerRightBtn");
        if (!btn) return;
        alert("デモアプリではこのボタンは操作できません。");
      });
      break;
    // シーン
    case "":
      break;
  }
}

/******************************************
 * ユーティリティ：モーダル表示
 ******************************************/
function showModal(modalId) {
  const modalEl = document.getElementById(modalId);
  if (!modalEl) return;

  const modal = new bootstrap.Modal(modalEl);
  modal.show();
}

/******************************************
 * イニシャライズ：フッター
 ******************************************/
const initFooterButtons = () => {
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const currentHeaderSetKey = document.body.dataset.appHeaderSet;
      // MyMU＋アイコンのみ処理する
      if (btn.dataset.appPage !== "mymuPlus") { return; }
      if (
        currentHeaderSetKey === "editAutomation" &&
        btn.dataset.appPage === "automation"
      ) {
        setJsonValue("navigationMode", "back");
      }
      setJsonValue("currentPage", btn.dataset.appPage);
    });
  });
};

/******************************************
 * レンダリング：フッターアイコン表示更新
 ******************************************/
const initFooterButtonsState = () => {
  // フッターが存在しない画面
  const footerElement = document.getElementsByClassName("content-footer")[0];
  if (footerElement.className.includes("d-none")) {
    return;
  }
  // スタイルリセット
  const currentPage = getJsonValue("currentPage");
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.classList.remove("active");
  });
  // レンダリング
  footerButtons.forEach((btn) => {
    const page = btn.dataset.appPage;
    if (page === currentPage) {
      btn.classList.add("active");
    }
  });
};

/******************************************
 * マスターデータ
 ******************************************/
// xxxx
const MASTER_xxxxx = {
}

/******************************************
 * State
 * 状態管理データ
 ******************************************/
let xxxxxx = {
};

/******************************************
 * クリックイベント
 ******************************************/
document.addEventListener("click", (e) => {
  const el = e.target;

  // MyMU＋画面｜ソリューションカード
  const appCardBtn = el.closest(".js-app-card");
  if (appCardBtn) {
    const mode = getJsonValue("screenMode");
    if (mode === "settings") {
      window.location.href = "../top-sleep-settings/";
    } else {
      window.location.href = "../top-report/";
    }
  }

  // トップ画面（睡眠設定）｜エアコン設定画面へ遷移js-ac-setting-type
  const acSettingsBtn = el.closest(".js-ac-settings-btn");
  if (acSettingsBtn) {
    window.location.href = "../ac-settings/";
  }

  // エアコン設定画面｜エアコン設定変更モーダルへ遷移
  const selectSettingTypeBtn = el.closest(".js-select-setting-type-btn");
  if (selectSettingTypeBtn) {
    showModal('selectAcSetupMethod');
  }
  
// ↑ クリックイベントの処理はここまで
});

/******************************************
 * レンダリング｜レポート画面
 * 各画面ごとのレンダリング処理
 ******************************************/
// MyMU＋画面｜ヘッダー部の注記の色をMyMUと同じカラーにする
function renderMymuPlusScreen() {
  const elm = document.querySelector('.content-alert .bg-black')
  elm.classList.add('alert');
  elm.classList.replace('bg-black', 'alert-primary');
}


/******************************************
 * レンダリング
 ******************************************/
// エアコン設定画面
function renderAcSettingsScreen() {

} 


// ↑ イベントデレゲーションここまで

