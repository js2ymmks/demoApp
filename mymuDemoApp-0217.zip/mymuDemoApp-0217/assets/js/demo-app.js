/******************************************
 * テンプレートファイル読み込み
 ******************************************/
document.addEventListener("DOMContentLoaded", async () => {
  try {
    const [alert, header, footer, modal, drawer] = await Promise.all([
      fetch("../../partials/alert.txt").then((r) => r.text()),
      fetch("../../partials/header.txt").then((r) => r.text()),
      fetch("../../partials/footer.txt").then((r) => r.text()),
      fetch("../../partials/modal.txt").then((r) => r.text()),
      fetch("../../partials/drawer-menu.txt").then((r) => r.text()),
    ]);

    document.querySelector(".content-alert").innerHTML = alert;
    document.querySelector(".content-header").innerHTML = header;
    document.querySelector(".content-footer").innerHTML = footer;
    document.querySelector(".content-modal").innerHTML = modal;
    document.querySelector(".content-drawer").innerHTML = drawer;
    initUI();
  } catch (err) {
    console.error("Failed to load partials:", err);
  }
});

function initUI() {
  // モーダル
  // initModalDriveModeSelectButtons();
  initFooterButtons();
  initFooterButtonsState();
  initHeader();
  // 基本機能 画面
  // renderDriveModeSwitchBtnAndSettingPanelOperation();
}

/******************************************
 * JSON取得（ブラケット版）
 ******************************************/
const getJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }

  if (!data) return undefined;

  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }

  return current;
};

/******************************************
 * JSON更新（ブラケット版）
 ******************************************/
const setJsonValue = (propertyPath, value) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : {};
  } catch (e) {
    data = {};
  }

  // ブラケット記法をドット記法に変換
  // "buttons[0].label" → "buttons.0.label"
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let i = 0; i < props.length - 1; i++) {
    const prop = props[i];

    // 数字 → 配列アクセス
    const index = Number(prop);
    const isIndex = !isNaN(index);

    if (isIndex) {
      if (!Array.isArray(current)) {
        current = [];
      }
      if (current[index] === undefined) {
        current[index] = {};
      }
      current = current[index];
    } else {
      if (!current[prop] || typeof current[prop] !== "object") {
        current[prop] = {};
      }
      current = current[prop];
    }
  }

  // 最終プロパティ
  const lastProp = props[props.length - 1];
  const lastIndex = Number(lastProp);

  if (!isNaN(lastIndex)) {
    if (!Array.isArray(current)) current = [];
    current[lastIndex] = value;
  } else {
    current[lastProp] = value;
  }

  // 確認用ログ
  sessionStorage.setItem("appData", JSON.stringify(data));
  // console.log(data.automation.items["auto-1"].actions[0]);
};

/******************************************
 * JSON取得（ブラケット版）ヘッダー用
 ******************************************/
const getHeaderJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("headerSet");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }

  if (!data) return undefined;

  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }

  return current;
};

/******************************************
 * JSON更新（ブラケット版）ヘッダー用
 ******************************************/
const setHeaderJsonValue = (propertyPath, value) => {
  const storedJson = sessionStorage.getItem("headerSet");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : {};
  } catch (e) {
    data = {};
  }

  // ブラケット記法をドット記法に変換
  // "buttons[0].label" → "buttons.0.label"
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let i = 0; i < props.length - 1; i++) {
    const prop = props[i];

    // 数字 → 配列アクセス
    const index = Number(prop);
    const isIndex = !isNaN(index);

    if (isIndex) {
      if (!Array.isArray(current)) {
        current = [];
      }
      if (current[index] === undefined) {
        current[index] = {};
      }
      current = current[index];
    } else {
      if (!current[prop] || typeof current[prop] !== "object") {
        current[prop] = {};
      }
      current = current[prop];
    }
  }

  // 最終プロパティ
  const lastProp = props[props.length - 1];
  const lastIndex = Number(lastProp);

  if (!isNaN(lastIndex)) {
    if (!Array.isArray(current)) current = [];
    current[lastIndex] = value;
  } else {
    current[lastProp] = value;
  }

  // 確認用ログ
  sessionStorage.setItem("headerSet", JSON.stringify(data));
  // console.log(data.automation.items["new"].triggers[0].days);
};


/******************************************
 * ユーティリティ：ヘッダーのアイテムを設定する
 * 対象：各画面のヘッダー
 * アクション：ヘッダー要素の初期化
 ******************************************/
function initHeader() {
  // ==============================
  // DOM取得
  // ==============================
  const headerDom = {
    leftBtn: document.getElementById("headerLeftBtn"),
    title: document.getElementById("headerTitle"),
    rightBtn: document.getElementById("headerRightBtn"),
  };

  if (!headerDom.leftBtn || !headerDom.title || !headerDom.rightBtn) {
    console.warn("header DOM がまだ準備できていません");
    return;
  }

  // ==============================
  // headerSetBodyKeyキー取得
  // ==============================
  const currentHeaderSetKey = document.body.dataset.appHeaderSet;
  if (!currentHeaderSetKey) {
    console.warn("data-app-header-set が指定されていません");
    return;
  }

  // ==============================
  // headerSetJson 取得
  // ==============================
  const headerSetJson = getHeaderJsonValue(`${currentHeaderSetKey}`);
  if (!headerSetJson) {
    console.warn(`headerSet.${currentHeaderSetKey} が見つかりません`);
    return;
  }

  // ==============================
  // タイトル
  // ==============================
  headerDom.title.innerHTML = headerSetJson.title;

  // ==============================
  // 左ボタン
  // ==============================
  renderLeftButton(headerSetJson.left?.type, headerDom.leftBtn);
  headerDom.leftBtn.onclick = () =>
    handleHeaderLeftAction(headerSetJson.left?.type);

  // ==============================
  // 右ボタン
  // ==============================
  renderRightButton(headerSetJson.right, headerDom.rightBtn);
  headerDom.rightBtn.onclick = () =>
    handleHeaderRightAction(headerSetJson.right?.action);
}

// ==============================
// 左ボタン描画
// ==============================
// リセット
function renderLeftButton(type, btn) {
  btn.innerHTML = "";
  btn.classList.remove("d-none");
  // アイコン設定
  switch (type) {
    case "back":
      btn.innerHTML = '<i class="bi bi-chevron-left"></i>';
      break;
    case "drawer":
      btn.innerHTML = '<i class="bi bi-list"></i>';
      break;
    default:
      btn.classList.add("d-none");
  }
}

// ==============================
// 左アクション処理
// ==============================
function handleHeaderLeftAction(type) {
  switch (type) {
    case "back":
      // document.addEventListener("DOMContentLoaded", syncToggleFromStorage);
      // window.addEventListener("pageshow", syncToggleFromStorage);
      window.history.back();
      break;

    case "drawer":
      const bsOffcanvas = new bootstrap.Offcanvas("#appOffcanvas");
      bsOffcanvas.show();
      break;
  }
}

// ==============================
// 右ボタン描画
// ==============================
function renderRightButton(headerSetJsonRight, headerDomRight) {
  // 右ボタンのプロパティチェック
  if (!headerSetJsonRight || !headerSetJsonRight.visible) {
    headerDomRight.classList.add("d-none");
    headerDomRight.onclick = null;
    return;
  }

  // 表示
  headerDomRight.classList.remove("d-none");

  // text / icon / svg すべて対応
  headerDomRight.innerHTML = headerSetJsonRight.text || "";

  // クリック処理（あれば）
  headerDomRight.onclick = () => {
    handleHeaderRightAction(headerSetJsonRight.action, headerSetJsonRight);
  };
}

// ==============================
// 右アクション処理（完了/done | 設定/set | リンク/link | 編集/edit | 決定/ok）
// ==============================
function handleHeaderRightAction(action) {
  switch (action) {
    // JSON更新後、前の画面へ戻る
    case "done":
      window.history.back();
      break;

    // 電気代チェック画面へ遷移
    case "set":
      window.history.back();
      break;

    // 指定リンクへ遷移
    case "link":
      const rightBtn = document.getElementById("headerRightBtn");
      const target = getJsonValue(
        "headerSet.electricityBillCheck.right.target",
      );
      if (rightBtn) {
        rightBtn.href = target;
      }
      break;

    // 現在の画面が編集可能になるtouch-airflow-back
    case "edit":
      window.history.back();
      break;

    // タッチ気流、窓位置設定のポインターがロックされる
    case "ok":
      window.history.back();
      break;

    // アラート表示schedule-done
    case "alert":
      alert(
        "デモアプリではこのボタンは操作できません。＜ ボタンで戻ってください",
      );
      break;

    // スケジュール画面で完了
    case "schedule-done":
      setJsonValue("isAutoMationSetDone", true);
      window.location.href = "../schedule/";
      break;

    // アラート表示
    case "touch-airflow-back":
      alert(
        "風向を設定しました。やり直す場合は画像をダブルタップしてください。",
      );
      break;
  }
}

/******************************************
 * イニシャライズ：フッター
 * 対象：フッターのアイコン
 * アクション：JSON更新(currentPage)
 ******************************************/
const initFooterButtons = () => {
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      setJsonValue("currentPage", btn.dataset.appPage);
    });
  });
};

/******************************************
 * レンダリング：フッターアイコン表示更新
 * 対象：フッターのアイコン
 * アクション：アクティブページのフッターアイコンの表示更新
 ******************************************/
const initFooterButtonsState = () => {
  // フッターが存在しない画面
  const footerElement = document.getElementsByClassName("content-footer")[0];
  if (footerElement.className.includes("d-none")) {
    return;
  }
  // スタイルリセット
  const currentPage = getJsonValue("currentPage");
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.classList.remove("active");
  });
  // レンダリング
  footerButtons.forEach((btn) => {
    const page = btn.dataset.appPage;
    if (page === currentPage) {
      btn.classList.add("active");
    }
  });
};

/******************************************
 * ユーティリティ：全画面
 * 対象：トグルスイッチ（button要素内にあるスイッチ）
 * アクション：クリック時の伝播を防ぐ
 ******************************************/
document.querySelectorAll(".form-check-input").forEach((toggle) => {
  toggle.addEventListener("click", (e) => {
    e.stopPropagation();
  });
});

/******************************************
 * ユーティリティ：全画面
 * 対象：button要素、スイッチ要素
 * アクション：「デモアプリではこのボタンは操作できません。」を表示する
 ******************************************/
document.addEventListener("click", (e) => {
  const target = e.target.closest(".demo-toggle-alert");
  if (!target) return;

  // 現在の状態を保持（クリック後の状態）
  const currentChecked = target.checked;
  e.stopPropagation();

  alert("デモアプリではこのボタンは操作できません。");

  // 元の状態に戻す
  target.checked = !currentChecked;
});

/******************************************
 * マッピングオブジェクト
 ******************************************/
// 機器名、アイコンマスター
const DEVICE_MASTER = {
  "rac-1": {
    label: "リビングのエアコン",
    icon: "../assets/img/icon_AC_40pt.svg",
    settings: "../device-settings-rac/",
  },
  "rac-2": {
    label: "寝室のエアコン",
    icon: "../assets/img/icon_AC_40pt.svg",
    settings: "../device-settings-rac/",
  },
  "eq": {
    label: "給湯機",
    icon: "../assets/img/product_Icon_EQ_40pt.svg",
    settings: "../device-settings-eq/",
  },
};

// 製品カテゴリマスター
const CATEGORY_MASTER = {
  "rac-1": "rac",
  "rac-2": "rac",
  "eq": "eq",
};

// トリガーイベント条件
const TRIGGER_EVENT_DESCRIPTION_MASTER = {
  "schedule": "設定した時刻に指定されたアクションを実行します。繰り返し設定を行わない場合、１度だけ指定されたアクションを実行します。",
  "location": "選択された家電シェアユーザーのうちの1名以上が位置条件を満たした場合に、指定されたアクションを実行します。",
  "devices": "機器の運転状態を元に、指定されたアクションを実行します。トリガーイベントとして指定できる機器の運転状態は1つです。",
};

// トリガーイベントセクション表示／非表示
const TRIGGER_EVENT_SECTION_MASTER = {
  "schedule": "schedule-section",
  "location": "location-section",
  "devices": "devices-section",
}

/******************************************
 * オートメーション編集 画面
 ******************************************/
// オートメーション編集画面
const renderAutomationEditing = () => {
  const entryAutoId = getJsonValue("entryId");
  const entryTrigger = getJsonValue(`${entryAutoId}.entryTrigger`);

  renderAutomationName(entryAutoId);       // オートメーション名
  setActiveTriggerEvent(entryTrigger);     // トリガーイベントボタン
  renderTriggerSection(entryTrigger);      // トリガーイベント条件
  renderScheduleStartTime(entryAutoId);    // 時間
  renderScheduleDays(entryAutoId);         // 曜日（繰り返し）
  renderScheduleDescription(entryAutoId);  // 曜日説明文
  renderTriggerEventSection(entryTrigger); // トリガーイベントセクションの表示／非表示
  renderLocationUsers(entryAutoId);        // 通知するユーザー（家電シェアユーザー）
  renderLocationCondition(entryAutoId);    // 位置条件
  renderDeviceTrigger(entryAutoId);        // 機器の状態を追加で生成されるカードボタン
  // アクション
}

// オートメーション名
const renderAutomationName = (entryAutoId) => {
  const el = document.getElementById("autoName");
  const automationName = getJsonValue(`${entryAutoId}.name`);

  if (!el) return;
  const name = automationName?.trim();
  if (name) {
    el.textContent = name;
  } else {
    el.textContent = "オートメーション名（未設定）";
  }
};

// トリガーイベントボタンの状態
const setActiveTriggerEvent = (entryTrigger) => {
  const targetElements = document.querySelectorAll(".js-trigger-event");
  targetElements.forEach((el) => {
    const key = el.dataset.appKey;
    if (key === entryTrigger) {
      el.classList.add("active");
      el.setAttribute("aria-pressed", "true");
    } else {
      el.classList.remove("active");
      el.setAttribute("aria-pressed", "false");
    }
  });
};

// トリガーイベントセクションの表示制御
const renderTriggerSection = (entryTrigger) => {
  const targetElement = document.querySelector(".trigger-section");
  targetElement.innerText = TRIGGER_EVENT_DESCRIPTION_MASTER[entryTrigger];
};

// 時間を代入
const renderScheduleStartTime = (entryAutoId) => {
  const el = document.getElementById("autoStartTime");
  const automationTime = getJsonValue(`${entryAutoId}.triggers.schedule.time`);
  if (!el) return;
  const time = automationTime?.trim();
  if (time) {
    el.textContent = time;
  } else {
    el.textContent = "開始時間（未設定）";
  }
};

// 曜日を代入
const renderScheduleDays = (entryAutoId) => {
  const targetElements = document.querySelectorAll(".day-of-the-week");
  if (!targetElements.length) return;

  // schedule.days を安全に取得
  const days = getJsonValue(`${entryAutoId}.triggers.schedule.days`) ?? [];

  targetElements.forEach((el) => {
    const day = el.dataset.appScheduleDay;
    const isActive = days.includes(day);

    el.classList.toggle("active", isActive);
    el.setAttribute("aria-pressed", String(isActive));
  });
};

  // 曜日説明文を代入
const renderScheduleDescription = (entryAutoId) => {
  const updateScheduleDescription = (days) => {
    const allDays = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
    const dayNames = {
      sun: "日",
      mon: "月",
      tue: "火",
      wed: "水",
      thu: "木",
      fri: "金",
      sat: "土",
    };

    let description = "";
    if (days.length === 0) {
      // 何も選択されていない：一度だけ実行
      description = "一度だけ実行します";
    } else if (days.length === 7) {
      // 全て選択：毎日実行
      description = "毎日実行します";
    } else {
      // 一部選択：選択された曜日に実行
      const selectedDayNames = days
        .sort((a, b) => allDays.indexOf(a) - allDays.indexOf(b))
        .map((day) => dayNames[day])
        .join("");
      description = `毎週${selectedDayNames}曜日に実行します`;
    }
    // 説明文を表示する要素を探して更新
    const descriptionElement = document.getElementById("scheduleText");
    if (descriptionElement) {
      descriptionElement.textContent = description;
    }
  };

  const scheduleTrigger = getJsonValue(`${entryAutoId}.triggers.schedule`);

  if (!scheduleTrigger) return;
  const days = scheduleTrigger.days ?? [];
  updateScheduleDescription(days);
};

// トリガーイベントセクションの表示／非表示
const renderTriggerEventSection = (entryTrigger) => {
  const key = TRIGGER_EVENT_SECTION_MASTER[entryTrigger];
  document.querySelector(`.${key}`).style.display = "block";
}

// 通知するユーザー（家電シェアユーザー）のチェックボックスを選択する
const renderLocationUsers = (entryAutoId) => {
  // location-section 内の checkbox を取得
  const checkboxes = document.querySelectorAll(
    '.location-section input[type="checkbox"]'
  );

  if (!checkboxes.length) return;

  // location trigger を取得
  const locationTrigger = getJsonValue(`${entryAutoId}.triggers.location`);
  if (!locationTrigger) return;

  const selectedUsers = locationTrigger.users || [];

  checkboxes.forEach((checkbox) => {
    const userName = checkbox.value;

    // JSON に含まれていればチェックON
    checkbox.checked = selectedUsers.includes(userName);
  });
};

// 位置条件のイベントを代入
const renderLocationCondition = (entryAutoId) => {

  const selectedCondition = getJsonValue(
    `${entryAutoId}.triggers.location.event`
  );

  // UI更新用の関数
  function updateLocationConditionUI(conditionValue) {

    const targetElements = document.querySelectorAll(".js-location-condition");

    targetElements.forEach((el) => {
      const condition = el.dataset.appLocationCondition;

      if (condition === conditionValue) {
        el.setAttribute("aria-pressed", "true");
        el.classList.add("active");
      } else {
        el.setAttribute("aria-pressed", "false");
        el.classList.remove("active");
      }
    });
  }

  updateLocationConditionUI(selectedCondition);
};

  // 機器の状態を追加で生成されるカードボタン
const renderDeviceTrigger = (entryAutoId) => {
  const trigger = getJsonValue(`${entryAutoId}.triggers.devices`);
  if (!trigger) return;

  // テンプレート（非表示のまま）
  const template = document.getElementById("roomTemperatureThresholdButton");
  if (!template) return;
  // 表示先コンテナ（親）
  const parent = template.parentElement;
  if (!parent) return;
  // 既存の生成済みボタンを削除（テンプレ除外）
  parent
    .querySelectorAll(
      ".trigger-section:not(#roomTemperatureThresholdButton)",
    )
    .forEach((el) => el.remove());

  // クローンを作成
  const button = template.cloneNode(true);
  button.removeAttribute("id");
  button.style.display = ""; // 作成後は表示にする

  const nameEl = button.querySelector(".name");
  const descEl = button.querySelector(".description");
  const tempEl = button.querySelector(".temperature");
  const imgEl = button.querySelector("img");
  const device = getDeviceInfo(trigger.id);
  // 機器名
  if (nameEl) nameEl.textContent = device.label;
  // 条件文
  if (descEl) descEl.textContent = trigger.condition ?? "";
  // 温度
  if (tempEl && trigger.threshold != null) {
    tempEl.textContent = `温度${trigger.threshold}℃`;
  }
  // アイコン
  if (imgEl) imgEl.src = device.icon;
  // deviceId を保持（遷移用）
  button.dataset.deviceId = trigger.id;
  parent.appendChild(button);
};



const initAutomationEditing = () => {
}





const setupAutomationEditing = () => {
  renderAutomationEditing();
  initAutomationEditing();
}


const updateAutomationEditing = () => {
  renderAutomationEditing();
}

// トリガーイベント内の処理
// イニシャライズ：トリガーイベントボタン
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".js-trigger-event");
  if (!btn) return;
  const key =btn.dataset.appKey;
  const entryAutoId = getJsonValue("entryId");
  setJsonValue(`${entryAutoId}.entryTrigger`, key)
  renderAutomationEditing();
});



// アクションセクション内の処理
// イニシャライズ：アクション内のカードボタン（シーン／機器操作／通知 を追加）
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".js-trigger-section");
  if (!btn) return;
  const section = btn.dataset.appAction;

  if (section === "scene") {
    window.location.href = "../select-scene/";
  } else if (section === "devices") {
    window.location.href = "../select-device/";
  } else if (section === "notify") {
    window.location.href = "../select-notice/";
  }
});


/******************************************
 * オートメーション 画面
 ******************************************/
// エントリー用のオートメーションIDをJSONに保存、編集画面へ遷移する
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".js-automation-id");
  if (!btn) return;

  const key = btn.dataset.appKey;
  setJsonValue("entryId", key);
  window.location.href = "../edit-automation/";
});









    // 機器情報取得
  const getDeviceInfo = (deviceId) => {
    const roomTemperatureThresholdButton = document.getElementById(
      "roomTemperatureThresholdButton",
    );
    if (roomTemperatureThresholdButton) {
      roomTemperatureThresholdButton.style.display = "none";
    }
    return (
      DEVICE_MASTER[deviceId] ?? {
        label: "不明な機器",
        icon: "../assets/img/icon_AC_40pt.svg",
      }
    );
  };


  
// オートメーション編集画面のレンダリング
const renderEditAutomationScreen = () => {
  // 変数をセット（オートメーションID、初期表示トリガーイベント）
  const entryId = getJsonValue("entryId");
  const entryTrigger =  getJsonValue(`${entryId}.entryTrigger`);






  // アクションボタンからのリンク
  const goToDeviceSettings = (deviceId) => {
    const device = DEVICE_MASTER[deviceId];
    if (!device) return;

    window.location.href = device.settings;
  };    


  // アクションを描画
  const renderActions = (entryId) => {
    const actions = getJsonValue(`${entryId}.actions`) ?? [];

    const container = document.getElementById("actionButtonsContainer");
    const template = document.getElementById("actionTemplate");
    if (!container || !template) return;

    const getDeviceDescription = (action) => {
      if (action.drive === "off") return "運転停止";

      if (action.drive === "on") {
        if (action.mode && action.temp) {
          return `${action.mode} ${action.temp}℃`;
        }
        return "運転開始";
      }

      return "";
    };

    // アクション用変換表（冷房／暖房）
    const ACTION_TEMP_RULES = {
      冷房: {
        condition: "above", // 以上
        thresholdText: (v) => `室温${v}℃以上`,
        actionText: (v) => `冷房${v}℃運転`,
      },
      暖房: {
        condition: "below", // 以下
        thresholdText: (v) => `室温${v}℃以下`,
        actionText: (v) => `暖房${v}℃運転`,
      },
    };

    // JSON → 表示用テキストへ変換する関数
    const buildActionTemperatureText = (action) => {
      const { drive, mode, threshold, temp } = action;

      // 運転停止
      if (drive === "off") {
        return "運転停止";
      }

      // 運転ONで threshold がある場合（温度条件付き）
      if (drive === "on" && mode && threshold != null && temp != null) {
        const rule = ACTION_TEMP_RULES[mode];
        if (!rule) return "";

        return `${rule.thresholdText(threshold)}で${rule.actionText(temp)}`;
      }

      // 運転ONで threshold がない場合（通常運転）
      if (drive === "on" && mode && temp != null) {
        // return `運転開始　${mode}　${temp.toFixed(1)}℃`;
        return `運転開始　${mode}　${temp}℃`;
      }

      return "";
    };

    const setActionButtonContent = (button, action) => {
      const nameEl = button.querySelector(".name");
      const descEl = button.querySelector(".description");
      const tempEl = button.querySelector(".temperature");
      const imgEl = button.querySelector(".source");

      if (!nameEl || !descEl || !tempEl || !imgEl) return;

      if (action.type === "devices") {
        const device = getDeviceInfo(action.id);

        button.dataset.deviceId = action.id;
        nameEl.textContent = device.label;

        // 給湯機（eq）の場合
        if (action.id === "eq") {
          if (action.drive === "on") {
            descEl.textContent = "ふろ自動開始";
          } else if (action.drive === "off") {
            descEl.textContent = "ふろ自動停止";
          } else {
            descEl.textContent = "";
          }
        }
        // エアコン（rac-*）の場合
        else {
          descEl.textContent = buildActionTemperatureText(action);
        }

        tempEl.textContent = "";
        imgEl.src = device.icon;
      }


      if (action.type === "notify") {
        const device = getDeviceInfo(action.id);
        // nameEl.textContent = "通知";
        nameEl.textContent = device.label;
        descEl.textContent = action.target ?? "";
        tempEl.textContent = action.message ?? "";
        imgEl.src = "../assets/img/icon_Notifications_40.svg";
      }
    };

    // 既存削除（テンプレ除外）
    container
      .querySelectorAll("button:not(#actionTemplate)")
      .forEach((el) => el.remove());

    // 描画
    actions.forEach((action) => {
      const button = template.cloneNode(true);
      button.removeAttribute("id");
      button.style.display = "";

      setActionButtonContent(button, action);
  if (action.type === "devices") {
    button.addEventListener("click", () => {
      goToDeviceSettings(action.id);
    });
  }

      container.appendChild(button);
    });
  };

const initScheduleDayButtons = () => {
  const buttons = document.querySelectorAll(".day-of-the-week");
  if (!buttons.length) return;

  buttons.forEach((button) => {
    button.addEventListener("click", () => {
      const entryId = getJsonValue("entryId");
      const day = button.dataset.appScheduleDay;

      // 現在の days を取得
      const days =
        getJsonValue(`${entryId}.triggers.schedule.days`) ?? [];

      // ON / OFF を切り替え
      const index = days.indexOf(day);
      if (index === -1) {
        days.push(day);
      } else {
        days.splice(index, 1);
      }

      console.log(day);

      // JSON に反映
      setJsonValue(`${entryId}.triggers.schedule.days`, days);
      // appData[entryId].triggers.schedule.days = days;

      // 再描画（← ここが重要）
      renderScheduleDays(entryId);
      renderScheduleDescription(entryId);
    });
  });
};

  // 実行する関数
  renderDeviceTrigger(entryId);
  renderActions(entryId);
  initScheduleDayButtons();

  // トリガーイベントボタン クリック処理
    // initTriggerEventButtons();
};

// 描画は何度でもOK
renderEditAutomationScreen();

/******************************************
 * イニシャライズ：オートメーション 画面
 * 対象：＋ボタン
 * アクション：新規オートメーション画面へ遷移する
 ******************************************/
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".js-add-automation");
  if (!btn) return;
  window.location.href = "../proposal-automation/";
});



document.addEventListener("click", (e) => {
  const btn = e.target.closest(".js-device-id");
  if (!btn) return;

  const key = btn.dataset.deviceId;
  setJsonValue("currentDeviceId", key);
});


// エアコン設定画面のレンダリング
const deviceSettngsRac = () => {
  const entryId = getJsonValue("entryId"); // オートメーションID
  const currentDeviceId = getJsonValue("currentDeviceId"); // クリックした機器のID
  const actions = getJsonValue(`${entryId}.actions`); // オートメーションのアクション一覧（複数オブジェクト）
  const targetAction = actions.find(
    // クリックした機器IDと同じIDを持つアクションを探す
    (action) => action.id === currentDeviceId,
  );

  let deviceName = "";
  if (!targetAction) return;

  if (targetAction.name) {
    // actions に直接 name がある場合
    deviceName = targetAction.name; // 例: "リビングのエアコンをつける"
  } else if (targetAction.type === "devices") {
    const device = getDeviceInfo(targetAction.id); // device マスタから取得
    deviceName = device?.label ?? ""; // 例: "リビングのエアコン"
  }

  // 機器名を表示
  const nameEl = document.querySelector(".device-name");
  if (targetAction) {
    const device = getDeviceInfo(targetAction.id);
    nameEl.textContent = device?.label ?? "";
  }
  const driveButtons = document.querySelectorAll("[data-app-is-drive]");

  // 運転／停止の状態反映
  driveButtons.forEach((btn) => {
    const isDrive = btn.dataset.appIsDrive === "true";
    const isActive =
      (targetAction.drive === "on" && isDrive) ||
      (targetAction.drive !== "on" && !isDrive);
    btn.classList.toggle("active", isActive);
  });
  const modeButtons = document.querySelectorAll(".js-drive-mode");

  // モードの状態反映
  modeButtons.forEach((btn) => {
    const mode = btn.dataset.appMode;
    const isActive = mode === targetAction.mode;
    btn.classList.toggle("active", isActive);
  });
  const tempEl = document.getElementById("racSettingTemperature");

  // 設定温度の表示
  if (targetAction.temp != null) {
    tempEl.textContent = `${targetAction.temp}℃`;
  } else {
    tempEl.textContent = "";
  }

  document.addEventListener("click", (e) => {
    const driveBtn = e.target.closest(".js-rac-drive");
    if (!driveBtn) return;

    const drive = driveBtn.dataset.appDrive;
    setJsonValue(
      `${entryId}.actions.${actions.indexOf(targetAction)}.drive`,
      drive,
    );

    deviceSettngsRac();
  });

  document.addEventListener("click", (e) => {
    const modeBtn = e.target.closest(".js-drive-mode");
    if (!modeBtn) return;

    const mode = modeBtn.dataset.appMode;
    setJsonValue(
      `${entryId}.actions.${actions.indexOf(targetAction)}.mode`,
      mode,
    );

    deviceSettngsRac();
  });
};

  




// エアコン設定画面のレンダリング
const deviceSettngsEq = () => {
  const entryId = getJsonValue("entryId"); // オートメーションID
  const currentDeviceId = getJsonValue("currentDeviceId"); // クリックした機器のID
  const actions = getJsonValue(`${entryId}.actions`); // オートメーションのアクション一覧（複数オブジェクト）
  const targetAction = actions.find(
    // クリックした機器IDと同じIDを持つアクションを探す
    (action) => action.id === currentDeviceId,
  );

  let deviceName = "";
  if (!targetAction) return;

  if (targetAction.name) {
    // actions に直接 name がある場合
    deviceName = targetAction.name; // 例: "リビングのエアコンをつける"
  } else if (targetAction.type === "devices") {
    const device = getDeviceInfo(targetAction.id); // device マスタから取得
    deviceName = device?.label ?? ""; // 例: "リビングのエアコン"
  }

  // 機器名を表示
  const nameEl = document.querySelector(".device-name");
  if (targetAction) {
    const device = getDeviceInfo(targetAction.id);
    nameEl.textContent = device?.label ?? "";
  }
  const driveButtons = document.querySelectorAll("[data-app-is-drive]");

  // 運転／停止の状態反映
  driveButtons.forEach((btn) => {
    const isDrive = btn.dataset.appIsDrive === "true";
    const isActive =
      (targetAction.drive === "on" && isDrive) ||
      (targetAction.drive !== "on" && !isDrive);
    btn.classList.toggle("active", isActive);
  });
};



// オートメーションカードを作成する関数
function createAutomationCard(automation) {
  const template = document.querySelector(".js-automation-template");
  if (!template) return
  const card = template.cloneNode(true);

  card.removeAttribute("data-app-key");
  card.style.display = "";

  // automationId保持（あとで遷移に使う）
  card.dataset.automationId = automation.id;

  // -------------------
  // ① 名前
  // -------------------
  const nameEl = card.querySelector(".automationName");
  nameEl.textContent = automation.name;

  // -------------------
  // ② トリガー
  // -------------------
  const triggerIconEl = card.querySelector(".triggerIcon");
  const triggerConditionEl = card.querySelector(".triggerCondition");

  const triggerInfo = getTriggerInfo(automation.trigger);

  triggerIconEl.src = triggerInfo.icon;
  triggerConditionEl.textContent = triggerInfo.text;

  // -------------------
  // ③ アクションアイコン（最大5つ）
  // -------------------
  const actionContainer = card.querySelector(".actionIcon").parentElement;
  actionContainer.innerHTML = "";

  automation.actions.slice(0, 5).forEach(action => {
    const img = document.createElement("img");

    if (action.type === "devices") {
      const device = getDeviceInfo(action.id);
      img.src = device.icon;
    }

    img.className = "me-1";
    actionContainer.appendChild(img);
  });

  return card;
}

// トリガー内容を組み立てる関数
function getTriggerInfo(trigger) {
  if (!trigger) return { icon: "", text: "" };

  switch (trigger.type) {

    // -----------------
    // スケジュール
    // -----------------
    case "schedule":
      return {
        icon: "../assets/img/icon-clock.svg",
        text: `${trigger.time} ${trigger.days.join("・")}`
      };

    // -----------------
    // 位置情報
    // -----------------
    case "location":
      return {
        icon: "../assets/img/icon-location.svg",
        text: trigger.event === "enter"
          ? "自宅に近づいたとき"
          : "自宅から離れたとき"
      };

    // -----------------
    // 機器（室温）
    // -----------------
    case "devices":
      return {
        icon: "../assets/img/icon_AC_40pt.svg",
        text: trigger.condition === "above"
          ? `室温が${trigger.temp}℃を超えたとき`
          : `室温が${trigger.temp}℃を下回ったとき`
      };

    default:
      return { icon: "", text: "" };
  }
}

// 共通関数：機器の状態を選択 → 室温のしきい値設定 画面へ遷移
const goRoomTempStatus = (type) => {
  // over | under
  sessionStorage.setItem("roomTemperatureCondition", type);
  location.href = "../select-room-temperature-status/";
};

/******************************************
 * レンダリング：機器の状態を選択 画面
 * 対象：
 * アクション：JSONの値を読み取って、機器名称を表示する
 ******************************************/
const selectDeviceOperation = () => {

  const entryId = getJsonValue("entryId"); // オートメーションID
  if (!entryId) return;

  const deviceId = getJsonValue(`${entryId}.triggers.devices.id`);
  if (!deviceId) return;

  const device = DEVICE_MASTER[deviceId];
  if (!device) return;

  // 機器名を取得
  const nameEl = document.getElementById("deviceName");
  if (nameEl) {
    nameEl.textContent = device.label;
  }

  // アイコンも動的にする場合
  // const iconEl = document.getElementById("deviceIcon");
  // if (iconEl) {
  //   iconEl.src = device.icon;
  // }

};

/******************************************
 * レンダリング：室温のしきい値を設定 画面
 * 対象：
 * アクション：
 ******************************************/
const selectRoomTemperatureStatus = () => {
  const condition = sessionStorage.getItem("roomTemperatureCondition");

  const bodyEl = document.body;
  const overEl = document.getElementById("section-over");
  const underEl = document.getElementById("section-under");

  // 初期化（非表示）
  if (overEl) overEl.style.display = "none";
  if (underEl) underEl.style.display = "none";

  // 条件分岐
  if (condition === "over") {
    // 表示制御
    if (overEl) overEl.style.display = "block";

    // ヘッダー指定
    bodyEl.dataset.appHeaderSet = "selectRoomTemperatureStatusOver";
  }

  if (condition === "under") {
    // 表示制御
    if (underEl) underEl.style.display = "block";

    // ヘッダー指定
    bodyEl.dataset.appHeaderSet = "selectRoomTemperatureStatusUnder";
  }
};

// アクションのカードボタンからのリンク（機器の場合：マップ関数）
const DEVICE_ROUTE_MAP = {
  rac: "../select-device-operation/",   // エアコン
  eq: "../select-bath-operation/",      // 給湯機
};

// アクションのカードボタンからのリンク（シーンと通知の場合：マップ関数）
const ACTION_ROUTE_MAP = {
  notify: "../select-notice/",
  scene: "../edit-action-scene/", // 保留
};

const goToActionEdit = (action) => {
  let url = "";

  if (action.type === "devices") {
    url = DEVICE_ROUTE_MAP[action.id];
  } else {
    url = ACTION_ROUTE_MAP[action.type];
  }

  if (!url) return;

  // 編集対象を保存
  sessionStorage.setItem("editingAction", JSON.stringify(action));

  location.href = url;
};




  const initRacDriveButtons = () => {
    const btn = document.querySelectorAll(".js-rac-drive");
    if (!btn) return;
    const drive = btn.dataset.appDrive;
  };






// デモ用のオートメーションデータ
const container = document.getElementById("automationList");
const sampleAutomation = getJsonValue("new");

const automationData = {
    status: true,
    entryTrigger: "schedule",
    name: "オートメーションサンプル", // オートメーション名
    trigger: {
      type: "schedule", // schedule | location | devices
      time: "18:00",
      days: ["月", "火", "水"],
    },
    actions: [
      { type: "devices", id: "rac-1" },
      { type: "devices", id: "eq" },
    ],
};

document.addEventListener("DOMContentLoaded", () => {   
const card = createAutomationCard(automationData);
if (!card) return;
container.appendChild(card);
});

