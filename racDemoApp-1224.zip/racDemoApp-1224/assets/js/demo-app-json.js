const initialAppData = {
  "currentPage": "schedule", // 表示画面
  "currentMode": "cooling", // 運転モード（cooling, dehumidifying, heating, perflation, ai-auto-cooling, ai-auto-heating）
  "currentHeaderSet": "", // 
  // 運転モード選択ボタン状態, 温度・湿度・除湿表示
  "driveModeSelectBtn": {
    "cooling": {
      "label": "冷房",
      "icon": "../assets/img/home-icon-btn-cooling.svg",
      "style": "btn-cooling",
      "settingDisplay": "text-cooling"
    },
    "dehumidifying": {
      "label": "除湿",
      "icon": "../assets/img/home-icon-btn-dehumidification.svg",
      "style": "btn-dehumidifying",
      "settingDisplay": "text-dehumidifying"
    },
    "heating": {
      "label": "暖房",
      "icon": "../assets/img/home-icon-btn-heating.svg",
      "style": "btn-heating",
      "settingDisplay": "text-heating"
    },
    "perflation": {
      "label": "送風",
      "icon": "../assets/img/home-icon-btn-perflation.svg",
      "style": "btn-perflation",
      "settingDisplay": "text-perflation"
    },
    "ai-auto-cooling": {
      "label": "A.I.自動(冷房)",
      "icon": "../assets/img/home-icon-btn-ai-auto.svg",
      "style": "btn-ai-auto",
      "settingDisplay": "text-ai-auto"
    },
    "ai-auto-heating": {
      "label": "A.I.自動(暖房)",
      "icon": "../assets/img/home-icon-btn-ai-auto.svg",
      "style": "btn-ai-auto",
      "settingDisplay": "text-ai-auto"
    }
  },
  // ヘッダーセット
  headerSet: {
    "headerSet01": {
      "left": {
        "type": "back",
        "href": "../home/",
        "icon": '<i class="bi bi-list fs-5"></i>'
      },
      "title": "リビング",
      "right": {
        "text": "保存",
        "href": "../save/",
        "visible": true
      },
    },
    "headerSet02": {
      "left": {
        "type": "back",
        "href": "../home/",
        "icon": '<i class="bi bi-chevron-left"></i>'
      },
      "title": "スケジュール",
      "right": {
        "text": "完了",
        "href": "../save/",
        "visible": true
      }
    }
    // headerSet01: '<i class="bi bi-list fs-5"></i>,リビング,',
    // headerSet02: '<i class="bi bi-chevron-left"></i>,スケジュール,完了',
    // headerSet03: '<i class="bi bi-chevron-left"></i>,タッチ気流<i class="bi bi-question-circle-fill ms-1 text-secondary"></i>,決定',
    // headerSet04: '<i class="bi bi-chevron-left"></i>,換気アシスト設定<i class="bi bi-question-circle-fill ms-1 text-secondary"></i>,完了',
    // headerSet05: '<i class="bi bi-chevron-left"></i>,窓位置設定,決定',
    // headerSet06: '<i class="bi bi-chevron-left"></i>,熱画像管理,',
    // headerSet07: '<i class="bi bi-chevron-left"></i>,電気代チェック,設定',
    // headerSet08: '<i class="bi bi-chevron-left"></i>,電気代単価設定,編集',
    // headerSet09: '<i class="bi bi-chevron-left"></i>,電気代単価設定,完了',
    // headerSet10: '<i class="bi bi-chevron-left"></i>,電気代チェック,',
    // headerSet11: '<i class="bi bi-chevron-left"></i>,目標電気代設定,',
    // headerSet12: '<i class="bi bi-chevron-left"></i>,運転履歴,',
    // headerSet13: '<i class="bi bi-chevron-left"></i>,メンテナンス,',
    // headerSet14: '<i class="bi bi-chevron-left"></i>,エアコン製品情報,',
    // headerSet15: '<i class="bi bi-chevron-left"></i>,製品情報の登録,',
    // headerSet16: '<i class="bi bi-chevron-left"></i>,オプション機能設定<i class="bi bi-exclamation-circle ms-1"></i>,',
    // headerSet17: '<i class="bi bi-chevron-left"></i>,機器情報,',
    // headerSet18: '<i class="bi bi-chevron-left"></i>,お知らせ,',
    // headerSet19: '<i class="bi bi-chevron-left"></i>,チュートリアル,',
    // headerSet20: '<i class="bi bi-chevron-left"></i>,アプリ情報,',
  },

  // フッターアイコンパス（拡張子なし）
  // footerIconStatus: {
  //   mymu: "../assets/img/icon-footer-mymu",
  //   basic: "../assets/img/icon-footer-basic",
  //   schedule: "../assets/img/icon-footer-schedule",
  //   other: "../assets/img/icon-footer-other",
  // },
  // スケジュール設定
  schedule: [
    {
      id: 1,
      name: "朝の運転",
      startTime: "07:00",
      dayOfTheWeek: {
        mon: true,
        tue: true,
        wed: true,
        thu: true,
        fri: true,
        sat: false,
        sun: false,
      },
      drive: true,
      mode: "cooling",
      setValue: 24,
    },
  ],
  // 運転／停止ボタン
  modalDrive: {
    // true ⇔ false
    isRunning: true,
    label: "停止",
  },
};

function storeJsonData() {
  try {
    sessionStorage.setItem("appData", JSON.stringify(initialAppData));
    // リダイレクト先に移動
    window.location.href = "./home/";
  } catch (error) {
    showAlert("JSONデータの保存に失敗しました。", "error");
  }
}

storeJsonData();
