const initialAppData = {
  currentPage: "home", // (home | automation | mymuPlus | notice)
  costumAutomation: {
    triggerEvent: "schedule", // (schedule | location | statusOfDevice)
  },
  automation: {
    selectedId: null,
    id1: {
      isSelected: false,
      status: true,
      name: "冬の帰宅",
      triggerEvent: {
        schedule: {
          startTime: "19:00",
          dayOfTheWeek: {
            sun: true,
            mon: true,
            tue: true,
            wed: true,
            thu: true,
            fri: true,
            sat: true,
          },
        },
        location: {
          user: {
            name: "",
            condition: "", // (close | away)
          },
        },
        product: {
          name: "", // (rac | eq)
          drive: "", // (on | off)
        },
      },
    },
    operationSettings: {
      ac1: {
        isDrive: false,
        mode: "cooling", // 運転モード（cooling, heating,, dehumidifying perflation）
        setTemperature: "24.0",
        setsStartTemperature: "24.0",
      },
      ac2: {
        isDrive: false,
        mode: "cooling", // 運転モード（cooling, heating,, dehumidifying perflation）
        setTemperature: "24.0",
        setsStartTemperature: "24.0",
      },
      eq: {
        isDrive: false,
      },
    },
    // スケジュール設定
    schedule: [
      {
        id: 3,
        name: "スケジュール",
        startTime: "07:00",
        dayOfTheWeek: {
          sun: true,
          mon: true,
          tue: false,
          wed: false,
          thu: false,
          fri: false,
          sat: false,
        },
        dayOfTheWeekLabel: "日月",
        isDrive: false,
        mode: "冷房",
        setValue: "24.0",
      },
    ],
  },
  // ヘッダーセット
  headerSet: {
    home: {
      left: {
        type: "drawer",
      },
      title: "MyMU",
      right: {
        text: '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="9" stroke="black" stroke-width="1.5"/><circle cx="10" cy="8" r="3" fill="black"/><path fill-rule="evenodd" clip-rule="evenodd" d="M5 17C5 14.2386 7.23858 12 10 12C12.7614 12 15 14.2386 15 17V17.3846L12.5 18.4615L10 19C10 19 8.45714 18.7708 7.5 18.4615C6.54286 18.1523 5 17.3846 5 17.3846V17Z" fill="black"/></svg>',
        visible: true,
      },
    },
    newAutomation: {
      left: {
        type: "back",
      },
      title: "新規オートメーション",
      right: {
        visible: false,
      },
    },
    deviceSettingsAc: {
      left: {
        type: "back",
      },
      title: "操作設定",
      right: {
        text: "完了",
        visible: true,
      },
    },
    deviceSettingsEq: {
      left: {
        type: "back",
      },
      title: "操作設定",
      right: {
        text: "完了",
        visible: true,
      },
    },
    applianceSelection: {
      left: {
        type: "back",
      },
      title: "機器を選択",
      right: {
        visible: false,
      },
    },
    customAutomation: {
      left: {
        type: "back",
      },
      title: "新規オートメーション",
      right: {
        visible: false,
      },
    },
    selectScene: {
      left: {
        type: "back",
      },
      title: "シーンを選択",
      right: {
        visible: false,
      },
    },
    noticeSettings: {
      left: {
        type: "back",
      },
      title: "通知設定",
      right: {
        text: "完了",
        visible: true,
      },
    },

    editAutomation: {
      left: {
        type: "back",
      },
      title: "オートメーション編集",
      right: {
        text: "完了",
        visible: true,
      },
    },
  },
};

function storeJsonData() {
  try {
    sessionStorage.setItem("appData", JSON.stringify(initialAppData));
    // リダイレクト先に移動
    window.location.href = "./home/";
  } catch (error) {
    showAlert("JSONデータの保存に失敗しました。", "error");
  }
}

storeJsonData();
