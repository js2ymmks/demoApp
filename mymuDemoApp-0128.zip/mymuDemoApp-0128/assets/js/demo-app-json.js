const initialAppData = {
};

function storeJsonData() {
  try {
    sessionStorage.setItem("appData", JSON.stringify(initialAppData));
    // リダイレクト先に移動
    window.location.href = "./home/";
  } catch (error) {
    showAlert("JSONデータの保存に失敗しました。", "error");
  }
}

storeJsonData();
