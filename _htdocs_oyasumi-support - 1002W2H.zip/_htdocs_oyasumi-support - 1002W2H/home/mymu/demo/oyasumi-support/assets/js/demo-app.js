﻿/******************************************
 * テンプレートファイル読み込み
 ******************************************/
document.addEventListener("DOMContentLoaded", async () => {
  try {
    const [alert, header, footer, modal, drawer] = await Promise.all([
      fetch("../partials/alert.txt").then((r) => r.text()),
      fetch("../partials/header.txt").then((r) => r.text()),
      fetch("../partials/footer.txt").then((r) => r.text()),
      fetch("../partials/modal.txt").then((r) => r.text()),
      fetch("../partials/drawer-menu.txt").then((r) => r.text()),

      // 本番環境では下記を使用する 
      // fetch("/home/mymu/demo/mymu/partials/alert.txt").then((r) => r.text()),
      // fetch("/home/mymu/demo/mymu/partials/header.txt").then((r) => r.text()),
      // fetch("/home/mymu/demo/mymu/partials/footer.txt").then((r) => r.text()),
      // fetch("/home/mymu/demo/mymu/partials/modal.txt").then((r) => r.text()),
      // fetch("/home/mymu/demo/mymu/partials/drawer-menu.txt").then((r) => r.text()),
    ]);

    document.querySelector(".content-alert").innerHTML = alert;
    document.querySelector(".content-header").innerHTML = header;
    document.querySelector(".content-footer").innerHTML = footer;
    document.querySelector(".content-modal").innerHTML = modal;
    document.querySelector(".content-drawer").innerHTML = drawer;
    initUI();
  } catch (err) {
    console.error("Failed to load partials:", err);
  }
});

/******************************************
 * ユーティリティ：JSON取得（ブラケット版）
 ******************************************/
const getJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("appDataEdit");
  let data;
  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }
  if (!data) return undefined;
  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");
  const props = normalizedPath.split(".");
  let current = data;
  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }
  return current;
};

/******************************************
 * ユーティリティ：JSON更新（ブラケット版）
 ******************************************/
const setJsonValue = (propertyPath, value) => {
  const storedJson = sessionStorage.getItem("appDataEdit");
  let data;
  try {
    data = storedJson ? JSON.parse(storedJson) : {};
  } catch (e) {
    data = {};
  }
  // ブラケット記法をドット記法に変換
  // "buttons[0].label" → "buttons.0.label"
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");
  const props = normalizedPath.split(".");
  let current = data;
  for (let i = 0; i < props.length - 1; i++) {
    const prop = props[i];
    // 数字 → 配列アクセス
    const index = Number(prop);
    const isIndex = !isNaN(index);
    if (isIndex) {
      if (!Array.isArray(current)) {
        current = [];
      }
      if (current[index] === undefined) {
        current[index] = {};
      }
      current = current[index];
    } else {
      if (!current[prop] || typeof current[prop] !== "object") {
        current[prop] = {};
      }
      current = current[prop];
    }
  }
  // 最終プロパティ
  const lastProp = props[props.length - 1];
  const lastIndex = Number(lastProp);
  if (!isNaN(lastIndex)) {
    if (!Array.isArray(current)) current = [];
    current[lastIndex] = value;
  } else {
    current[lastProp] = value;
  }
  sessionStorage.setItem("appDataEdit", JSON.stringify(data));
};

/******************************************
 * ユーティリティ：JSON取得（ブラケット版）ヘッダー用
 ******************************************/
const getHeaderJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("headerSet");
  let data;
  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }
  if (!data) return undefined;
  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");
  const props = normalizedPath.split(".");
  let current = data;
  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }
  return current;
};

/******************************************
 * ユーティリティ
 ******************************************/
// モーダルを閉じたときにフォーカスを外す
window.addEventListener("hide.bs.modal", () => {
  document.activeElement.blur();
});

/******************************************
 * ユーティリティ：ヘッダーのアイテムを設定する
 ******************************************/
function initHeader() {
  // ==============================
  // DOM取得
  // ==============================
  const headerDom = {
    leftBtn: document.getElementById("headerLeftBtn"),
    title: document.getElementById("headerTitle"),
    rightBtn: document.getElementById("headerRightBtn"),
  };

  if (!headerDom.leftBtn || !headerDom.title || !headerDom.rightBtn) {
    console.warn("header DOM がまだ準備できていません");
    return;
  }

  // ==============================
  // headerSetBodyKeyキー取得
  // ==============================
  const currentHeaderSetKey = document.body.dataset.appHeaderSet;
  if (!currentHeaderSetKey) {
    console.warn("data-app-header-set が指定されていません");
    return;
  }

  // ==============================
  // headerSetJson 取得
  // ==============================
  const headerSetJson = getHeaderJsonValue(`${currentHeaderSetKey}`);
  if (!headerSetJson) {
    console.warn(`headerSet.${currentHeaderSetKey} が見つかりません`);
    return;
  }

  // ==============================
  // タイトル
  // ==============================
  headerDom.title.innerHTML = headerSetJson.title;

  // ==============================
  // 左ボタン
  // ==============================
  renderLeftButton(headerSetJson.left?.type, headerDom.leftBtn);
  headerDom.leftBtn.onclick = () =>
    handleHeaderLeftAction(headerSetJson.left?.type);

  // ==============================
  // 右ボタン
  // ==============================
  renderRightButton(headerSetJson.right, headerDom.rightBtn);
  headerDom.rightBtn.onclick = () =>
    handleHeaderRightAction(headerSetJson.right?.action);
}

function initUI() {
  initFooterButtons();
  initFooterButtonsState();
  initHeader();
  bindScheduleTimeModal();
}

function bindScheduleTimeModal() {
  const modalEl = document.getElementById("scheduleTimeModal");
  if (!modalEl) return;
  if (modalEl.dataset.boundScheduleTimeModal === "1") return;
  modalEl.dataset.boundScheduleTimeModal = "1";

  modalEl.addEventListener("show.bs.modal", () => {
    const entryId = getJsonValue("entryId");
    renderScheduleTimeModal(entryId);
  });
}

// ==============================
// 左ボタン描画
// ==============================
// リセット
function renderLeftButton(type, btn) {
  btn.innerHTML = "";
  btn.classList.remove("d-none");
  // アイコン設定
  switch (type) {
    case "back":
      btn.innerHTML =
        '<i class="bi bi-chevron-left" style="color: white; font-size: 24px"></i>';
      break;
    case "backToMyMUPlusScreen":
      btn.innerHTML =
        '<div class="d-flex align-items-center gap-2"><img src="../assets/img/chevron-back.svg"><img src="../assets/img/icon_MyMUHeader.svg"></div>';
      break;
    case "backToTopSleepSettingsScreen":
      btn.innerHTML =
        '<img src="../assets/img/chevron-back.svg">';
      break;
    case "acCustomSettings":
      btn.innerHTML =
        '<img src="../assets/img/chevron-back.svg">';
      break;
    case "drawer":
      btn.innerHTML =
        '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"><rect x="1" y="2" width="18" height="2.5" rx="1.25" fill="black"/><rect x="1" y="9" width="18" height="2.5" rx="1.25" fill="black"/><rect x="1" y="16" width="18" height="2.5" rx="1.25" fill="black"/></svg>';
      break;
    case "backToSelectDeviceScreen":
      btn.innerHTML = '<i class="bi bi-chevron-left"></i>';
      break;
    case "easySetup":
      btn.innerHTML =
        '<img src="../assets/img/chevron-back.svg">';
      break;
    default:
      btn.classList.add("d-none");
  }
}

// ==============================
// 左アクション処理
// ==============================
function handleHeaderLeftAction(type) {
  switch (type) {
    case "backToMyMUPlusScreen":
      window.location.href = "../../mymu/mymu-plus/";
      break;
    case "backToSelectDeviceScreen":
      window.location.href = "../select-device/";
      break;
    case "backToTopSleepSettingsScreen":
      window.location.href = "../top-sleep-settings/";
      break;
    case "acCustomSettings":
      window.location.href = "../ac-settings/";
      break;
    case "easySetup":
      prevPage();
      // window.location.href = "../ac-settings/";
      break;
    case "drawer":
      const bsOffcanvas = new bootstrap.Offcanvas("#appOffcanvas");
      bsOffcanvas.show();
      break;
  }
}

// ==============================
// 右ボタン描画　headerTitle
// ==============================
function renderRightButton(headerSetJsonRight, headerDomRight) {
  // 右ボタンのプロパティチェック
  if (!headerSetJsonRight || !headerSetJsonRight.visible) {
    headerDomRight.classList.add("d-none");
    headerDomRight.onclick = null;
    return;
  }
  // 表示
  headerDomRight.classList.remove("d-none");
  // text / icon / svg すべて対応
  headerDomRight.innerHTML = headerSetJsonRight.text || "";
  if (headerSetJsonRight.action === "drawer") {
    headerDomRight.disabled = false;
    headerDomRight.classList.remove("disabled");
    headerDomRight.classList.remove("js-complete-btn");
    headerDomRight.setAttribute("aria-disabled", "false");
  }

  // クリック処理（あれば）
  headerDomRight.onclick = () => {
    handleHeaderRightAction(headerSetJsonRight.action, headerSetJsonRight);
  };
}

// ==============================
// 右アクション処理（）
// ==============================
function handleHeaderRightAction(action) {
  switch (action) {
    // メニュー表示
    case "drawer":
      const bsOffcanvas = new bootstrap.Offcanvas("#appOffcanvas");
      bsOffcanvas.show();
      break;

    // アラート表示
    case "alert":
      alert(
        "デモアプリではこのボタンは操作できません。＜ ボタンで戻ってください",
      );
      break;

    // MyMUボタン
    case "mymu":
      const headerEl = document.querySelector(".app-header");
      headerEl.addEventListener("click", (e) => {
        const btn = e.target.closest("#headerRightBtn");
        if (!btn) return;
        alert("デモアプリではこのボタンは操作できません。");
      });
      break;

    // エアコンのこだわり設定 ｜ 完了ボタン
    case "moveToTopSleepSettingsScreen":
      alert("デモアプリではこのボタンは操作できません。");
      window.location.href = "../top-sleep-settings/";
      break;

    // シーン
    case "":
      break;
  }
}

/******************************************
 * ユーティリティ：モーダル表示
 ******************************************/
function showModal(modalId) {
  const modalEl = document.getElementById(modalId);
  if (!modalEl) return;

  const modal = new bootstrap.Modal(modalEl);
  modal.show();
}

/******************************************
 * イニシャライズ：フッター
 ******************************************/
const initFooterButtons = () => {
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const currentHeaderSetKey = document.body.dataset.appHeaderSet;
      // MyMU＋アイコンのみ処理する
      if (btn.dataset.appPage !== "mymuPlus") {
        return;
      }
      if (
        currentHeaderSetKey === "editAutomation" &&
        btn.dataset.appPage === "automation"
      ) {
        setJsonValue("navigationMode", "back");
      }
      setJsonValue("currentPage", btn.dataset.appPage);
    });
  });
};

/******************************************
 * レンダリング：フッターアイコン表示更新
 ******************************************/
const initFooterButtonsState = () => {
  // フッターが存在しない画面
  const footerElement = document.getElementsByClassName("content-footer")[0];
  if (footerElement.className.includes("d-none")) {
    return;
  }
  // スタイルリセット
  const currentPage = getJsonValue("currentPage");
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.classList.remove("active");
  });
  // レンダリング
  footerButtons.forEach((btn) => {
    const page = btn.dataset.appPage;
    if (page === currentPage) {
      btn.classList.add("active");
    }
  });
};

/******************************************
 * おやすみサポート デモアプリ
 * 2026年9月
 * トップ画面 睡眠設定 topSleepSettings
 * トップ画面 レポート topReport
 * エアコン設定画面 acSettings
 * エアコンのこだわり画面 acCustomSettings
 * おやすみ音楽設定画面 sleepMusicSettings
 * メニュー画面
 ******************************************/

/******************************************
 * トップ画面（睡眠設定）
 ******************************************/

// トップ画面（睡眠設定） | 状態管理
const topSleepSettingsScreenState = {
  state: getJsonValue('topSleepSettings.state'),
  timer: "normal", // normal | edit
  audio: 'stop' // 'stop' | 'play' |'stop' | 'pause'
}

// トップ画面（睡眠設定） | レンダリング 
function renderTopSleepSettingsScreen() {
  setSectionDisplay(topSleepSettingsScreenState.state, 'oyasumiSupport');
  renderToggleComponents();
  getSwitchTabInnerHTML();
  whichScreenToDisplay();
  renderOyasumiTimerSection();
  renderAudioSection();
}

// トップ画面（睡眠設定） | レンダリング | おやすみサポートアイコン表示
function renderOyasumiSupportSection() {
  const state = topSleepSettingsScreenState.state;
  document.querySelector('#oyasumiSupportIcon img').src = state ? "../assets/img/launcher_Icon_sleep_on.svg" : "../assets/img/launcher_Icon_sleep_off.svg";
}

// トップ画面（睡眠設定） | レンダリング | おやすみ時間設定
function renderOyasumiTimerSection() {
  const mode = topSleepSettingsScreenState.timer;
  const normal = document.querySelector('.settingDial[data-state-value="normal"]');
  const edit = document.querySelector('.settingDial[data-state-value="edit"]');
  const btnLabel = document.querySelector('.timerBtnLabel');

  const isNormal = mode === "normal";

  normal.classList.toggle("is-visible", isNormal);
  edit.classList.toggle("is-visible", !isNormal);
  btnLabel.textContent = isNormal ? "おやすみ時間変更" : "完了";
  initTopSleepTimeHandles();
}

// トップ画面（睡眠設定） | レンダリング | オーディオ
function renderAudioSection() {
  const readyBtn = document.getElementById('ready');
  const stopBtn = document.getElementById('stop');
  const playBtn = document.getElementById('play');
  const pauseBtn = document.getElementById('pause');
  const audioMode = topSleepSettingsScreenState.audio;

  switch (audioMode) {
    case "ready":
    case "stop":
      readyBtn.classList.toggle('d-none', false);
      stopBtn.classList.toggle('d-none', true);
      playBtn.classList.toggle('d-none', true);
      pauseBtn.classList.toggle('d-none', true);
      break;
    case "play":
      readyBtn.classList.toggle('d-none', true);
      stopBtn.classList.toggle('d-none', false);
      playBtn.classList.toggle('d-none', true);
      pauseBtn.classList.toggle('d-none', false);
      break;
    case "pause":
      readyBtn.classList.toggle('d-none', true);
      stopBtn.classList.toggle('d-none', false);
      playBtn.classList.toggle('d-none', false);
      pauseBtn.classList.toggle('d-none', true);
      break;
  }
}

// トップ画面（睡眠設定） | クリックイベント
document.addEventListener("click", (e) => {
  const el = e.target;
  // トップ画面（睡眠設定） | クリックイベント | 表示設定
  const oyasumiSupportToggle = el.closest('[data-state-key="oyasumiSupport"]');
  if (oyasumiSupportToggle) {
    topSleepSettingsScreenState.state = !topSleepSettingsScreenState.state;
    renderOyasumiSupportSection();
    renderTopSleepSettingsScreen();
  }

  // トップ画面（睡眠設定） | クリックイベント | おやすみタイマー設定
  const timerBtnLabel = el.closest('.timerBtnLabel');
  if (timerBtnLabel) {
    topSleepSettingsScreenState.timer = (topSleepSettingsScreenState.timer === "normal") ? "edit" : "normal";
    renderOyasumiTimerSection();
  }

  // トップ画面（睡眠設定） | クリックイベント | モーダル表示
  const oyasumiSupportTimeSettings = el.closest('.oyasumiSupportTimeSettings');
  if (oyasumiSupportTimeSettings) {
    const key = oyasumiSupportTimeSettings.dataset.key;
    if (key === 'sleep') {
      console.log(key);
      setModalElementsTwoColumn(key)
    } else {
      console.log(key);
      setModalElementsTwoColumn(key)
    }
    showModal('modalDialogTwoColumn');
  }

  // トップ画面（睡眠設定） | クリックイベント | 再生ボタン
  const audioBtn = el.closest('#ready, #stop, #play, #pause');
  if (audioBtn) {
    const value = audioBtn.dataset.value;
    topSleepSettingsScreenState.audio = value;
    renderAudioSection();
  }

});


/******************************************
 * マスターデータ
 ******************************************/

// ダイアログ
const MASTER_DIALOG = {
  // こだわり設定_ダイアログ_1
  acCustomSettings: {
    description: '設定内容が保存されていません<br />設定内容を破棄してもよろしいですか？',
    btnLeft: '破棄する',
    btnRight: '編集を続ける',
  },
  // おやすみ時間設定_ダイアログ_1
  sleepTimeSetting1: {
    description: 'おやすみ自動運転の開始時刻を過ぎているため、おやすみ自動運転は翌日以降に動作します。設定を変更しますか？',
    btnLeft: '変更しない',
    btnRight: '変更する',
  },
  // おやすみ時間設定_ダイアログ_2
  sleepTimeSetting2: {
    description: 'おやすみサポートをOFFにすると「おやすみ自動運転」は行われません。設定を変更しますか？',
    btnLeft: '変更しない',
    btnRight: '変更する',
  },
  // おやすみ音楽設定_ダイアログ_1
  deleteSleepMusic: {
    description: '音楽を削除しますか？<br />※削除後も再ダウンロードが可能です。',
    btnLeft: 'いいえ',
    btnRight: 'はい',
  },
  // おやすみ音楽設定_ダイアログ_2
  downloadSleepMusic: {
    description: 'ダウンロードを開始しますか？<br />(50MB)',
    btnLeft: 'いいえ',
    btnRight: 'はい',
  },
  // おやすみ時間
  oyasumiSupportTimeSettings: {
    sleep: {
      title: '就寝時刻',
      optionsLeft: ['20', '21', '22', '23', '22'],
      optionsRight: ['', '', '00', '10', '20'],
    },
    wakeup: {
      title: '起床時刻',
      optionsLeft: ['5', '6', '7', '8', '9'],
      optionsRight: ['10', '20', '30', '40', '50'],
    }
  },
  // 就寝中の冷房
  coolingWhileSleeping: {
    title: '運転時間',
    options: ['30分', '40分', '50分', '1時間', '1時間10分'],
  },
  // 就寝前の予冷・予暖
  preCoolingHeatingBeforeSleeping: {
    title: '運転継続時間',
    options: ['0分 (就寝時刻で停止)', '30分', '1時間', '2時間', '起床時刻まで'],
  },
  // 冷房の起動室温
  coolingStartUpRoomTemperature: {
    title: '冷房の起動室温',
    options: ['27.0℃', '27.5℃', '28.0℃', '28.5℃', '29.0℃'],
  },
  // 冷房の設定温度
  coolingSetTemperature: {
    title: '冷房の設定温度',
    options: ['23.0℃', '23.5℃', '24.0℃', '24.5℃', '25.0℃'],
  },
  // 暖房の起動室温
  heatingStartUpRoomTemperature: {
    title: '暖房の起動室温',
    options: ['17.0℃', '17.5℃', '18.0℃', '18.5℃', '19.0℃'],
  },
  // 暖房の設定温度
  heatingSetTemperature: {
    title: '暖房の設定温度',
    options: ['20.0℃', '20.5℃', '21.0℃', '21.5℃', '22.0℃'],
  },
};

/******************************************
 * 状態管理
 ******************************************/

// かんたん設定
const easySetupState = {
  currentPage: 'easySetup1',
  minPage: 'easySetup1',
  maxPage: 'easySetup4',
  coolingSetTemperature: 24,
  heatingSetTemperature: 21.0,
};

const acSettingsModeState = {
  mode: getJsonValue("easySetup"), // easy | custom
  // mode: "custom", // easy | custom
}

/******************************************
 * クリックイベント
 ******************************************/
document.addEventListener("click", (e) => {
  const el = e.target;

  // 全画面 | アラート表示
  const showAlertBtn = el.closest(".js-show-alert");
  if (showAlertBtn) {
    alert("デモアプリではこのボタンは操作できません。");
  }

  // MyMU＋画面 | ソリューションカード
  const appCardBtn = el.closest(".js-app-card");
  if (appCardBtn) {
    const mode = getJsonValue("topPageMode");
    if (mode === "settings") {
      window.location.href = "../top-sleep-settings/";
    } else {
      window.location.href = "../top-report/";
    }
  }

  // トップ画面（睡眠設定） | エアコン設定画面へ遷移
  const acSettingsBtn = el.closest(".js-ac-settings-btn");
  if (acSettingsBtn) {
    window.location.href = "../ac-settings/";
  }

  // エアコン設定画面 | エアコン設定変更モーダルへ遷移
  const selectSettingTypeBtn = el.closest(".js-set-ac-settings-btn");
  if (selectSettingTypeBtn) {
    renderSelectAcSetupMethod();
    showModal("selectAcSetupMethod");
  }

  // トップ画面（睡眠設定） |
  const showSleepSettingsScreenBtn = el.closest(".js-show-sleep-settings");
  if (showSleepSettingsScreenBtn) {
    setJsonValue("topPageMode", "settings");
  }

  // トップ画面（レポート） |
  const showReportScreenBtn = el.closest(".js-show-report");
  if (showReportScreenBtn) {
    setJsonValue("topPageMode", "report");
  }

  // モーダルテンプレート |
  const showModalDialogTemplateBtn = el.closest(".js-show-modal");
  if (showModalDialogTemplateBtn) {
    renderModalDialogTemplate();
    showModal("modalDialogTemplate");
  }

  // おやすみ音楽設定画面へ遷移
  const gotoSleepMusicSettingsScreenBtn = el.closest(".js-goto-sleep-music-settings");
  if (gotoSleepMusicSettingsScreenBtn) {
    window.location.href = "../sleep-music-settings/";
  }

  // おやすみ音楽設定画面 | おやすみ音楽削除ボタン
  const musicDeleteBtn = el.closest("#musicDeleteBtn");
  if (musicDeleteBtn) {
    showModal("modalDialogTemplate");
  }

  // おやすみ音楽設定画面 | おやすみ音楽ダウンロードボタン
  const musicDownloadBtn = el.closest("#musicDownloadBtn");
  if (musicDownloadBtn) {
    showModal("modalDialogTemplate");
  }

  // おやすみ音楽設定画面 | おやすみ音楽選択ボタン
  const musicSelectBtn = el.closest("#musicSelectBtn");
  if (musicSelectBtn) {
    showModal("modalDialogTemplate");
  }


  // ↑ クリックイベントの処理はここまで
});

/******************************************
 * レンダリング | レポート画面
 * 各画面ごとのレンダリング処理
 ******************************************/
// MyMU＋画面 | ヘッダー部の注記の色をMyMUと同じカラーにする
function renderMymuPlusScreen() {
  const elm = document.querySelector(".content-alert .bg-black");
  elm.classList.add("alert");
  elm.classList.replace("bg-black", "alert-primary");
}

/******************************************
 * レンダリング | 各画面
 ******************************************/

// トップ画面（レポート）
function renderTopReportScreen() {
  getSwitchTabInnerHTML();
  whichScreenToDisplay();
  renderRoomTemperatureCheck();
  renderComfortRatingSection();
}

// エアコン設定画面
function renderAcSettingsScreen() {
  setSectionDisplay(acSettingsScreenState.state, 'automaticOperation');
  renderToggleComponents();
  renderRadioComponents();
}

// おやすみ音楽設定画面
function renderSleepMusicSettingsScreen() {
  renderToggleComponents();
  renderRadioComponents();
  // initAudioVolume();
}

// かんたん設定画面
function renderEasySetupScreen() {
  renderSvgImage();
}

// トップページ | SVGアイコン | 
function whichScreenToDisplay() {
  const topPageMode = getJsonValue("topPageMode");
  const settingsElm = document.querySelector(
    '.tab-switch[data-key="settings"]',
  );
  const reportElm = document.querySelector('.tab-switch[data-key="report"]');
  // 画面表示をスイッチ
  if (topPageMode === "settings") {
    setComponentState(settingsElm, "active");
    setComponentState(reportElm, "inactive");
  } else if (topPageMode === "report") {
    setComponentState(settingsElm, "inactive");
    setComponentState(reportElm, "active");
  }
}

// かんたん設定画面 | リンダリング
function renderSvgImage() {
  const hideSvgImages = document.querySelectorAll(".js-svg-image");
  const displaySvgImage = document.getElementById(
    `${easySetupState.currentPage}`,
  );
  // リセット（全て非表示）
  hideSvgImages.forEach((image) => {
    image.style.display = "none";
  });
  // 表示
  displaySvgImage.style.display = "block";
  renderTemperatureUI();
}

// ユーティリティ | 状態変更
function setComponentState(element, state) {
  element.dataset.state = state;
}

// モード選択スイッチタブのinnerHTML
function getSwitchTabInnerHTML() {
  document.getElementById("switchTab").innerHTML = `
          <div class="container px-4 py-2">
            <div class="row align-items-center">
              <!-- 睡眠設定 -->
              <div class="col tab-switch" data-key="settings" data-state="">
                <a role="button"
                  class="d-flex flex-column align-items-center text-decoration-none footer-button js-show-sleep-settings"
                  href="../top-sleep-settings/" data-app-page="mymu">
                  <div class="">
                    <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path id="iconSleepSettings"
                        d="M12.2041 0C17.472 0.831521 21.5008 5.39097 21.501 10.8926C21.501 16.984 16.5622 21.9229 10.4707 21.9229C6.06656 21.9227 2.26786 19.3397 0.5 15.6074C1.97938 16.5031 3.71371 17.0204 5.56934 17.0205C10.984 17.0205 15.374 12.6305 15.374 7.21582C15.3739 4.36063 14.1519 1.79173 12.2041 0Z"
                        fill="currentColor" />
                    </svg>
                  </div>
                  <div id="labelSleepSettings" class="fs-14 pt-2 label">睡眠設定</div>
                </a>
              </div>
              <!-- レポート -->
              <div class="col tab-switch" data-key="report" data-state="">
                <a role="button"
                  class="d-flex flex-column align-items-center text-decoration-none footer-button js-show-report"
                  href="../top-report/" data-app-page="">
                  <div class="">
                    <svg id="iconReport" width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <rect class="icon" x="6" width="4" height="22" rx="1" fill="currentColor" />
                      <rect class="icon" x="12" y="6" width="4" height="16" rx="1" fill="currentColor" />
                      <rect class="icon" x="18" y="10" width="4" height="12" rx="1" fill="currentColor" />
                      <rect class="icon" y="10" width="4" height="12" rx="1" fill="currentColor" />
                    </svg>
                  </div>
                  <div id="labelReport" class="fs-14 pt-2 label">レポート</div>
                </a>
              </div>
            </div>
          </div>
  `;
}

// かんたん設定画面 | 次へボタン | 次スライド番号
function nextPage() {
  if (easySetupState.currentPage === "easySetup5") {
    easySetupState.currentPage = "easySetup1";
    window.location.href = "../ac-settings/";
    return;
  }
  const pageNumber = Number(
    easySetupState.currentPage.replace("easySetup", ""),
  );
  easySetupState.currentPage = `easySetup${pageNumber + 1}`;
  renderSvgImage();
}

// エアコンのかんたん設定 | 戻るボタン | 戻るスライド番号
function prevPage() {
  if (easySetupState.currentPage === "easySetup1") {
    window.location.href = "../ac-settings/";
    return;
  }
  const pageNumber = Number(
    easySetupState.currentPage.replace("easySetup", ""),
  );
  easySetupState.currentPage = `easySetup${pageNumber - 1}`;
  renderSvgImage();
}

function renderModalDialogTemplate() {
  const modalState = stateModalDialogTest.state;
  document.querySelector(".description").textContent = MASTER_DIALOG[modalState].description;
  document.querySelector(".btnLeft").textContent = MASTER_DIALOG[modalState].btnLeft;
  document.querySelector(".btnRight").textContent = MASTER_DIALOG[modalState].btnRight;

}

// かんたん設定｜クリックイベント｜設定温度をクリックして変更
function changeTemperature(offset) {
  if (easySetupState.currentPage === "easySetup2") {
    easySetupState.coolingSetTemperature += offset;
  } else if (easySetupState.currentPage === "easySetup3") {
    easySetupState.heatingSetTemperature += offset;
  } else {
    return;
  }
  renderTemperatureUI();
}
// }

// かんたん設定｜クリックイベント
document.addEventListener("click", (e) => {
  const el = e.target;
  // かんたん設定｜クリックイベント｜温度増減
  const setBtn = el.closest(".js-set-btn");
  if (setBtn) {
    changeTemperature(Number(setBtn.dataset.offsetValue), easySetupState.currentPage);
  }
  // ↑ クリックイベントの処理はここまで
});


// かんたん設定｜レンダリング｜設定温度を更新
function renderTemperatureUI() {
  let val;
  let temperatureInteger;
  let temperatureDecimal;
  if (easySetupState.currentPage === "easySetup2") {
    val = easySetupState.coolingSetTemperature;
    temperatureInteger = document.querySelector(".coolingTemperatureInteger");
    temperatureDecimal = document.querySelector(".coolingTemperatureDecimal");
  } else if (easySetupState.currentPage === "easySetup3") {
    val = easySetupState.heatingSetTemperature;
    temperatureInteger = document.querySelector(".heatingTemperatureInteger");
    temperatureDecimal = document.querySelector(".heatingTemperatureDecimal");
  } else {
    return;
  }

  const integerPart = Math.floor(val); // 整数部
  const decimalPart = (val % 1).toFixed(1).split('.')[1];  // 小数部

  if (temperatureInteger) temperatureInteger.textContent = integerPart + '.';
  if (temperatureDecimal) temperatureDecimal.textContent = decimalPart + '℃';

}

/******************************************
 * トグルスイッチ（コンポーネント）
 ******************************************/
const toggleState = {
  oyasumiSupport: getJsonValue("topSleepSettings.state") ?? true,
  automaticOperation: true,
  autoTempSets: false, // おまかせ温度設定
  preCoolingBeforeSleep: true, // 就寝前の予冷
  preHeatingBeforeSleep: true, // 就寝前の予暖
  fadeOut: true,
  playbackTime: true,
};

function renderToggle(toggleElement) {
  if (!toggleElement) return;
  const stateKey = toggleElement.dataset.stateKey;
  const isOn = toggleState[stateKey];
  const track = toggleElement.querySelector('.toggle-track');
  const knob = toggleElement.querySelector('.toggle-knob');
  if (!track || !knob) return;
  track.setAttribute(
    'fill',
    isOn ? '#967AEB' : '#F0F0F0'
  );
  knob.setAttribute(
    'cx',
    isOn ? '35' : '15.5'
  );
}

document.addEventListener('click', (event) => {
  const toggle = event.target.closest('.toggle-component');
  if (!toggle) return;
  const stateKey = toggle.dataset.stateKey;
  toggleState[stateKey] = !toggleState[stateKey];
  renderToggle(toggle);
});

// 対象のDOM要素を返す
function renderToggleComponents() {
  Object.entries(toggleState).forEach(([key, value]) => {
    // data-state-key 属性がキー名と一致する要素を取得
    const toggleElement = document.querySelector(`[data-state-key="${key}"]`);
    if (toggleElement) {
      // 要素が存在する場合のみ描画処理を実行
      renderToggle(toggleElement);
    }
  });
};
/******************************************
 * ラジオボタン（コンポーネント）
 ******************************************/
const radioState = {
  acSettings: 'easy', // easy | custom
  sleepMusic: 'music04', // music01 | music02 | music03 | music04
  acWindSpeed: 'auto', // auto | custom
};

function renderRadioGroup(group) {
  const stateKey = group.dataset.stateKey;
  const selectedId = radioState[stateKey];

  group.querySelectorAll('.radio-component')
    .forEach(radio => {
      const radioId = radio.dataset.stateKey;
      const dot = radio.querySelector('.radio-dot');
      dot.style.display =
        radioId === selectedId ? 'block' : 'none';
    });
}

document.addEventListener('click', (event) => {
  const radio = event.target.closest('.radio-component');
  if (!radio) return;
  const radioGroupElement = radio.closest('.radio-group');
  if (!radioGroupElement) return;
  const stateKey = radio.dataset.stateKey;
  const radioGroupKey = radioGroupElement.dataset.stateKey;
  radioState[radioGroupKey] = stateKey;
  renderRadioGroup(radioGroupElement);
});

// 対象のDOM要素を返す
function renderRadioComponents() {
  Object.entries(radioState).forEach(([key, value]) => {
    // data-state-key 属性がキー名と一致する要素を取得
    const radio = document.querySelector(`[data-state-key="${key}"]`);
    if (radio) {
      // 要素が存在する場合のみ描画処理を実行
      renderRadioGroup(radio);
    }
  });
};

// エアコンかんたん設定モーダル | エアコン設定、こだわり設定のどちらかへ遷移
function moveToAcSettingsScreen() {
  const mode = radioState.acSettings;
  if (mode === "easy") {
    window.location.href = "../easy-setup/";
  } else {
    window.location.href = "../ac-custom-settings/";
  }
}


/******************************************
 * カレンダー処理
 * グリッド型カレンダー・水平型カレンダー 共通設定
 * （calendarConfig・calendarState を両カレンダーで共有する）
 ******************************************/
// カレンダー | 設定情報 | 最小日付・最大日付
const calendarConfig = {
  minDate: {
    year: 2025,
    month: 1,
    day: 1
  },
  maxDate: {
    year: 2026,
    month: 9,
    day: 23,
  }
};
// 状態管理 | 初期表示
let calendarState = {
  mode: "month", // month | year
  displayYear: 2026,
  displayMonth: 9,
  selectedDate: {
    year: calendarConfig.maxDate.year,
    month: calendarConfig.maxDate.month,
    day: calendarConfig.maxDate.day,
  },
};

// 選択日ラベル | レンダリング（グリッド型・水平型 共通）
// calendarState.selectedDate の変更を画面上部の「○月○日」表示へ反映する
function renderSelectedDateLabel() {
  const label = document.getElementById("selectedDateLabel");
  if (!label) return;
  label.textContent =
    `${calendarState.selectedDate.month}月${calendarState.selectedDate.day}日`;
}

// カレンダー | レンダリング
function renderCalendar() {
  // レンダリング | ヘッダー部 | 年月表示
  renderCalenderHeader(calendarState.displayYear, calendarState.displayMonth - 1);
  // レンダリング | ボディ部 | 月カレンダー
  renderMonthCalendar();
  // ボタンの状態をチェック|非活性・無効化
  isBtnDisable();
}

/******************************************
 * グリッド型カレンダーセクション
 * （#gridCalender クリックでモーダル表示する月カレンダー）
 ******************************************/
/******************************************
 * ビュー
 ******************************************/
// 矢印ボタン | 無効化する（disabled・グレー色）
function disableButton(selector) {
  const btn = document.querySelector(selector);
  if (!btn) return;

  btn.setAttribute("aria-disabled", "true");
  btn.classList.add("is-disabled");
  btn.style.pointerEvents = "none";

  const svgPath = btn.querySelector("svg path");
  if (svgPath) {
    svgPath.setAttribute("fill", "#E6E6E6");
  }
}

// 矢印ボタン | 有効化する（有効化・元の青色）
function enableButton(selector) {
  const btn = document.querySelector(selector);
  if (!btn) return;

  btn.setAttribute("aria-disabled", "false");
  btn.classList.remove("is-disabled");
  btn.style.pointerEvents = "";

  const svgPath = btn.querySelector("svg path");
  if (svgPath) {
    svgPath.setAttribute("fill", "#967AEB");
  }
}

/******************************************
 * 月カレンダー
 ******************************************/
// レンダリング | 月カレンダー | 
function renderMonthCalendar() {
  // レンダリング | 月カレンダ | カレンダーデータ作成（HTML・日にちデータ）
  createMonthCalendarHtml(calendarState.displayYear, calendarState.displayMonth - 1);
  // メンテナンス日をマーク
  // const selectedYear = calendarState.selectedDate.year
  // const selectedMonth = calendarState.selectedDate.month
  // const selectedDay = calendarState.selectedDate.day
}

// レンダリング | 月・年カレンダー | 共通（ヘッダー）
function renderCalenderHeader(year, month) {
  document.querySelector(".js-calendar-month-label").textContent =
    `${calendarState.displayYear}年 ${String(calendarState.displayMonth).padStart(2, "0")}月`;
}

// HTML作成 | 月カレンダー | 
function createMonthCalendarHtml(year, month) {
  // カレンダーデータを取得
  const calendar = createMonthCalendarData(year, month);
  // 表示先
  const container = document.getElementById("monthCalendar");

  if (!container) return;
  // カレンダーを初期化
  let html = "";
  // データ属性用の変数
  let n = 1;
  // 42セルをループ
  for (let i = 0; i < 42; i++) {
    if (calendar.days[i] === null) {
      html += `<button class="bg-transparent border border-0 js-calendar-day invisible"></button>`;
      // 本日より後の日付は選択不可
    } else if (!isWithinDateRange(n)) {
      html += `<button class="bg-transparent border border-0 is-disabled js-calendar-day" data-key="${n}">${calendar.days[i]}</button>`;
      n++;
      // 本日はマークする
    } else if (!isReportDay(n)) {
      html += `<button class="bg-transparent border border-0 js-calendar-day" data-key="${n}">${calendar.days[i]}</button>`;
      n++;
    } else {
      html += `<button class="bg-transparent border border-0 js-calendar-day active" data-key="${n}">${calendar.days[i]}</button>`;
      n++;
    }
  }
  container.innerHTML = html;
  document.querySelector('.calenderExcuteBtn ').classList.remove('disabled') ?? "";
}

// データ作成 | 月カレンダー
function createMonthCalendarData(year, month) {
  // 1日の曜日
  const firstWeek = new Date(year, month, 1).getDay();
  // 月末日
  const lastDate = new Date(year, month + 1, 0).getDate();
  // 42セル
  const days = Array(42).fill(null);
  // 日付を配置
  for (let day = 1; day <= lastDate; day++) {
    days[firstWeek + day - 1] = day;
  }
  return {
    year,
    month,
    firstWeek,
    lastDate,
    days
  };
}

// レポート日を設定
function isReportDay(n) {
  const displayYear = Number(calendarState.displayYear);
  const displayMonth = Number(calendarState.displayMonth);
  const selectedYear = Number(calendarState.selectedDate.year);
  const selectedMonth = Number(calendarState.selectedDate.month);
  const selectedDay = Number(calendarState.selectedDate.day);

  if (
    displayYear === selectedYear &&
    displayMonth === selectedMonth &&
    selectedDay === Number(n)
  ) {
    return true;
  }
  return false;
}

// 月カレンダー | 前月・次月の切り替え
function changeMonth(offset) {
  let year = calendarState.displayYear;
  let month = calendarState.displayMonth + offset;
  // 1月より小さい場合は12月になる
  if (month < 1) {
    month = 12;
    year--;
  }
  // 12月より大きい場合は1月になる
  if (month > 12) {
    month = 1;
    year++;
  }

  // 最小値・最大値を超えた場合
  if (!canDisplayMonth(year, month)) {
    return;
  }

  calendarState.displayYear = year;
  calendarState.displayMonth = month;

  isBtnDisable(); // ボタンの状態をチェック
  renderCalenderHeader(calendarState.displayYear, calendarState.displayMonth - 1);
  createMonthCalendarData(calendarState.displayYear, calendarState.displayMonth - 1);
}

// ボタンの状態をチェック|非活性・無効化
function isBtnDisable() {
  const year = calendarState.displayYear;
  const month = calendarState.displayMonth;

  enableButton(".js-calendar-prev-month");
  enableButton(".js-calendar-next-month");

  // 月カレンダーの場合
  if (
    year === calendarConfig.minDate.year &&
    month === calendarConfig.minDate.month
  ) {
    disableButton(".js-calendar-prev-month");
  } else if (
    year === calendarConfig.maxDate.year &&
    month === calendarConfig.maxDate.month
  ) {
    disableButton(".js-calendar-next-month");
  }
}

// イベントデリゲーション | カレンダーモーダル
document.addEventListener("click", (event) => {

  //   前月
  if (event.target.closest(".js-calendar-prev-month")) {
    changeMonth(-1); // 前月
    renderMonthCalendar(); // カレンダー表示
  }
  //   次月
  if (event.target.closest(".js-calendar-next-month")) {
    changeMonth(1); // 次月
    renderMonthCalendar(); // カレンダー表示
  }

  // 日にちをクリック | JSONへ代入（日と月のみ）
  if (event.target.closest(".js-calendar-day")) {
    const dayButton = event.target.closest(".js-calendar-day");
    // 一旦リセット
    dayButton.parentElement.querySelectorAll('.js-calendar-day').forEach((btn) => {
      btn.classList.remove('active');
    });
    // 日にちをマーク
    dayButton.classList.add('active');
    // Stateへ代入
    calendarState.selectedDate.year = calendarState.displayYear;
    calendarState.selectedDate.month = calendarState.displayMonth;
    calendarState.selectedDate.day = Number(dayButton.dataset.key);
    // 選択日ラベル・水平型カレンダーへ反映（グリッド型と水平型で状態を共有）
    renderSelectedDateLabel();
    renderHorizontalCalendar();
  }

  // ↑ イベントデレゲーションここまで
});

// カレンダー | 戻る・進むボタンの最小月・最大月判定
function canDisplayMonth(year, month) {
  // 戻る・進むボタンをリセット
  enableButton('.js-calendar-prev-month');
  enableButton('.js-calendar-next-month');
  // 最小年月より前
  if (
    year < calendarConfig.minDate.year ||
    (year === calendarConfig.minDate.year &&
      month < calendarConfig.minDate.month)
  ) {
    return false;
  }
  // 最大年月より後
  if (
    year > calendarConfig.maxDate.year ||
    (year === calendarConfig.maxDate.year &&
      month > calendarConfig.maxDate.month)
  ) {
    return false;
  }
  return true;
}

// カレンダー | 決定ボタン —> JSONへセット
function setMaintenanceDay() {
  // setJsonValue('lastMaintenanceDate.year', calendarState.selectedDate.year);
  // setJsonValue('lastMaintenanceDate.month', calendarState.selectedDate.month);
  // setJsonValue('lastMaintenanceDate.day', calendarState.selectedDate.day);
  syncCalendarStateFromJson();
  // modeをリセット
  calendarState.mode = "month";
  document.querySelector(".calendarYear").classList.add("d-none");
  document.querySelector(".calendarMonth").classList.remove("d-none");

  // レポート画面レンダリング
  renderReportScreen();
}

// 判定 | 月カレンダー | 最終メンテナンス日から当日までを活性化、他は非活性化
function isWithinDateRange(day) {

  const targetDate = new Date(
    calendarState.displayYear,
    calendarState.displayMonth - 1,
    day
  );

  const todayDate = new Date(
    calendarConfig.maxDate.year,
    calendarConfig.maxDate.month - 1,
    calendarConfig.maxDate.day
  );

  // 本日より前日だけ活性化（仕様変更のため）
  // 元に戻す場合は下記コメントを外す　
  return targetDate <= todayDate;
  // return targetDate >= startDate && targetDate <= todayDate;
}


/******************************************
 * 水平型カレンダーセクション
 * （#horizontalCalendar に生成する横スクロールカレンダー）
 * グリッド型カレンダーと calendarConfig・calendarState を共有する
 ******************************************/
// 表示日数 | 選択できる日（本日を含む過去日数）
const HORIZONTAL_CALENDAR_PAST_DAYS = 29;
// 表示日数 | 選択できない日（本日を含まない未来日数）
const HORIZONTAL_CALENDAR_FUTURE_DAYS = 7;
// 画面に表示される日数（先頭と末尾は50%だけ見える状態になる）
const HORIZONTAL_CALENDAR_VISIBLE_DAYS = 9;
// 曜日ラベル
const HORIZONTAL_CALENDAR_WEEKDAY_LABELS = ["日", "月", "火", "水", "木", "金", "土"];

// 水平型カレンダー | 「本日」を表す基準日を取得
// 現状は calendarState.selectedDate を基準にしている（本来の「本日」ではない）
// 本日の日付を自動取得する処理に対応したら、ここを置き換える
function getHorizontalCalendarAnchorDate() {
  return new Date(
    calendarState.selectedDate.year,
    calendarState.selectedDate.month - 1,
    calendarState.selectedDate.day
  );
}

// 水平型カレンダー | 表示する日付データを作成
// 基準日から見て 過去 HORIZONTAL_CALENDAR_PAST_DAYS 日 ～ 未来 HORIZONTAL_CALENDAR_FUTURE_DAYS 日 分を生成する
function buildHorizontalCalendarDays(anchorDate) {
  const days = [];
  for (
    let offset = -HORIZONTAL_CALENDAR_PAST_DAYS;
    offset <= HORIZONTAL_CALENDAR_FUTURE_DAYS;
    offset++
  ) {
    const date = new Date(anchorDate);
    date.setDate(date.getDate() + offset);
    days.push({
      year: date.getFullYear(),
      month: date.getMonth() + 1,
      day: date.getDate(),
      weekday: date.getDay(),
      isToday: offset === 0,
      // 本日を含む過去日のみ選択可能、未来日は選択不可（グレーアウト）
      isSelectable: offset <= 0,
    });
  }
  return days;
}

// 水平型カレンダー | 選択中の日付（calendarState.selectedDate）と一致するか判定
function isHorizontalCalendarSelectedDay(d) {
  return (
    Number(calendarState.selectedDate.year) === d.year &&
    Number(calendarState.selectedDate.month) === d.month &&
    Number(calendarState.selectedDate.day) === d.day
  );
}

// 水平型カレンダー | レンダリング
function renderHorizontalCalendar() {
  const viewport = document.getElementById("horizontalCalendarViewport");
  const track = document.getElementById("horizontalCalendarTrack");
  if (!viewport || !track) return;

  const anchorDate = getHorizontalCalendarAnchorDate();
  const days = buildHorizontalCalendarDays(anchorDate);

  // カレンダーを初期化
  track.innerHTML = "";

  days.forEach((d) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "horizontal-calendar-day";
    button.dataset.year = d.year;
    button.dataset.month = d.month;
    button.dataset.day = d.day;

    const weekSpan = document.createElement("span");
    weekSpan.className = "horizontal-calendar-day-week";
    weekSpan.textContent = HORIZONTAL_CALENDAR_WEEKDAY_LABELS[d.weekday];

    const numSpan = document.createElement("span");
    numSpan.className = "horizontal-calendar-day-num";
    numSpan.textContent = d.day;

    button.append(weekSpan, numSpan);

    if (!d.isSelectable) {
      // 選択できない日（未来日）はグレーアウトし、タップ不可にする
      button.classList.add("is-disabled");
      button.disabled = true;
    }
    if (isHorizontalCalendarSelectedDay(d)) {
      button.classList.add("active");
    }

    track.appendChild(button);
  });

  // セル幅を計算 | 可視幅をセル (表示日数 - 1) 分とすることで、先頭・末尾のセルが50%だけ見える状態になる
  const viewportWidth = viewport.clientWidth;
  const cellWidth = viewportWidth / (HORIZONTAL_CALENDAR_VISIBLE_DAYS - 1);
  track.querySelectorAll(".horizontal-calendar-day").forEach((btn) => {
    btn.style.width = `${cellWidth}px`;
  });

  // 本日が中央付近にくるよう初期スクロール位置を設定
  const todayIndex = HORIZONTAL_CALENDAR_PAST_DAYS;
  const centerOffset = Math.floor((HORIZONTAL_CALENDAR_VISIBLE_DAYS - 1) / 2);
  viewport.scrollLeft = (todayIndex - centerOffset) * cellWidth + cellWidth / 2;
}

// イベントデリゲーション | 水平型カレンダー | 日にちをタップ
document.addEventListener("click", (event) => {
  const dayButton = event.target.closest(
    "#horizontalCalendarTrack .horizontal-calendar-day"
  );
  if (!dayButton || dayButton.classList.contains("is-disabled")) return;

  // Stateへ代入（グリッド型カレンダーと共通）
  calendarState.selectedDate.year = Number(dayButton.dataset.year);
  calendarState.selectedDate.month = Number(dayButton.dataset.month);
  calendarState.selectedDate.day = Number(dayButton.dataset.day);
  // グリッド型カレンダーの表示月も選択日へ同期
  calendarState.displayYear = calendarState.selectedDate.year;
  calendarState.displayMonth = calendarState.selectedDate.month;

  // 選択日ラベルへ反映（グリッド型と水平型で状態を共有）
  renderSelectedDateLabel();
  renderHorizontalCalendar();
});

renderSelectedDateLabel();
renderHorizontalCalendar();


/******************************************
 * おやすみ音楽設定画面
 ******************************************/
document.addEventListener("click", (e) => {
  const el = e.target;

  // おやすみ音楽設定画面 | クリックイベント | 曲選択の操作アイコンをクリック
  const operateMusicBtn = el.closest(".js-operate-music");
  if (!operateMusicBtn) return;
  const id = operateMusicBtn.dataset.musicAction;
  if (renderDialogTemplate(id) === false) {
    return;
  }
  // showModal("modalDialogTemplate");
});

// ダイアログテンプレート | レンダリング
function renderDialogTemplate(id) {
  // if (!MASTER_DIALOG[id]) {
    // alert("デモアプリでは使用できません。");
  //   return false;
  // }
  // const descriptionElm = document.querySelector("#modalDialogTemplate .description");
  // const btnLeftElm = document.querySelector("#modalDialogTemplate .btnLeft");
  // const btnRightElm = document.querySelector("#modalDialogTemplate .btnRight");
  // descriptionElm.innerHTML = MASTER_DIALOG[id].description;
  // btnLeftElm.textContent = MASTER_DIALOG[id].btnLeft;
  // btnRightElm.textContent = MASTER_DIALOG[id].btnRight;
};


// エアコンかんたん設定モーダル | かんたん設定・こだわり設定のラジオボタンをレンダリング
function renderSelectAcSetupMethod() {
  const radioGroup = document.querySelector(
    '#selectAcSetupMethod .radio-group'
  );

  if (radioGroup) {
    renderRadioGroup(radioGroup);
  }
}

renderSelectAcSetupMethod();







// おやすみ音楽設定画面 | 音量設定 | 水平スライダー
// const svg = document.querySelector('.volume-settings-slider');
// const thumb = svg.querySelector('[data-slider="thumb"]');
// const trackLeft = svg.querySelector('[data-slider="track-left"]');
// const trackRight = svg.querySelector('[data-slider="track-right"]');
// SVGのサイズ
// const sliderWidth = 315;
// thumbの半径
// const thumbRadius = 13;
// thumb中心が動ける範囲
// const minX = thumbRadius;
// const maxX = sliderWidth - thumbRadius;
// ドラッグ状態
// let isDragging = false;

// --------------------------------
// スライダーを描画
// --------------------------------
function renderSlider(x) {

  // thumb
  thumb.setAttribute('cx', x);

  // thumbの左右端
  const left = x - thumbRadius;
  const right = x + thumbRadius;

  // 左側：紫
  trackLeft.setAttribute('width', left);

  // 右側：グレー
  trackRight.setAttribute('x', right);
  trackRight.setAttribute('width', sliderWidth - right);
}

// --------------------------------
// トップ画面（睡眠設定）
// --------------------------------



// トップ画面（睡眠設定） | 時刻ハンドルの円周ドラッグ
function initTopSleepTimeHandles() {
  const svg = document.querySelector('.settingDial[data-state-value="edit"] svg');
  if (!svg || svg.dataset.timeHandlesBound === 'true') return;

  const handles = [
    { element: svg.querySelector('#sleepTime'), baseX: 85, baseY: 41, angle: Math.atan2(41 - 150, 85 - 150), time: '22:00' },
    { element: svg.querySelector('#wakeTime'), baseX: 278, baseY: 150, angle: 0, time: '06:00' },
  ];
  if (handles.some((handle) => !handle.element)) return;
  handles.forEach((handle) => {
    handle.label = [...svg.querySelectorAll('text')].find((text) => text.textContent.trim() === handle.time);
  });
  const trackSegments = [...svg.querySelectorAll('#track > path')];

  svg.dataset.timeHandlesBound = 'true';
  const center = { x: 150, y: 150 };
  const radius = 127;
  const stepsPerDay = 144;
  const minSleepSteps = 24;
  const maxSleepSteps = 132;
  let activeHandle = null;
  let activePointerId = null;

  const updateTrack = () => {
    const sleepStep = Math.round((((handles[0].angle + Math.PI / 2 + Math.PI * 2) % (Math.PI * 2))
      / (Math.PI * 2)) * stepsPerDay) % stepsPerDay;
    const wakeStep = Math.round((((handles[1].angle + Math.PI / 2 + Math.PI * 2) % (Math.PI * 2))
      / (Math.PI * 2)) * stepsPerDay) % stepsPerDay;
    const duration = (wakeStep - sleepStep + stepsPerDay) % stepsPerDay;

    trackSegments.forEach((segment, index) => {
      const isSleepInterval = (index - sleepStep + stepsPerDay) % stepsPerDay < duration;
      const fill = isSleepInterval ? '#FFFFFF' : '#000000';
      segment.setAttribute('fill', fill);
      segment.setAttribute('stroke', fill);
      segment.setAttribute('stroke-width', '0.5');
      segment.setAttribute('stroke-linejoin', 'round');
    });
  };

  const updateHandlePosition = (handle, event) => {
    const screenMatrix = svg.getScreenCTM();
    if (!screenMatrix) return;
    const svgPoint = new DOMPoint(event.clientX, event.clientY).matrixTransform(screenMatrix.inverse());
    const angle = Math.atan2(svgPoint.y - center.y, svgPoint.x - center.x);
    let tenMinuteStep = Math.round((((angle + Math.PI / 2 + Math.PI * 2) % (Math.PI * 2))
      / (Math.PI * 2)) * stepsPerDay) % stepsPerDay;
    const sleepStep = Math.round((((handles[0].angle + Math.PI / 2 + Math.PI * 2) % (Math.PI * 2))
      / (Math.PI * 2)) * stepsPerDay) % stepsPerDay;
    const wakeStep = Math.round((((handles[1].angle + Math.PI / 2 + Math.PI * 2) % (Math.PI * 2))
      / (Math.PI * 2)) * stepsPerDay) % stepsPerDay;

    if (handle === handles[0]) {
      const duration = (wakeStep - tenMinuteStep + stepsPerDay) % stepsPerDay;
      const boundedDuration = Math.max(minSleepSteps, Math.min(maxSleepSteps, duration));
      tenMinuteStep = (wakeStep - boundedDuration + stepsPerDay) % stepsPerDay;
    } else {
      const duration = (tenMinuteStep - sleepStep + stepsPerDay) % stepsPerDay;
      const boundedDuration = Math.max(minSleepSteps, Math.min(maxSleepSteps, duration));
      tenMinuteStep = (sleepStep + boundedDuration) % stepsPerDay;
    }

    const snappedAngle = tenMinuteStep / stepsPerDay * Math.PI * 2 - Math.PI / 2;
    const x = center.x + Math.cos(snappedAngle) * radius;
    const y = center.y + Math.sin(snappedAngle) * radius;
    handle.angle = snappedAngle;
    handle.element.setAttribute('transform', `translate(${x - handle.baseX} ${y - handle.baseY})`);
    updateTrack();
    if (handle.label) {
      const minutes = tenMinuteStep * 10;
      handle.label.querySelector('tspan').textContent = `${String(Math.floor(minutes / 60)).padStart(2, '0')}:${String(minutes % 60).padStart(2, '0')}`;
    }
  };

  updateTrack();

  const endDrag = (event) => {
    if (activePointerId !== event.pointerId) return;
    activeHandle.element.style.cursor = 'grab';
    activeHandle = null;
    activePointerId = null;
  };

  handles.forEach((handle) => {
    handle.element.style.touchAction = 'none';
    handle.element.style.cursor = 'grab';
  });

  svg.addEventListener('pointerdown', (event) => {
    if (activePointerId !== null) return;
    const target = event.target instanceof Element ? event.target.closest('#sleepTime, #wakeTime') : null;
    const handle = handles.find((candidate) => candidate.element === target);
    if (!handle) return;

    activeHandle = handle;
    activePointerId = event.pointerId;
    handle.element.style.cursor = 'grabbing';
    svg.setPointerCapture(event.pointerId);
    updateHandlePosition(handle, event);
    event.preventDefault();
  });

  svg.addEventListener('pointermove', (event) => {
    if (!activeHandle || activePointerId !== event.pointerId) return;
    updateHandlePosition(activeHandle, event);
  });

  svg.addEventListener('pointerup', endDrag);
  svg.addEventListener('pointercancel', endDrag);
  svg.addEventListener('lostpointercapture', endDrag);
}


// --------------------------------
// トップ画面（レポート）
// --------------------------------

// トップ画面（レポート） | 状態管理
const topReportScreenState = {
  entryRoomTemperatureCheck: 'hot3',
  entryComfortRating: 'nice1',
  comfortRatingCold: 'cold0', // cold0 | cold1 | cold2 | cold3
  comfortRatingNice: 'nice0', // nice1
  comfortRatingHot: 'hot0' // hot0 | hot1 | hot2 | hot3
}

// トップ画面（レポート） | クリックイベント
document.addEventListener("click", (e) => {
  const el = e.target;
  // トップ画面（レポート） | クリックイベント | 評価
  const comfortRatingBtn = el.closest('[data-value="cold"] img, [data-value="nice"] img, [data-value="hot"] img');
  if (comfortRatingBtn) {
      const mode = comfortRatingBtn.dataset.link ?? null;
      if(mode.startsWith('cold')) {
        topReportScreenState.comfortRatingCold = mode;
      } else if(mode.startsWith('nice')) {
        topReportScreenState.comfortRatingNice = mode;
      } else if(mode.startsWith('hot')) {
        topReportScreenState.comfortRatingHot = mode;
      }
      topReportScreenState.entryRoomTemperatureCheck = mode;
      renderRoomTemperatureCheck();
      renderComfortRatingSection();
  }
});

// --------------------------------
// トップ画面（レポート）
// --------------------------------

// トップ画面（レポート） | レンダリング | 快適度評価
function renderRoomTemperatureCheck() {
  const key = topReportScreenState.entryRoomTemperatureCheck;
  const roomTempElements = document.querySelectorAll('.js-room-temperature-check');
  roomTempElements.forEach((roomTempElement) => {
    if (roomTempElement.dataset.key === key) {
      roomTempElement.classList.toggle('d-none', false);
    } else {
      roomTempElement.classList.toggle('d-none', true);
    }
  });
}

// トップ画面（レポート） | レンダリング | 快適度アイコン
function renderComfortRatingSection() {
  const coldIcons = document.querySelectorAll('#comfortRatingSection [data-value="cold"] img');
  const niceIcons = document.querySelectorAll('#comfortRatingSection [data-value="nice"] img');
  const hotIcons = document.querySelectorAll('#comfortRatingSection [data-value="hot"] img');

  const iconCold = topReportScreenState.comfortRatingCold
  const iconNice = topReportScreenState.comfortRatingNice
  const iconHot = topReportScreenState.comfortRatingHot

  coldIcons.forEach((img) => {
    const shouldDisplay = img.dataset.value === iconCold;
    const animationSrc = img.dataset.animationSrc ?? img.src;
    if (shouldDisplay && img.classList.contains('d-none') && animationSrc.split('?')[0].toLowerCase().endsWith('.gif')) {
      img.dataset.animationSrc = animationSrc;
      img.src = `${animationSrc}?animation=${Date.now()}`;
    }
    img.classList.toggle('d-none', !shouldDisplay);
  });
  niceIcons.forEach((img) => {
    img.dataset.value === iconNice ? img.classList.toggle('d-none', false) : img.classList.toggle('d-none', true);
  });
  hotIcons.forEach((img) => {
    img.dataset.value === iconHot ? img.classList.toggle('d-none', false) : img.classList.toggle('d-none', true);
  });
}

// --------------------------------
// エアコン設定画面
// --------------------------------

// エアコン設定画面 | 状態管理
const acSettingsScreenState = {
  state: getJsonValue('acSettings.state'),
}

// エアコン設定画面 | クリックイベント
document.addEventListener("click", (e) => {
  const el = e.target;
  // トップ画面（睡眠設定） | クリックイベント | 表示設定
  const automaticOperationToggle = el.closest('[data-state-key="automaticOperation"]');
  if (!automaticOperationToggle) return;
  acSettingsScreenState.state = !acSettingsScreenState.state;
  renderAcSettingsScreen();

});

// --------------------------------
// エアコンのこだわり設定画面
// --------------------------------

// エアコンのこだわり設定 | 状態管理
const acCustomSettingsState = {
  // おやすみ温度設定
  sleepTempSet: {
    cooling: {
      tempSet: 26.5,
      startTemp: 28.0
    },
    heating: {
      tempSet: 20.0,
      startTemp: 18.0
    }
  },
  // おまかせ温度設定
  autoTempSet: {
    isOpen: false,
    state: true,
  },
  // 就寝中の冷房
  coolingWhileSleeping: {
    isOpen: false,
    operatingTime: "運転時間：1時間",
  },
  // 就寝前の予冷
  preCoolingBeforeSleeping: {
    isOpen: false,
    operatingTime: "運転継続時間：30分",
  },
  // 就寝前の予暖
  preHeatingBeforeSleeping: {
    isOpen: false,
    operatingTime: "運転継続時間：30分",
  },
  // 風速（オプション機能）
  windSpeed: {
    isOpen: false,
    state: true,
    mode: 'auto' // auto | device
  },
};

// エアコンのこだわり設定 | レンダリング
function renderAcCustomSettingsScreen() {
  renderToggleComponents();
  renderRadioComponents();
  renderTextContent();
  renderDescription();
  initAcCustomSettingsSliders();
}

// エアコンのこだわり設定 | レンダリング | 各セクションへテキスト代入（例：運転時間：1時間 など）
function renderTextContent() {
  const sections = [
    'autoTempSet',
    'coolingWhileSleeping',
    'preCoolingBeforeSleeping',
    'preHeatingBeforeSleeping',
    'windSpeed',
  ];
  sections.forEach((id) => {
    const element = document.querySelector(`#${id} .switch-text`);
    if (element) {
      if (id === 'autoTempSet') {
        element.textContent = (acCustomSettingsState[id].state ? '有効' : '無効')
      } else if (id === 'windSpeed') {
        element.textContent = '';
      } else {
        element.textContent = acCustomSettingsState[id].operatingTime;
      }
    }
  });
}

// エアコンのこだわり設定 | テキスト表示切り替え | アコーディオン開閉時のボタン部テキスト表示切り替え
function renderDescription() {
  const sections = [
    'autoTempSet',
    'coolingWhileSleeping',
    'preCoolingBeforeSleeping',
    'preHeatingBeforeSleeping',
    'windSpeed',
  ];
  sections.forEach((id) => {
    const isOpen = acCustomSettingsState[id].isOpen;
    document.querySelector(`#${id} .switch-text`)
      ?.classList.toggle('d-none', isOpen);
    document.querySelector(`#${id} .description`)
      ?.classList.toggle('d-none', !isOpen);
  });
}

/******************************************
 * エアコンのこだわり画面｜クリックイベント
 ******************************************/
document.addEventListener("click", (e) => {
  const el = e.target;

  // 冷房の設定温度・起動室温、暖房の設定温度・起動室温、就寝中の冷房運転時間、就寝前の予冷・予暖運転継続時間
  const btn = el.closest('#coolingSetTemperature, #coolingStartUpRoomTemperature, #heatingSetTemperature, #heatingStartUpRoomTemperature, [data-key="coolingWhileSleeping"], [data-key="preCoolingHeatingBeforeSleeping"]');
  let key = "";
  if (btn) {
    btn.id ? key = btn.id : key = btn.dataset.key;
    setModalElements(key)
  }

  // ↑ クリックイベントの処理はここまで
});

// エアコンのこだわり設定画面 | クリックイベント | アコーディオンの開閉
document.querySelectorAll('.accordion-button-custom').forEach(button => {
  button.addEventListener('click', () => {
    const accordionItem = button.closest('.accordion-item');
    const id = accordionItem.id;
    acCustomSettingsState[id].isOpen = !acCustomSettingsState[id].isOpen;
    const isOpen = acCustomSettingsState[id].isOpen;
    accordionItem.classList.toggle('is-open', isOpen);
    button.setAttribute('aria-expanded', isOpen);
    renderDescription()
    // アコーディオンを開いたとき、画面からはみ出さないようにスクロールする処理
    if (isOpen) {
      setTimeout(() => {
        accordionItem.scrollIntoView({
          behavior: 'smooth',
        });
      }, 100); // 100ミリ秒の遅延
    }
  });
});

// エアコンのこだわり設定画面 | 選択モーダル表示
function showTimeSelectionDialog(dialog) {
  document.querySelector('#modalDialogButtonsOnHeader .title').textContent = dialog.title;
  document.querySelectorAll('#modalDialogButtonsOnHeader .option')
    .forEach((element, index) => {
      element.textContent = dialog.options[index] ?? '';
    });
  showModal('modalDialogButtonsOnHeader');
}


// --------------------------------
// 共通
// --------------------------------

// 共通 | 表示設定 | トグルの状態でセクションを表示・非表示
function setSectionDisplay(state, sectionKey) {
  const section = document.querySelector(`[data-depends-on="${sectionKey}"]`);
  section.classList.toggle('is-disabled', !state)
}

// 共通 | モーダル | モーダル表示
function setModalElements(key) {
  const dialog = MASTER_DIALOG[key] ?? MASTER_DIALOG.oyasumiSupportTimeSettings?.[key];
  if (!dialog) return;
  const modalTitle = document.querySelector('#modalDialogButtonsOnHeader .title');
  const optionElements = document.querySelectorAll('.value .option');
  modalTitle.textContent = dialog.title;
  (dialog.options ?? dialog.optionsLeft ?? []).forEach((value, index) => {
    if (optionElements[index]) {
      optionElements[index].textContent = value;
    }
  });
  showModal('modalDialogButtonsOnHeader');
}

// 共通 | モーダル | モーダル表示（2カラム）
function setModalElementsTwoColumn(key) {
  const dialog = MASTER_DIALOG.oyasumiSupportTimeSettings?.[key];
  if (!dialog) return;
  const modalTitle = document.querySelector('#modalDialogTwoColumn .title');
  modalTitle.textContent = dialog.title;
  const optionLeftElements = document.querySelectorAll('.left.value .option');
  (dialog.options ?? dialog.optionsLeft ?? []).forEach((value, index) => {
    if (optionLeftElements[index]) {
      optionLeftElements[index].textContent = value;
    }
  });
  const optionRightElements = document.querySelectorAll('.right.value .option');
  (dialog.optionsRight ?? []).forEach((value, index) => {
    if (optionRightElements[index]) {
      optionRightElements[index].textContent = value;
    }
  });
}

// おやすみ音楽設定画面 | 音量設定
// function initAudioVolume() {
//   const svg = document.getElementById('volumeSlider');
//   const trackLeft = svg.querySelector('[data-slider="track-left"]');
//   const trackRight = svg.querySelector('[data-slider="track-right"]');
//   const thumbGroup = svg.querySelector('#thumbGroup');

//   let isDragging = false;

//   // SVG全体のビューボックス幅
//   const viewBoxWidth = 315;
//   const minX = 13; // ツマミがはみ出さない最小X座標（左端のパディング等に合わせる）
//   const maxX = viewBoxWidth - 9; // 右端の制限

//   // マウスが押されたらドラッグ開始
//   svg.addEventListener('mousedown', (e) => {
//     isDragging = true;
//     updateSlider(e);
//     e.preventDefault(); // テキスト選択などを防止
//   });

//   // マウス移動中
//   document.addEventListener('mousemove', (e) => {
//     if (!isDragging) return;
//     updateSlider(e);
//   });

//   // マウスを離したら終了
//   document.addEventListener('mouseup', () => {
//     isDragging = false;
//   });

//   // スライダーの位置を計算して各パーツを更新する関数
//   function updateSlider(e) {
//     // 1. 画面上のSVG要素の位置・サイズを取得
//     const rect = svg.getBoundingClientRect();

//     // 2. SVG内でのマウスのX座標（ピクセル）を計算
//     const mouseXPixel = e.clientX - rect.left;

//     // 3. 画面上のピクセル幅を、SVGの viewBox (0〜315) の座標系に変換
//     let x = (mouseXPixel / rect.width) * viewBoxWidth;

//     // 4. 可動範囲（最小値〜最大値）に制限（クランプ）
//     x = Math.max(minX, Math.min(x, maxX));

//     // --- 各パーツの数値をリアルタイムに書き換え ---

//     // ① 左側トラックの幅を更新 (起点は4、幅は x - 4)
//     const leftWidth = Math.max(0, x - 4);
//     trackLeft.setAttribute('width', leftWidth);

//     // ② 中央のツマミグループ全体を横移動させる場合（transformを使うと一括で動かせます）
//     // ※もしGroup 179ごと動かすならこれが一番簡単です
//     const centerBaseX = 157.5; // 初期の中央位置
//     const deltaX = x - centerBaseX;
//     thumbGroup.setAttribute('transform', `translate(${deltaX}, 0)`);

//     // ③ 右側トラックの位置と幅を更新
//     // 右トラックの開始位置はツマミの右端（x + 13）から
//     const rightX = x + 12.5;
//     const rightWidth = Math.max(0, viewBoxWidth - rightX);
//     trackRight.setAttribute('x', rightX);
//     trackRight.setAttribute('width', rightWidth);

//     // ④ 現在の音量などの割合（0.0 〜 1.0）が必要な場合
//     const ratio = (x - minX) / (maxX - minX);
//     // console.log("Current Value Ratio:", ratio);
//   }
// }

// エアコンのこだわり設定画面 | 温度スライダー
function initAcCustomSettingsSliders() {
  const svg = document.querySelector('#temptureSettings');
  if (!svg || svg.dataset.sliderInitialized) return;

  const thumbRadius = 15;
  const sliders = [
    { thumbId: 'circleCoolingRoomTemp', trackId: 'trackCoolingRoomTemp', baseY: 147, minTemp: 16, maxTemp: 31, step: 0.5, getValue: () => acCustomSettingsState.sleepTempSet.cooling.tempSet, setValue: (value) => { acCustomSettingsState.sleepTempSet.cooling.tempSet = value; }, displayKey: 'cooling-set' },
    { thumbId: 'circleCoolingStartUpRoomTemp', trackId: 'trackCoolingStartUpRoomTemp', baseY: 99, minTemp: 20, maxTemp: 35, step: 0.5, getValue: () => acCustomSettingsState.sleepTempSet.cooling.startTemp, setValue: (value) => { acCustomSettingsState.sleepTempSet.cooling.startTemp = value; }, displayKey: 'cooling-start' },
    { thumbId: 'circleHeatingStartUpRoomTemp', trackId: 'trackHeatingStartUpRoomTemp', baseY: 219, minTemp: 10, maxTemp: 25, step: 0.5, getValue: () => acCustomSettingsState.sleepTempSet.heating.startTemp, setValue: (value) => { acCustomSettingsState.sleepTempSet.heating.startTemp = value; }, displayKey: 'heating-start' },
    { thumbId: 'circleHeatingSetTemperature', trackId: 'trackHeatingSetTemperature', baseY: 181, minTemp: 16, maxTemp: 31, step: 0.5, getValue: () => acCustomSettingsState.sleepTempSet.heating.tempSet, setValue: (value) => { acCustomSettingsState.sleepTempSet.heating.tempSet = value; }, displayKey: 'heating-set' },
  ];
  const activeSliders = sliders.map((slider) => ({
    ...slider,
    thumb: svg.querySelector(`#${slider.thumbId}`),
    track: svg.querySelector(`#${slider.trackId}`),
    minY: Number(svg.querySelector(`#${slider.trackId}`).getAttribute('y')) + thumbRadius,
    maxY: Number(svg.querySelector(`#${slider.trackId}`).getAttribute('y')) + Number(svg.querySelector(`#${slider.trackId}`).getAttribute('width')) - thumbRadius,
    steps: (slider.maxTemp - slider.minTemp) / slider.step,
  })).filter((slider) => slider.thumb && slider.track);

  if (!activeSliders.length) return;
  svg.dataset.sliderInitialized = 'true';

  let activeSlider = null;

  activeSliders.forEach((slider) => {
    updateTemperatureDisplay(slider, slider.getValue());
    updateSliderThumb(slider, slider.getValue());
    [slider.thumb, slider.track].forEach((element) => {
      element.style.touchAction = 'none';
      element.style.cursor = 'pointer';
      element.addEventListener('pointerdown', (event) => {
        activeSlider = slider;
        svg.setPointerCapture(event.pointerId);
        updateSliderPosition(event);
        event.preventDefault();
      });
    });
  });

  svg.addEventListener('pointermove', (event) => {
    if (activeSlider) updateSliderPosition(event);
  });

  svg.addEventListener('pointerup', () => {
    activeSlider = null;
  });

  svg.addEventListener('pointercancel', () => {
    activeSlider = null;
  });

  function updateSliderPosition(event) {
    const point = svg.createSVGPoint();
    point.x = event.clientX;
    point.y = event.clientY;
    const y = point.matrixTransform(svg.getScreenCTM().inverse()).y;
    const boundedY = Math.max(activeSlider.minY, Math.min(y, activeSlider.maxY));
    const ratio = (activeSlider.maxY - boundedY) / (activeSlider.maxY - activeSlider.minY);
    const stepIndex = Math.round(ratio * activeSlider.steps);
    const value = Number((activeSlider.minTemp + stepIndex * activeSlider.step).toFixed(1));
    activeSlider.setValue(value);
    updateTemperatureDisplay(activeSlider, value);
    updateSliderThumb(activeSlider, value);
  }

  function updateTemperatureDisplay(slider, value) {
    const [integer, decimal] = value.toFixed(1).split('.');
    document.querySelectorAll(`[data-temperature-integer="${slider.displayKey}"]`)
      .forEach((element) => { element.textContent = `${integer}.`; });
    document.querySelectorAll(`[data-temperature-decimal="${slider.displayKey}"]`)
      .forEach((element) => { element.textContent = `${decimal}℃`; });
  }

  function updateSliderThumb(slider, value) {
    const ratio = (value - slider.minTemp) / (slider.maxTemp - slider.minTemp);
    const y = slider.maxY - ratio * (slider.maxY - slider.minY);
    slider.thumb.setAttribute('transform', `translate(0, ${y - slider.baseY})`);
  }
}


