const initialAppData = {
  currentPage: "mymu", // (mymu | automation | mymuPlus | notice)
  currentTriggerEvent: "schedule", // (schedule | location | statusOfDevice)
  automation: {
    selectedId: "auto-1",
    items: {
      "auto-1": {
        status: true,
        name: "冬の帰宅",
        triggers: [
          {
            type: "schedule",
            startTime: "18:00",
            days: ["mon", "tue", "wed", "thu", "fri"]
          }
        ],
        actions: [
          {
            type: "product",
            productId: "rac-living",
            drive: "on",
            mode: "heat",
            temperature: 20
          }
        ]
      },

      "auto-2": {
        status: true,
        name: "夏の帰宅",
        triggers: [
          {
            type: "schedule",
            startTime: "19:00",
            days: ["mon", "wed", "fri"]
          }
        ],
        actions: [
          {
            type: "product",
            productId: "rac-living",
            drive: "on",
            mode: "cool",
            temperature: 27
          }
        ]
      },

      "auto-3": {
        status: true,
        name: "高温おしらせ",
        triggers: [
          {
            type: "product",
            productId: "rac-living",
            condition: "temperatureAbove",
            threshold: 28
          }
        ],
        actions: [
          {
            type: "product",
            productId: "rac-living",
            drive: "on",
            mode: "cool",
            temperature: 27
          },
          {
            type: "notification",
            target: "mother",
            message: "リビングのエアコン 室温"
          }
        ]
      }
    }
  },
};

