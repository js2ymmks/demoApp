// トリガー・アクションカードマスター
const CARD_MASTER = {
  "scene": {
    icon: "",
    name: "",
    description: "",
  },
  "devices": {
    icon: "",
    name: "",
    description: "",
  },
  "notify": {
    icon: "",
    name: "",
    description: "",
  },
};

/******************************************
 * ユーティリティ：全画面
 * 対象：トグルスイッチ（button要素内にあるスイッチ）
 * アクション：クリック時の伝播を防ぐ
 ******************************************/
document.querySelectorAll(".form-check-input").forEach((toggle) => {
  toggle.addEventListener("click", (e) => {
    e.stopPropagation();
  });
});



// EVENT LISTENER（クリックイベント統合）
document.addEventListener("click", (e) => {
  let btn;


  btn = e.target.closest(".js-editable");
  if (btn)  markEdited();

  btn = e.target.closest(".js-drive");
  if (btn) handleDriveClick(btn);

  btn = e.target.closest(".js-mode");
  if (btn) handleModeClick(btn);  


});


// 完了ボタンの処理（編集された後、完了ボタンが活性化）
function markEdited() {
  if (AppState.isEdited) return;
  AppState.isEdited = true;
  const headerBtn = document.getElementById("headerRightBtn");
  if (!headerBtn) return;

  headerBtn.disabled = false;
  headerBtn.classList.remove("disabled");
  headerBtn.classList.add("active");
};

// エアコン・給湯機設定画面のクリックイベント（運転）
function handleDriveClick(btn){
  const drive = btn.dataset.appDrive;
  const entryId = getJsonValue("entryId");
  const actionId = getJsonValue("editActionId");
  const actions = getJsonValue(`${entryId}.actions`) ?? [];
  const action = actions.find(a => a.actionId === actionId);
  if(!action) return;

  /* JSON保存 */
  action.drive = drive;
  
  setJsonValue(`${entryId}.actions`, actions);

  /* UI排他 */
  document.querySelectorAll(".js-drive").forEach(el=>{
    const isActive = el.dataset.appDrive === drive;
    el.classList.toggle("active",isActive);
    el.setAttribute("aria-pressed",String(isActive));
  });
}

// エアコン設定画面のクリックイベント（モード）
function handleModeClick(btn){
  const mode = btn.dataset.appMode;
  const entryId = getJsonValue("entryId");
  const actionId = getJsonValue("editActionId");
  const actions = getJsonValue(`${entryId}.actions`) ?? [];

  const action = actions.find(a => a.actionId === actionId);
  if(!action) return;

  /* JSON保存 */
  action.mode = mode;
  setJsonValue(`${entryId}.actions`, actions);

  /* UI排他 */
  document.querySelectorAll(".js-mode").forEach(el=>{
    const isActive = el.dataset.appMode === mode;
    el.classList.toggle("active",isActive);
    el.setAttribute("aria-pressed",String(isActive));
  });
}


function goRoomTempStatus() {
  // 遷移先のURLを設定
  const url = "../select-room-temperature-status/";
  window.location.href = url;
};


// 完了ボタン処理
const initCompleteButton = () => {
  const btn = document.getElementById("headerRightBtn");
  if (!btn) return;
  AppState.isEdited = false;
  btn.disabled = true;
  btn.classList.add("disabled");
};



// 「機器の操作を選択」「機器の状態を追加」 ボタンからの遷移
document.addEventListener("DOMContentLoaded", () => {

  const section = document.querySelector(".js-select-device-section");
  if (!section) return;

  section.addEventListener("click", (e) => {

    const deviceBtn = e.target.closest(".js-select-device-btn");
    if (!deviceBtn) return;

    const deviceId = deviceBtn.dataset.appDevice;
    const entryDeviceCard = getJsonValue("entryDeviceCard");   // trigger / action
    const entryId = getJsonValue("entryId");
    

    if (!entryId) return;

    const device = getJsonValue(`${entryId}.triggers.devices`);  

    /* -----------------------------
       トリガー（機器状態）
    ----------------------------- */

    if (entryDeviceCard === "trigger") {

      setJsonValue(`${entryId}.triggers.devices`, {
        id: deviceId
      });

      // const url = ACTION_MASTER.devices[deviceId]?.url;
      // const url = "../select-device-operation/";

      // if (url) window.location.href = url;

      return;
    }

    /* -----------------------------
       アクション（機器操作）
    ----------------------------- */

    let actions = getJsonValue(`${entryId}.actions`) ?? [];

    if (actions.length >= 5) return;

    actions.push({
      actionId: createId(),
      type: "devices",
      id: deviceId
    });

    const actionId = actions[actions.length - 1].actionId;

    setJsonValue(`${entryId}.actions`, actions);
    setJsonValue("editActionId", actionId);

    const url = ACTION_MASTER.devices[deviceId]?.url;
    // if (url) window.location.href = url;

  });

});

document.addEventListener("click", function (e) {
  const btn = e.target.closest(".js-drive");
  if (!btn) return;
  const isDriveOn = btn.dataset.appIsDrive === "true";
  updateDriveState(isDriveOn);
});
