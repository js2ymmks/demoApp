const demoAppJson = {
  jsonName: '04-GoodShareSettingsDemoAppRac',
  version: '1.0.0',
  slides: [
    {
      index: 0,
      alt: 'STEP-01',
      imagePath: '../assets/img/01401.svg',
      tooltipTarget: 'targetArea01401',
      tooltipDescription: '☰メニューをタップする',
      footerContent: '',
    },
    {
      index: 1,
      alt: 'STEP-02',
      imagePath: '../assets/img/01402.svg',
      tooltipTarget: 'targetArea01402',
      tooltipDescription: '「＋機器登録」をタップする',
      footerContent: '',
    },
    {
      index: 2,
      alt: 'STEP-03',
      imagePath: '../assets/img/01403.svg',
      tooltipTarget: 'targetArea01403',
      tooltipDescription: '「エアコン」をタップする',
      footerContent: '',
    },
    {
      index: 3,
      alt: 'STEP-04',
      imagePath: '../assets/img/01501.svg',
      tooltipTarget: 'targetArea10601',
      tooltipDescription: '「ハウジングエアコン」をタップする',
      footerContent: '',
    },

    {
      index: 4,
      alt: 'STEP-05',
      imagePath: '../assets/img/10701.svg',
      tooltipTarget: 'targetArea10701',
      tooltipDescription:
        '機器とルーターの接続方法を選択します。<br><button type="button" class="btn btn-outline-primary mt-2 d-block mx-auto" data-bs-toggle="modal" data-bs-target="#modalCommon107">選択メニューを表示</button>',
      footerContent:
        'ルーターにWPS機能がない場合はアクセスポイントモードで接続、WPS機能がある場合はルーターの「WPS」ボタンを使って接続してください。<span class="fw-medium text-danger">WPS機能がない場合はWPSによる接続はできません。</span>',
    },
    {
      index: 5,
      alt: 'STEP-06',
      imagePath: '../assets/img/01801.svg',
      tooltipTarget: 'targetArea01801',
      tooltipDescription: '画面の内容を確認し、「次へ」をタップする',
      footerContent: '',
    },
    {
      index: 6,
      alt: 'STEP-07',
      imagePath: '../assets/img/01802.svg',
      tooltipTarget: 'targetArea01802',
      tooltipDescription: '画面の内容を確認し、「次へ」をタップする',
      footerContent:
        '<ul><li>事前に以下の準備をしてください。<i class="bi bi-1-circle"></i>接続したいルーターのSSID(2.4GHz)、<i class="bi bi-2-circle"></i>ルーターに接続する暗号化キー(パスワード)</li><li>本アプリでルーターのSSIDに使用できる文字は<a class="footer-link" data-bs-toggle="modal" data-bs-target="#modalCommon018">半角英数字、半角記号、半角スペース</a>です。</li></ul>',
    },
    {
      index: 7,
      alt: 'STEP-08',
      imagePath: '../assets/img/01901.svg',
      tooltipTarget: 'targetArea01901',
      tooltipDescription: '画面の内容を確認し、「次へ」をタップする',
      footerContent: '',
    },
    {
      index: 8,
      alt: 'STEP-09',
      imagePath: '../assets/img/02001.svg',
      tooltipTarget: 'targetArea02001',
      tooltipDescription: '画面の内容を操作し、「次へ」をタップする',
      footerContent:
        '<ul><li><a class="footer-link" data-bs-toggle="modal" data-bs-target="#modalCommon111">エアコンをアクセスポイント（APモード）にする</a></li><li>詳しくは<a href="https://www.mitsubishielectric.co.jp/home/mymu/entry_ib_pdf.html">機器登録説明書、または機器個別の登録手順</a>（各機器の登録部分を抜粋した説明書）から、機器を登録する事項を確認ください。</li></ul>',
    },
    {
      index: 9,
      alt: 'STEP-10',
      imagePath: '../assets/img/02201.svg',
      tooltipTarget: 'targetArea02201',
      tooltipDescription: '画面の内容を確認し、「次へ」をタップする',
      footerContent: '',
    },
    {
      index: 10,
      alt: 'STEP-11',
      imagePath: '../assets/img/11202.svg',
      tooltipTarget: 'targetArea11202',
      tooltipDescription: '画面の内容を確認し、「次へ」をタップする',
      footerContent:
        '<a class="footer-link" data-bs-toggle="modal" data-bs-target="#modalCommon113">設定情報シールを確認する</a>',
    },
    {
      index: 11,
      alt: 'STEP-12',
      imagePath: '../assets/img/02202.svg',
      tooltipTarget: 'targetArea02202',
      tooltipDescription: '「スマートフォンの設定画面へ」をタップして設定する',
      footerContent:
        '<ul><li><a class="footer-link" data-bs-toggle="modal" data-bs-target="#modalCommon054">エアコンとスマートフォンを接続する</a></li></ul>',
    },
    {
      index: 12,
      alt: 'STEP-13',
      imagePath: '../assets/img/02501.svg',
      tooltipTarget: 'targetArea02501',
      tooltipDescription: '画面の内容を確認し、「次へ」をタップする',
      footerContent:
        '<ul><li>ルーターのSSID（2.4GHz）と暗号化キー（パスワード）をお手元に準備してください。次の操作で使用します。</li></ul>',
    },
    {
      index: 13,
      alt: 'STEP-14',
      imagePath: '../assets/img/02601.svg',
      tooltipTarget: 'targetArea02601',
      tooltipDescription:
        'タップして<a class="footer-link" data-bs-toggle="modal" data-bs-target="#modalCommon02601">一覧画面</a>を表示、接続するルーターのSSIDを選択する',
      footerContent:
        '<ul><li><a class="footer-link" data-bs-toggle="modal" data-bs-target="#modalCommon02602">SSIDと暗号化キーの表示例</a></li><li><a class="footer-link" data-bs-toggle="modal" data-bs-target="#modalCommon027">SSIDは手動でも入力できます。</a></li></ul>',
    },
    {
      index: 14,
      alt: 'STEP-15',
      imagePath: '../assets/img/02602.svg',
      tooltipTarget: 'targetArea02602',
      tooltipDescription:
        'ルーターの暗号化キー(パスワード)を入力、「接続する」をタップする',
      footerContent:
        '<ul><li><a class="footer-link" data-bs-toggle="modal" data-bs-target="#modalCommon02603">「前回使用した暗号化キーを入力する」</a>を選択すると、前回使用した暗号化キーを自動入力できます。</li></ul>',
    },
    {
      index: 15,
      alt: 'STEP-16',
      imagePath: '../assets/img/02801.svg',
      tooltipTarget: 'targetArea02801',
      tooltipDescription: '機器の登録が終わるまで、2～3分程度待つ',
      footerContent:
        '<ul><li><a class="footer-link" data-bs-toggle="modal" data-bs-target="#modalCommon02801">機器の登録に失敗した場合</a></li><li><a class="footer-link" data-bs-toggle="modal" data-bs-target="#modalCommon02802">「機器の登録確認」が表示された場合</a></li><li>登録された機器を削除する場合は<a href="https://www.mitsubishielectric.co.jp/home/mymu/ib.html">MyMUアプリの取扱説明書</a>を確認ください（ユーザー種別が「管理者」のみ行えます）。</li><li>機器を工場出荷時の状態に戻す場合は<a href="https://www.mitsubishielectric.co.jp/ldg/wink/ssl/searchProduct.do?ccd=104010">エアコン</a>、<a href="https://www.mitsubishielectric.co.jp/ldg/wink/ssl/displayProduct.do?pid=318322&ccd=1040128812">スマートスイッチ</a>、<a href="https://www.mitsubishielectric.co.jp/ldg/wink/ssl/displayProduct.do?pid=318325&ccd=1040128814">環境センサー</a>の取扱説明書を確認ください。</li></ul>',
    },
    {
      index: 16,
      alt: 'STEP-17',
      imagePath: '../assets/img/03001.svg',
      tooltipTarget: 'targetArea03001',
      tooltipDescription:
        '登録が完了したら、「エアコン初期設定へ」をタップする',
      footerContent: '',
    },
    {
      index: 17,
      alt: 'STEP-18',
      imagePath: '../assets/img/03002.svg',
      tooltipTarget: 'targetArea03002',
      tooltipDescription: '「宅外操作」を有効、「次へ」をタップする',
      footerContent:
        'MyMUアプリでエアコンを操作するためには、宅外操作を必ず有効(<i class="bi bi-toggle-on"></i>)に設定してください。',
    },
    {
      index: 18,
      alt: 'STEP-19',
      imagePath: '../assets/img/03101.svg',
      tooltipTarget: 'targetArea06201',
      tooltipDescription:
        '「アプリを起動する」をタップ、霧ヶ峰アプリを起動させる',
      footerContent:
        '<ul><li>エアコン登録と初期設定が完了しました。霧ヶ峰アプリの使い方については、霧ヶ峰アプリの取扱説明書を確認ください。</li><li>エアコン名は設置されている部屋名称に変更することをお勧めします(リビングのエアコンなど)。変更方法は<a href="https://www.mitsubishielectric.co.jp/home/mymu/ib.html">MyMUアプリの取扱説明書</a>から、「登録機器一覧を確認する」の事項を確認ください（ユーザー種別が「管理者」のみ行えます）。</li></ul>',
    },
    {
      index: 19,
      alt: 'STEP-20',
      imagePath: '../assets/img/03201.svg',
      tooltipTarget: 'targetArea03201',
      tooltipDescription: '画面の内容を確認し、「次へ」をタップする',
      footerContent: 'ここからは、WPS機能で接続する手順を説明します。',
    },
    {
      index: 20,
      alt: 'STEP-21',
      imagePath: '../assets/img/03202.svg',
      tooltipTarget: 'targetArea03202',
      tooltipDescription: '画面の内容を確認し、「次へ」をタップする',
      footerContent:
        '<ul><li>事前に以下の準備をしてください。<i class="bi bi-1-circle"></i>接続したいルーターの場所、<i class="bi bi-2-circle"></i>ルーターのWPS実施方法</li><li>ルーターのWPS実施方法は機器により異なります。詳しくはルーターの取扱説明書を確認ください。</li></ul>',
    },
    {
      index: 21,
      alt: 'STEP-22',
      imagePath: '../assets/img/03301.svg',
      tooltipTarget: 'targetArea03301',
      tooltipDescription: '画面の内容を操作し、「次へ」をタップする',
      footerContent:
        '<ul><li><a class="footer-link" data-bs-toggle="modal" data-bs-target="#modalCommon125">リモコンを使ってエアコンを接続モードにする</a></li></ul>',
    },
    {
      index: 22,
      alt: 'STEP-23',
      imagePath: '../assets/img/03501.svg',
      tooltipTarget: 'targetArea03501',
      tooltipDescription: '画面の内容を操作し、「次へ」をタップする',
      footerContent:
        '<ul><li><a class="footer-link" data-bs-toggle="modal" data-bs-target="#modalCommon035">ルーターをWPSモードにする</a></li></ul>',
    },
    {
      index: 23,
      alt: 'STEP-24',
      imagePath: '../assets/img/03601.svg',
      tooltipTarget: 'targetArea03601',
      tooltipDescription: '画面の内容を操作し、「次へ」をタップする',
      footerContent:
        '<ul><li><a class="footer-link" data-bs-toggle="modal" data-bs-target="#modalCommon036">エアコンとルーターの接続が完了したことを確認する</a></li><li><a class="footer-link" data-bs-toggle="modal" data-bs-target="#modalCommon03602">接続に失敗したときは</a></li></ul>',
    },

    {
      index: 24,
      alt: 'STEP-25',
      imagePath: '../assets/img/03901.svg',
      tooltipTarget: 'targetArea03901',
      tooltipDescription: '画面の内容を確認し、「次へ」をタップする',
      footerContent:
        '<ul><li><a class="footer-link" data-bs-toggle="modal" data-bs-target="#modalCommon03901">スマートフォンの接続先を確認する</a></li><li><a class="footer-link" data-bs-toggle="modal" data-bs-target="#modalCommon03902">「"MyMU"がローカルネットワーク上のデバイスの検索および接続を求めています」</a>と表示されたら</li></ul>',
    },
    {
      index: 25,
      alt: 'STEP-26',
      imagePath: '../assets/img/04001.svg',
      tooltipTarget: 'targetArea04001',
      tooltipDescription: '登録するエアコンをタップする',
      footerContent:
        '<ul><li>複数の機器が表示された場合、<img class="mt-0 align-text-bottom" src="../assets/img/rac/buzzer.svg">ブザー鳴動ボタンをタップし、登録するエアコンからブザー音が鳴ることを確認ください。</li><li><a class="footer-link" data-bs-toggle="modal" data-bs-target="#modalCommon02802">エアコンが別のユーザーに登録されている場合</a></li></ul>',
    },
    {
      index: 26,
      alt: 'STEP-27',
      imagePath: '../assets/img/03001.svg',
      tooltipTarget: 'targetArea03001-01',
      tooltipDescription:
        '登録が完了したら、「エアコン初期設定へ」をタップする',
      footerContent: '',
    },
    {
      index: 27,
      alt: 'STEP-28',
      imagePath: '../assets/img/03002.svg',
      tooltipTarget: 'targetArea03002-01',
      tooltipDescription: '「宅外操作」を有効、「次へ」をタップする',
      footerContent:
        'MyMUアプリでエアコンを操作するためには、宅外操作を必ず有効(<i class="bi bi-toggle-on"></i>)に設定してください。',
    },
    {
      index: 28,
      alt: 'STEP-29',
      imagePath: '../assets/img/12201.svg',
      tooltipTarget: 'targetArea06201-01',
      tooltipDescription:
        '「アプリを起動する」をタップ、霧ヶ峰アプリを起動させる',
      footerContent:
        '<ul><li>エアコン登録と初期設定が完了しました。霧ヶ峰アプリの使い方については、霧ヶ峰アプリの取扱説明書を確認ください。</li><li>エアコン名は設置されている部屋名称に変更することをお勧めします(リビングのエアコンなど)。変更方法は<a href="https://www.mitsubishielectric.co.jp/home/mymu/ib.html">MyMUアプリの取扱説明書</a>から、「登録機器一覧を確認する」の事項を確認ください（ユーザー種別が「管理者」のみ行えます）。</li></ul>',
    },
  ],
};
