/******************************************
 * テンプレートファイル読み込み
 ******************************************/
document.addEventListener("DOMContentLoaded", async () => {
  try {
    const [alert, header, footer, modal, drawer] = await Promise.all([
      fetch("../../partials/alert.txt").then((r) => r.text()),
      fetch("../../partials/header.txt").then((r) => r.text()),
      fetch("../../partials/footer.txt").then((r) => r.text()),
      fetch("../../partials/modal.txt").then((r) => r.text()),
      fetch("../../partials/drawer-menu.txt").then((r) => r.text()),
    ]);

    document.querySelector(".content-alert").innerHTML = alert;
    document.querySelector(".content-header").innerHTML = header;
    document.querySelector(".content-footer").innerHTML = footer;
    document.querySelector(".content-modal").innerHTML = modal;
    document.querySelector(".content-drawer").innerHTML = drawer;
    initUI();
  } catch (err) {
    console.error("Failed to load partials:", err);
  }
});

function initUI() {
  // モーダル
  // initModalDriveModeSelectButtons();
  initFooterButtons();
  initFooterButtonsState();
  initHeader();
  // 基本機能 画面
  // renderDriveModeSwitchBtnAndSettingPanelOperation();
}


/******************************************
 * JSON取得（ブラケット版）
 ******************************************/
const getJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }

  if (!data) return undefined;

  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }

  return current;
};

/******************************************
 * JSON更新（ブラケット版）
 ******************************************/
const setJsonValue = (propertyPath, value) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : {};
  } catch (e) {
    data = {};
  }

  // ブラケット記法をドット記法に変換
  // "buttons[0].label" → "buttons.0.label"
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let i = 0; i < props.length - 1; i++) {
    const prop = props[i];

    // 数字 → 配列アクセス
    const index = Number(prop);
    const isIndex = !isNaN(index);

    if (isIndex) {
      if (!Array.isArray(current)) {
        current = [];
      }
      if (current[index] === undefined) {
        current[index] = {};
      }
      current = current[index];
    } else {
      if (!current[prop] || typeof current[prop] !== "object") {
        current[prop] = {};
      }
      current = current[prop];
    }
  }

  // 最終プロパティ
  const lastProp = props[props.length - 1];
  const lastIndex = Number(lastProp);

  if (!isNaN(lastIndex)) {
    if (!Array.isArray(current)) current = [];
    current[lastIndex] = value;
  } else {
    current[lastProp] = value;
  }

  sessionStorage.setItem("appData", JSON.stringify(data));
};

/******************************************
 * ユーティリティ：ヘッダーのアイテムを設定する
 * 対象：各画面のヘッダー
 * アクション：ヘッダー要素の初期化
 ******************************************/
function initHeader() {
  // ==============================
  // DOM取得
  // ==============================
  const headerDom = {
    leftBtn: document.getElementById("headerLeftBtn"),
    title: document.getElementById("headerTitle"),
    rightBtn: document.getElementById("headerRightBtn"),
  };

  if (!headerDom.leftBtn || !headerDom.title || !headerDom.rightBtn) {
    console.warn("header DOM がまだ準備できていません");
    return;
  }

  // ==============================
  // headerSetBodyKeyキー取得
  // ==============================
  const currentHeaderSetKey = document.body.dataset.appHeaderSet;
  if (!currentHeaderSetKey) {
    console.warn("data-app-header-set が指定されていません");
    return;
  }

  // ==============================
  // headerSetJson 取得
  // ==============================
  const headerSetJson = getJsonValue(`headerSet.${currentHeaderSetKey}`);
  if (!headerSetJson) {
    console.warn(`headerSet.${currentHeaderSetKey} が見つかりません`);
    return;
  }

  // ==============================
  // タイトル
  // ==============================
  headerDom.title.innerHTML = headerSetJson.title;

  // ==============================
  // 左ボタン
  // ==============================
  renderLeftButton(headerSetJson.left?.type, headerDom.leftBtn);
  headerDom.leftBtn.onclick = () =>
    handleHeaderLeftAction(headerSetJson.left?.type);

  // ==============================
  // 右ボタン
  // ==============================
  renderRightButton(headerSetJson.right, headerDom.rightBtn);
  headerDom.rightBtn.onclick = () =>
    handleHeaderRightAction(headerSetJson.right?.action);
}

// ==============================
// 左ボタン描画
// ==============================
// リセット
function renderLeftButton(type, btn) {
  btn.innerHTML = "";
  btn.classList.remove("d-none");
  // アイコン設定
  switch (type) {
    case "back":
      btn.innerHTML = '<i class="bi bi-chevron-left"></i>';
      break;
    case "drawer":
      btn.innerHTML = '<i class="bi bi-list"></i>';
      break;
    default:
      btn.classList.add("d-none");
  }
}

// ==============================
// 左アクション処理
// ==============================
function handleHeaderLeftAction(type) {
  switch (type) {
    case "back":
      // document.addEventListener("DOMContentLoaded", syncToggleFromStorage);
      // window.addEventListener("pageshow", syncToggleFromStorage);
      window.history.back();
      break;

    case "drawer":
      const bsOffcanvas = new bootstrap.Offcanvas("#appOffcanvas");
      bsOffcanvas.show();
      break;
  }
}

// ==============================
// 右ボタン描画
// ==============================
function renderRightButton(headerSetJsonRight, headerDomRight) {
  // 右ボタンのプロパティチェック
  if (!headerSetJsonRight || !headerSetJsonRight.visible) {
    headerDomRight.classList.add("d-none");
    headerDomRight.onclick = null;
    return;
  }

  // 表示
  headerDomRight.classList.remove("d-none");

  // text / icon / svg すべて対応
  headerDomRight.innerHTML = headerSetJsonRight.text || "";

  // クリック処理（あれば）
  headerDomRight.onclick = () => {
    handleHeaderRightAction(headerSetJsonRight.action, headerSetJsonRight);
  };
}

// ==============================
// 右アクション処理（完了/done | 設定/set | リンク/link | 編集/edit | 決定/ok）
// ==============================
function handleHeaderRightAction(action) {
  switch (action) {
    // JSON更新後、前の画面へ戻る
    case "done":
      window.history.back();
      break;

    // 電気代チェック画面へ遷移
    case "set":
      window.history.back();
      break;

    // 指定リンクへ遷移
    case "link":
      const rightBtn = document.getElementById("headerRightBtn");
      const target = getJsonValue(
        "headerSet.electricityBillCheck.right.target",
      );
      if (rightBtn) {
        rightBtn.href = target;
      }
      break;

    // 現在の画面が編集可能になるtouch-airflow-back
    case "edit":
      window.history.back();
      break;

    // タッチ気流、窓位置設定のポインターがロックされる
    case "ok":
      window.history.back();
      break;

    // アラート表示schedule-done
    case "alert":
      alert(
        "デモアプリではこのボタンは操作できません。＜ ボタンで戻ってください",
      );
      break;

    // スケジュール画面で完了
    case "schedule-done":
      setJsonValue("isAutoMationSetDone", true);
      window.location.href = '../schedule/';
      break;

    // アラート表示
    case "touch-airflow-back":
      alert(
        "風向を設定しました。やり直す場合は画像をダブルタップしてください。",
      );
      break;
  }
}

/******************************************
 * イニシャライズ：フッター
 * 対象：フッターのアイコン
 * アクション：JSON更新(currentPage)
 ******************************************/
const initFooterButtons = () => {
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      setJsonValue("currentPage", btn.dataset.appPage);
    });
  });
};

/******************************************
 * レンダリング：フッターアイコン表示更新
 * 対象：フッターのアイコン
 * アクション：アクティブページのフッターアイコンの表示更新
 ******************************************/
const initFooterButtonsState = () => {
  // フッターが存在しない画面
  const footerElement = document.getElementsByClassName("content-footer")[0];
  if (footerElement.className.includes("d-none")) {
    return;
  }
  // スタイルリセット
  const currentPage = getJsonValue("currentPage");
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.classList.remove("active");
  });
  // レンダリング
  footerButtons.forEach((btn) => {
    const page = btn.dataset.appPage;
    if (page === currentPage) {
      btn.classList.add("active");
    }
  });
};

/******************************************
 * イニシャライズ：オートメーション 画面
 * 対象：＋ボタン
 * アクション：オートメーション追加画面が表示される
 ******************************************/
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".js-add-automation");
  if (!btn) return;
  window.location.href = "../new-automation/";
});

/******************************************
 * イニシャライズ：新規オートメーション 画面
 * 対象：カスタムオートメーション作成 ボタン
 * アクション：ボタンをクリックすると、カスタムオートメーション画面へ遷移する
 ******************************************/
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".js-new-automation");
  if (!btn) return;
  window.location.href = "../custom-automation/";
});

/******************************************
 * イニシャライズ：カスタムオートメーション 画面
 * 対象：スケジュール／位置情報／機器の状態 ボタン
 * アクション：JSONデータ更新
 ******************************************/
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".js-trigger-event");
  if (!btn) return;
  const triggerEvent = btn.dataset.appTriggerEvent;
  if (!triggerEvent) return;
  // JSONデータ更新
  setJsonValue("currentTriggerEvent", triggerEvent);
  renderCustomAutomationTriggerEventBtn();
  renderCustomAutomationTriggerEventBlockDisplay(triggerEvent);
});

/******************************************
 * レンダリング：カスタムオートメーション 画面
 * 対象：トリガーイベント ボタン（スケジュール／位置情報／機器の状態 ボタン）
 * アクション：JSONデータ更新
 ******************************************/
const renderCustomAutomationTriggerEventBtn = () => {
  const triggerEvent = getJsonValue(
    "currentTriggerEvent.triggerEvent",
  );
  const triggerEventButtons = document.querySelectorAll(
    ".js-trigger-event",
  );
  triggerEventButtons.forEach((btn) => {
    btn.classList.remove("active");
    if (btn.dataset.appTriggerEvent === triggerEvent) {
      btn.classList.add("active");
    }
  });
};

/******************************************
 * レンダリング：カスタムオートメーション 画面
 * 対象：トリガーイベント 家電シェアユーザー／位置条件の表示⇔非表示
 * アクション：JSONデータを取得して表示⇔非表示を切り替え
 ******************************************/
const renderCustomAutomationTriggerEventBlockDisplay = (triggerEvent) => {

  // 表示⇔非表示にするセクション
  const sections = {
    schedule: "triggerEventScheduleSection",
    location: "triggerEventLocationSection",
    product: "triggerEventStatusOfDeviceSection",
  };

  Object.values(sections).forEach(id =>
    document.getElementById(id).classList.add("d-none")
  );

  document
    .getElementById(sections[triggerEvent])
    ?.classList.remove("d-none");
};

/******************************************
 * イニシャライズ：カスタムオートメーション 画面
 * 対象：シーンを追加／機器の操作を追加／通知を追加 ボタン
 * アクション：画面を遷移する
 ******************************************/
document.addEventListener("click", (e) => {
  const action = e.target.closest(".js-trigger-event")?.dataset?.appAction;
  const routes = {
    scene: "../select-scene/",
    operation: "../select-device/",
    notification: "../notice-settings/",
  };
  if (action && routes[action]) location.href = routes[action];
});

/******************************************
 * イニシャライズ：機器を選択 画面
 * 対象：シーンを追加／機器の操作を追加／通知を追加 ボタン
 * アクション：画面を遷移する
 ******************************************/
document.addEventListener("click", (e) => {
  const action = e.target.closest(".js-trigger-event")?.dataset?.appAction;
  const routes = {
    ac1: "../device-settings-ac-1/",
    ac2: "../device-settings-ac-2/",
    eq: "../device-settings-eq/",
  };
  if (action && routes[action]) location.href = routes[action];
});

/******************************************
 * イニシャライズ：操作設定 画面
 * 対象：運転／停止、冷房／暖房／除湿／送風 ボタン
 * アクション：JSONの値を更新する
 ******************************************/
document.addEventListener("click", (e) => {
  const targetDevice =
    e.target.closest(".js-trigger-event")?.dataset?.appDevice;
  const btnDrive = e.target.closest(".js-trigger-event")?.dataset?.appIsDrive;
  const btnMode = e.target.closest(".js-trigger-event")?.dataset?.appMode;

  if (btnDrive !== undefined && targetDevice) {
    const isDrive = btnDrive === "true";
    setJsonValue(`operationSettings.${targetDevice}.isDrive`, isDrive);
  }

  if (btnMode && targetDevice) {
    setJsonValue(`operationSettings.${targetDevice}.mode`, btnMode);
  }
});

/******************************************
 * イニシャライズ：オートメーション 画面
 * 対象：オートメーション カード ボタン
 * アクション：クリックすると、JSONの値を更新、画面遷移する
 *  ******************************************/
document.addEventListener("click", (e) => {
  const autoId = e.target.closest(".js-trigger-auto-id")?.dataset?.appKey;
  if(!autoId) return;
  setJsonValue("automation.selectedId", `${autoId}`);
  // setJsonValue(`automation.${autoId}.isSelected`, true);
  window.location.href = '../edit-automation/';
});


/******************************************
 * レンダリング：オートメーション編集 画面
 * 対象：画面の全ての設定要素
 * アクション：JSONから値を取得して画面を更新する
 ******************************************/
const renderAutomationEditScreen = () => {
  // 選択されたオートメーションIDを取得
  const selectedId = getJsonValue("automation.selectedId");
  const targetPath = `automation.items.${selectedId}`;

 // トリガーイベント
  const targetButton = document.querySelector('.js-trigger-event[data-app-trigger-event="schedule"]');
  targetButton.classList.add("active");

  // オートメーション名
  document.getElementById("autoName").innerText = getJsonValue(`${targetPath}.name`);

  // 時間
  document.getElementById("autoStartTime").innerText = getJsonValue(`${targetPath}.triggers[0].startTime`);

  // 曜日
  document.querySelectorAll(".day-of-the-week").forEach(button => {
    const day = button.dataset.appScheduleDay;
    getJsonValue(`${targetPath}.triggers[0].days`).includes(day)
    ? button.classList.add("active")
    : null;

    day 
    // button.classList.toggle("active", days.includes(day));
  });
};


/******************************************
 * イニシャライズ：ユーティリティ
 * 対象：.setting-btn ボタン
 * アクション：選択すると .active クラスを追加する
 ******************************************/
document.addEventListener("click", (e) => {
  // const targetButton = e.target.closest(".setting-btn");
  // targetButton.classList.add("active");
});



/******************************************
 ******************************************/

// 選択中オートメーション取得
const getSelectedAutomation = () => {
  const { selectedId, items } = getJsonValue("automation");
  return items[selectedId];
}

// // UI 初期描画関数
// function renderAutomationName() {
//   const auto = getSelectedAutomation();
//   document.getElementById("automationName").innerText = auto.name;
// }

// // トグル（ON / OFF）
// function renderStatusToggle() {
//   const auto = getSelectedAutomation();
//   const toggle = document.getElementById("automationStatus");
//   toggle.checked = auto.status;
// }

// // スケジュール（時間・曜日）
// function getScheduleTrigger(auto) {
//   return auto.triggers.find(t => t.type === "schedule");
// }

// // 時刻
// function renderStartTime() {
//   const auto = getSelectedAutomation();
//   const schedule = getScheduleTrigger(auto);
//   document.getElementById("startTime").value = schedule?.startTime ?? "";
// }

// // 曜日
// function renderWeekdays(days = []) {
//   document.querySelectorAll("[data-day]").forEach(btn => {
//     btn.classList.toggle("active", days.includes(btn.dataset.day));
//   });
// }

// function renderSchedule() {
//   const auto = getSelectedAutomation();
//   const schedule = getScheduleTrigger(auto);
//   renderWeekdays(schedule?.days ?? []);
// }

// // アクション（表示のみ）
// function renderActions() {
//   const auto = getSelectedAutomation();
//   const container = document.getElementById("actionList");

//   container.innerHTML = "";

//   auto.actions.forEach(action => {
//     const div = document.createElement("div");

//     if (action.type === "product") {
//       div.innerText =
//         `エアコン：${action.mode} ${action.temperature}℃`;
//     }

//     if (action.type === "notification") {
//       div.innerText =
//         `通知 → ${action.target}`;
//     }

//     container.appendChild(div);
//   });
// }

// 初期描画をまとめる
function renderAll() {
  getSelectedAutomation();
  // renderStatusToggle();
  // renderStartTime();
  // renderSchedule();
  // renderActions();
}

document.addEventListener("DOMContentLoaded", renderAll) 

console.log(getJsonValue("automation"));