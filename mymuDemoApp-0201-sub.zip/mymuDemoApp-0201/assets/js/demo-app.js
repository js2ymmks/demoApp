/******************************************
 * テンプレートファイル読み込み
 ******************************************/
Promise.all([
  fetch("../../partials/header.html").then((r) => r.text()),
  // fetch("../../partials/date.html").then((r) => r.text()),
  fetch("../../partials/footer.txt").then((r) => r.text()),
  fetch("../../partials/modal.html").then((r) => r.text()),
  fetch("../../partials/drower-menu.html").then((r) => r.text()),
])
  .then(([headerHtml, footerHtml, modalHtml, drawerHtml]) => {
    document.querySelector(".content-header").innerHTML = headerHtml;
    // document.querySelector(".content-date").innerHTML = dateHtml;
    document.querySelector(".content-footer").innerHTML = footerHtml;
    document.querySelector(".content-modal").innerHTML = modalHtml;
    document.querySelector(".content-drawer").innerHTML = drawerHtml;
  })
  .catch((err) => {
    console.error("Failed to load partials:", err);
  });

/******************************************
 * JSON取得（ブラケット版）
 ******************************************/
const getJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }

  if (!data) return undefined;

  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }

  return current;
};

/******************************************
 * JSON更新（ブラケット版）
 ******************************************/
const setJsonValue = (propertyPath, value) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : {};
  } catch (e) {
    data = {};
  }

  // ブラケット記法をドット記法に変換
  // "buttons[0].label" → "buttons.0.label"
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let i = 0; i < props.length - 1; i++) {
    const prop = props[i];

    // 数字 → 配列アクセス
    const index = Number(prop);
    const isIndex = !isNaN(index);

    if (isIndex) {
      if (!Array.isArray(current)) {
        current = [];
      }
      if (current[index] === undefined) {
        current[index] = {};
      }
      current = current[index];
    } else {
      if (!current[prop] || typeof current[prop] !== "object") {
        current[prop] = {};
      }
      current = current[prop];
    }
  }

  // 最終プロパティ
  const lastProp = props[props.length - 1];
  const lastIndex = Number(lastProp);

  if (!isNaN(lastIndex)) {
    if (!Array.isArray(current)) current = [];
    current[lastIndex] = value;
  } else {
    current[lastProp] = value;
  }

  sessionStorage.setItem("appData", JSON.stringify(data));
};

/******************************************
 * ユーティリティ：ヘッダーのアイテムを設定する
 * 対象：各画面のヘッダー
 * アクション：ヘッダー要素の初期化
 ******************************************/
window.addEventListener("load", () => {
  setTimeout(initHeader, 100);
});

function initHeader() {
  // ==============================
  // DOM取得
  // ==============================
  const headerDom = {
    leftBtn: document.getElementById("headerLeftBtn"),
    title: document.getElementById("headerTitle"),
    rightBtn: document.getElementById("headerRightBtn"),
  };

  if (!headerDom.leftBtn || !headerDom.title || !headerDom.rightBtn) {
    console.warn("header DOM がまだ準備できていません");
    return;
  }

  // ==============================
  // headerSetBodyKeyキー取得
  // ==============================
  const currentHeaderSetKey = document.body.dataset.appHeaderSet;
  if (!currentHeaderSetKey) {
    console.warn("data-app-header-set が指定されていません");
    return;
  }

  // ==============================
  // headerSetJson 取得
  // ==============================
  const headerSetJson = getJsonValue(`headerSet.${currentHeaderSetKey}`);
  if (!headerSetJson) {
    console.warn(`headerSet.${currentHeaderSetKey} が見つかりません`);
    return;
  }

  // ==============================
  // タイトル
  // ==============================
  headerDom.title.innerHTML = headerSetJson.title;

  // ==============================
  // 左ボタン
  // ==============================
  renderLeftButton(headerSetJson.left?.type, headerDom.leftBtn);
  headerDom.leftBtn.onclick = () =>
    handleHeaderLeftAction(headerSetJson.left?.type);

  // ==============================
  // 右ボタン
  // ==============================
  renderRightButton(headerSetJson.right, headerDom.rightBtn);
  headerDom.rightBtn.onclick = () =>
    handleHeaderRightAction(headerSetJson.right?.action);
}

// ==============================
// 左ボタン描画
// ==============================
// リセット
function renderLeftButton(type, btn) {
  btn.innerHTML = "";
  btn.classList.remove("d-none");
  // アイコン設定
  switch (type) {
    case "back":
      btn.innerHTML = '<i class="bi bi-chevron-left"></i>';
      break;
    case "drawer":
      btn.innerHTML = '<i class="bi bi-list"></i>';
      break;
    default:
      btn.classList.add("d-none");
  }
}

// ==============================
// 左アクション処理
// ==============================
function handleHeaderLeftAction(type) {
  switch (type) {
    case "back":
      // document.addEventListener("DOMContentLoaded", syncToggleFromStorage);
      // window.addEventListener("pageshow", syncToggleFromStorage);
      window.history.back();
      break;

    case "drawer":
      const bsOffcanvas = new bootstrap.Offcanvas("#appOffcanvas");
      bsOffcanvas.show();
      break;
  }
}

// ==============================
// 右ボタン描画
// ==============================
function renderRightButton(headerSetJsonRight, headerDomRight) {
  // 右ボタンのプロパティチェック
  if (!headerSetJsonRight || !headerSetJsonRight.visible) {
    headerDomRight.classList.add("d-none");
    headerDomRight.onclick = null;
    return;
  }
  // 右側のテキストボタン表示

  headerDomRight.innerText = headerSetJsonRight.text || "";
}

// ==============================
// 右アクション処理（完了/done | 設定/set | リンク/link | 編集/edit | 決定/ok）
// ==============================
function handleHeaderRightAction(action) {
  switch (action) {
    // JSON更新後、前の画面へ戻る
    case "done":
      window.history.back();
      break;

    // 電気代チェック画面へ遷移
    case "set":
      window.history.back();
      break;

    // 指定リンクへ遷移
    case "link":
      const rightBtn = document.getElementById("headerRightBtn");
      const target = getJsonValue(
        "headerSet.electricityBillCheck.right.target",
      );
      if (rightBtn) {
        rightBtn.href = target;
      }
      break;

    // 現在の画面が編集可能になるtouch-airflow-back
    case "edit":
      window.history.back();
      break;

    // タッチ気流、窓位置設定のポインターがロックされる
    case "ok":
      window.history.back();
      break;

    // アラート表示schedule-done
    case "alert":
      alert(
        "デモアプリではこのボタンは操作できません。＜ ボタンで戻ってください",
      );
      break;

    // スケジュール画面で完了
    case "schedule-done":
      setJsonValue("isAutoMationSetDone", true);
      window.location.href = '../schedule/';
      break;

    // アラート表示
    case "touch-airflow-back":
      alert(
        "風向を設定しました。やり直す場合は画像をダブルタップしてください。",
      );
      break;
  }
}
