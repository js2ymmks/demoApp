---  
date: 2026-03-13  
update: 2026-04-10   
title: "RACデモアプリ仕様書"  
auther: "MEE 京駐和事 山田 幸一"
---

<div class="edit-date" markdown>
:octicons-pencil-24:&nbsp;{{date}}<span class="space-1"></span>
:material-refresh:&nbsp;{{update}}<span class="space-1"></span>
:octicons-person-24:&nbsp;{{auther}}
</div>

## 概要
### アプリ名
RACデモアプリ

### バージョン
Ver. 1.0 

### 依頼元
MELCO 京都 SB業・SB業（担当：中森 裕子 様）

### アプリ概要説明
本デモアプリは、起動ページにアクセスすることでセッションストレージにJSONが保存され、以降のページ遷移はJSONを読み取り／書き込みしながら画面の状態が制御されます。また、遷移できる画面は限定的で、遷移されない画面へリンクするボタンをタップした場合にはアラート「デモアプリではこのボタンは操作できません。」が表示されます。

### おもな機能
* JSON読み取り／書き込みによる各コンポーネント制御
* 起動ページ以外のページへアクセスした時のリダイレクト処理
* 画面遷移しない箇所をタップした時のアラート表示
* タッチ気流操作の疑似体験

### 公開URL
以下のURLにアクセスすると起動ページからトップページへリダイレクトされ使用可能になります。  
[https://www.mitsubishielectric.co.jp/home/mymu/demo/rac/](https://www.mitsubishielectric.co.jp/home/mymu/demo/rac/)


!!! warning

    本デモアプリを開始するには、必ず上記URLにアクセスしてください。上記URLにアクセスするとホーム画面にリダイレクトされ使用可能な状態になります。セッション切れや、途中画面からスタートすると、アラートが表示され上記URLに戻ります。

## 動作環境
### 対応デバイス
* 一般的なPC／スマートフォン／タブレット  
iPhone SE（横幅750px）の画面を基準レイアウトとしています。

### 実機検証した端末名
* Apple iPhone 13（iOS 18.6.2/1170×2532）
* ほか、ソ運 様でレビュー
* macOSは未検証


<!-- !!! note

    横幅750px未満の低解像度端末による検証は、ソ運 様にて実施 -->

## 画面遷移図
本デモアプリは以下の構成で遷移します。  
※ クリックすると拡大され、マウス操作で全体を移動できます。

![画面遷移図](./assets/img/screen-flowchart.png){ align=left }

## JSON
起動時のプロパティ構成は以下のとおりです。

### JSON仕様

``` javascript
const initialAppData = {
  currentPage: "basic", // 表示画面
  currentMode: "ai-auto-cooling", // 運転モード（cooling, dehumidifying, heating, perflation, ai-auto-cooling, ai-auto-heating）
  automationMode: "",
  lastUpdated: "20xx/07/01 11:15", // 最終更新日時
  isThermalImageManagement: true, // 熱画像管理ON/OFF　(true　|　false)
  isTouchAirflow: true, // タッチ気流ON/OFF　(true　|　false)
  isAutoMationSetDone: false, // オートメーション機能　有効/無効　(true　|　false)
  modalDrive: {
    isRunning: true, // true ⇔ false
    label: "停止",
  },
  driveModeSelectBtn: {
    // 運転モード選択ボタン状態, 温度・湿度・除湿表示
    cooling: {
      label: "冷房",
      icon: "../assets/img/home-icon-btn-cooling.svg",
      style: "btn-cooling",
      settingDisplay: "text-cooling",
    },
    dehumidifying: {
      label: "除湿",
      icon: "../assets/img/home-icon-btn-dehumidification.svg",
      style: "btn-dehumidifying",
      settingDisplay: "text-dehumidifying",
    },
    heating: {
      label: "暖房",
      icon: "../assets/img/home-icon-btn-heating.svg",
      style: "btn-heating",
      settingDisplay: "text-heating",
    },
    perflation: {
      label: "送風",
      icon: "../assets/img/home-icon-btn-perflation.svg",
      style: "btn-perflation",
      settingDisplay: "text-perflation",
    },
    "ai-auto-cooling": {
      label: "A.I.自動(冷房)",
      icon: "../assets/img/home-icon-btn-ai-auto.svg",
      style: "btn-ai-auto",
      settingDisplay: "text-ai-auto",
    },
    "ai-auto-heating": {
      label: "A.I.自動(暖房)",
      icon: "../assets/img/home-icon-btn-ai-auto.svg",
      style: "btn-ai-auto",
      settingDisplay: "text-ai-auto",
    },
  },
  headerSet: {
    // ヘッダーセット
    basic: {
      left: {
        type: "drawer",
      },
      title: "リビング",
      right: {
        visible: false,
      },
    },
    headerSet02: {
      left: {
        type: "back",
      },
      title: "スケジュール",
      right: {
        text: "完了",
        action: "schedule-done",
        visible: true,
      },
    },
    touchAirflow: {
      left: {
        type: "back",
      },
      title:
        'タッチ気流<i class="bi bi-question-circle-fill ms-1 text-secondary"></i>',
      right: {
        text: "決定",
        action: "touch-airflow-back",
        bordered: true,
        visible: true,
      },
    },
    thermalImage: {
      left: {
        type: "back",
      },
      title:
        '熱画像<i class="bi bi-question-circle-fill ms-1 text-secondary"></i>',
      right: {
        visible: false,
      },
    },
    headerSet04: {
      left: {
        type: "back",
      },
      title:
        '換気アシスト設定<i class="bi bi-question-circle-fill ms-1 text-secondary"></i>',
      right: {
        text: "完了",
        action: "done",
        target: "",
        visible: true,
      },
    },
    setTheWindowPositions: {
      left: {
        type: "back",
      },
      title: "窓位置設定",
      right: {
        text: "決定",
        action: "back",
        visible: true,
      },
    },
    thermalImageManagement: {
      left: {
        type: "back",
      },
      title: "熱画像管理",
      right: {
        visible: false,
      },
    },
    electricityBillCheck: {
      left: {
        type: "back",
      },
      title: "電気代チェック",
      right: {
        text: "設定",
        action: "link",
        target: "../electricity-bill-check-settings/",
        visible: true,
      },
    },
    electricityRateSettings: {
      left: {
        type: "back",
      },
      title: "電気代単価設定",
      right: {
        text: "編集",
        action: "alert",
        visible: true,
      },
    },
    electricityBillCheckSettings: {
      left: {
        type: "back",
      },
      title: "電気代チェック",
      right: {
        visible: false,
      },
    },
    targetElectricityCostSettings: {
      left: {
        type: "back",
      },
      title: "目標電気代設定",
      right: {
        action: "link",
        target: "../electricity-bill-check-settings/",
        visible: false,
      },
    },
    operatingHistory: {
      left: {
        type: "back",
      },
      title: "運転履歴",
      right: {
        text: "設定",
        action: "alert",
        target: "",
        visible: true,
      },
    },
    maintenance: {
      left: {
        type: "back",
      },
      title: "メンテナンス",
      right: {
        visible: false,
      },
    },
    headerSet14: {
      left: {
        type: "back",
      },
      title: "エアコン製品情報",
      right: {
        visible: false,
      },
    },
    headerSet15: {
      left: {
        type: "back",
      },
      title: "製品情報の登録",
      right: {
        visible: false,
      },
    },
    optionalFeatureSettings: {
      left: {
        type: "back",
      },
      title: 'オプション機能設定 <svg width="18" height="18" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.083 1C15.1223 1 19.1668 5.04378 19.167 10.083C19.167 15.1224 15.1224 19.167 10.083 19.167C5.04378 19.1668 1 15.1223 1 10.083C1.00017 5.04389 5.04389 1.00017 10.083 1Z" stroke="black" stroke-width="2"/><circle cx="10.083" cy="6.08203" r="1" fill="black"/><rect x="9.08301" y="8.08203" width="2" height="7" rx="1" fill="#646464"/></svg>',
      right: {
        visible: false,
      },
    },
    headerSet17: {
      left: {
        type: "back",
      },
      title: "機器情報",
      right: {
        visible: false,
      },
    },
    headerSet18: {
      left: {
        type: "back",
      },
      title: "お知らせ",
      right: {
        visible: false,
      },
    },
    headerSet19: {
      left: {
        type: "back",
      },
      title: "チュートリアル",
      right: {
        visible: false,
      },
    },
    headerSet20: {
      left: {
        type: "back",
      },
      title: "アプリ情報",
      right: {
        visible: false,
      },
    },
  },
  electricityBill: { // 電気代
    isSelected: true,
    period: {
      yearly: {
        isSelected: true,
      },
      monthly: {
        isSelected: false,
      },
    },
  },
  electricityConsumption: { // 電気量
    isSelected: false,
    period: {
      yearly: {
        isSelected: true,
      },
      monthly: {
        isSelected: false,
      },
    },
  },
  // スケジュール設定
  schedule: [
    {
      id: 3,
      name: "スケジュール",
      startTime: "08:00",
      dayOfTheWeek: {
        sun: false,
        mon: false,
        tue: false,
        wed: false,
        thu: false,
        fri: false,
        sat: false,
      },
      dayOfTheWeekLabel: "",
      isDrive: true,
      mode: "冷房",
      setValue: "27.0",
    },
  ],
};
```

### JSONプロパティ名と値

| プロパティ名                    | 内容                                   | 値（複数の場合は最上位が初期値）、子要素                                            |
|----------------------------|----------------------------------------|-------------------------------------------------------------------------------|
| `currentPage`              | 現在の表示ページ                           | mymu, basic, schedule, other                                                  |
| `currentMode`              | 現在の運転モード                           | cooling, dehumidifying, heating, perflation, ai-auto-cooling, ai-auto-heating |
| `automationMode`           | オートメーションのモード                           | null, create, edit                                                            |
| `lastUpdated`              | 最終更新日時（画面上部に表示）            | 20xx/07/01 11:15                                                              |
| `isThermalImageManagement` | 熱画像管理のトグルスイッチの状態                | true, false                                                                   |
| `isTouchAirflow`           | タッチ気流のトグルスイッチの状態                   | true, false                                                                   |
| `isAutoMationSetDone`      | オートメーション機能の有効／無効                 | false, true                                                                   |
| `modalDrive`               | 運転状態（画面／ポップアップ）                  | true, false／運転, 停止                                                        |
| `driveModeSelectBtn`       | 運転モード選択ボタン状態, 温度・湿度・除湿表示 | label, icon, style, settingDisplay                                            |
| `headerSet`                | ヘッダーに表示するタイトル                        | basic, touchAirflow など                                                        |
| `electricityBill`          | 電気代の画面が表示されている                  | isSelected, period など                                                         |
| `electricityConsumption`   | 電気量の画面が表示されている                  | isSelected, period など                                                         |
| `schedule`                 | スケジュール画面の曜日管理                    | dayOfTheWeek, dayOfTheWeekLabel など                                            |


### 基本機能
=== "基本機能"

    ![ホーム](./assets/img/ホーム.png){ align=left }


### スケジュール
=== "スケジュール一覧"

    ![スケジュール一覧](./assets/img/スケジュール一覧.png){ align=left }

=== "エアコン運転編集"

    ![エアコン運転編集](./assets/img/エアコン運転編集.png){ align=left }


### その他機能
=== "その他機能"

    ![その他機能](./assets/img/その他機能.png){ align=left }

=== "タッチ気流"

    ![タッチ気流](./assets/img/タッチ気流.png){ align=left }

=== "熱画像管理"

    ![熱画像管理](./assets/img/熱画像管理.png){ align=left }

=== "熱画像"

    ![熱画像管理](./assets/img/熱画像.png){ align=left }

=== "電気代"

    ![エアコン運転編集](./assets/img/エアコン運転編集.png){ align=left }

=== "運転履歴"

    ![運転履歴](./assets/img/運転履歴.png){ align=left }

=== "メンテンナンス"

    ![メンテナンス](./assets/img/メンテナンス.png){ align=left }


### 電気代／電力量

=== "電気代（月間）"

    ![電気代（月間）](./assets/img/電気代（月間）.png){ align=left }

=== "電気代（年間）"

    ![電気代（年間）](./assets/img/電気代（年間）.png){ align=left }

=== "電力量（月間）"

    ![電力量（月間）](./assets/img/電力量（月間）.png){ align=left }

=== "電力量（年間）"

    ![電力量（年間）](./assets/img/電力量（年間）.png){ align=left }


### そのほか

=== "メニュー"

    ![メニュー](./assets/img/メニュー.png){ align=left }

=== "オプション機能設定"

    ![オプション機能設定](./assets/img/オプション機能設定.png){ align=left }

=== "電気代チェック（メニュー）"

    ![電気代チェック（メニュー）](./assets/img/電気代チェック（メニュー）.png){ align=left }

=== "目標電気代設定（メニュー）"

    ![目標電気代設定（メニュー）](./assets/img/目標電気代設定（メニュー）.png){ align=left }

=== "電気代単価設定（グラフ）"

    ![電気代単価設定（グラフ）](./assets/img/電気代単価設定（グラフ）.png){ align=left }


## 改定履歴
* 2026年04月10日 初版発行  
