/******************************************
 * テンプレートファイル読み込み
 ******************************************/
Promise.all([
  fetch("../../partials/header.txt").then((r) => r.text()),
  fetch("../../partials/date.html").then((r) => r.text()),
  fetch("../../partials/footer.txt").then((r) => r.text()),
  fetch("../../partials/modal.html").then((r) => r.text()),
  fetch("../../partials/drower-menu.txt").then((r) => r.text()),
])
  .then(([headerHtml, dateHtml, footerHtml, modalHtml, drawerHtml]) => {
    document.querySelector(".content-header").innerHTML = headerHtml;
    document.querySelector(".content-date").innerHTML = dateHtml;
    document.querySelector(".content-footer").innerHTML = footerHtml;
    document.querySelector(".content-modal").innerHTML = modalHtml;
    document.querySelector(".content-drawer").innerHTML = drawerHtml;
  })
  .catch((err) => {
    console.error("Failed to load partials:", err);
  });

/******************************************
 * JSON取得（ブラケット版）
 ******************************************/
const getJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }

  if (!data) return undefined;

  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }

  return current;
};

/******************************************
 * JSON更新（ブラケット版）
 ******************************************/
const setJsonValue = (propertyPath, value) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : {};
  } catch (e) {
    data = {};
  }

  // ブラケット記法をドット記法に変換
  // "buttons[0].label" → "buttons.0.label"
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let i = 0; i < props.length - 1; i++) {
    const prop = props[i];

    // 数字 → 配列アクセス
    const index = Number(prop);
    const isIndex = !isNaN(index);

    if (isIndex) {
      if (!Array.isArray(current)) {
        current = [];
      }
      if (current[index] === undefined) {
        current[index] = {};
      }
      current = current[index];
    } else {
      if (!current[prop] || typeof current[prop] !== "object") {
        current[prop] = {};
      }
      current = current[prop];
    }
  }

  // 最終プロパティ
  const lastProp = props[props.length - 1];
  const lastIndex = Number(lastProp);

  if (!isNaN(lastIndex)) {
    if (!Array.isArray(current)) current = [];
    current[lastIndex] = value;
  } else {
    current[lastProp] = value;
  }

  sessionStorage.setItem("appData", JSON.stringify(data));
};

/******************************************
 * 無効ボタンをクリックしたときの処理
 ******************************************/
document.addEventListener("DOMContentLoaded", () => {
  setTimeout(() => {
    document.querySelectorAll(".demo-disabled-button").forEach(link => {
      link.addEventListener("click", (e) => {
        e.preventDefault(); // href の遷移を止める
        alert("この機能は現在ご利用いただけません。");
      });
    });
  }, 100);
});

/******************************************
 * ヘッダーのアイテムを設定する
 ******************************************/

window.addEventListener("load", () => {
  setTimeout(initHeader, 100);
});

function initHeader() {
// ==============================
// DOM取得
// ==============================
  const headerDom = {
    leftBtn: document.getElementById("headerLeftBtn"),
    title: document.getElementById("headerTitle"),
    rightBtn: document.getElementById("headerRightBtn"),
  };

  if (!headerDom.leftBtn || !headerDom.title || !headerDom.rightBtn) {
    console.warn("header DOM がまだ準備できていません");
    return;
  }

// ==============================
// headerSetBodyKeyキー取得
// ==============================
  const currentHeaderSetKey = document.body.dataset.appHeaderSet;
  if (!currentHeaderSetKey) {
    console.warn("data-app-header-set が指定されていません");
    return;
  }

// ==============================
// headerSetJson 取得
// ==============================
  const headerSetJson = getJsonValue(`headerSet.${currentHeaderSetKey}`);
  if (!headerSetJson) {
    console.warn(`headerSet.${currentHeaderSetKey} が見つかりません`);
    return;
  }

// ==============================
// タイトル
// ==============================
  headerDom.title.innerHTML = headerSetJson.title;

// ==============================
// 左ボタン
// ==============================
  renderLeftButton(headerSetJson.left?.type, headerDom.leftBtn);
  headerDom.leftBtn.onclick = () =>
    handleHeaderLeftAction(headerSetJson.left?.type);

// ==============================
// 右ボタン
// ==============================
  renderRightButton(headerSetJson.right, headerDom.rightBtn);
  headerDom.rightBtn.onclick = () =>
    handleHeaderRightAction(headerSetJson.right?.action); 
}

// ==============================
// 左ボタン描画
// ==============================
// リセット
function renderLeftButton(type, btn) {
  btn.innerHTML = "";
  btn.classList.remove("d-none");
  // アイコン設定
  switch (type) {
    case "back":
      btn.innerHTML = '<i class="bi bi-chevron-left"></i>';
      break;
    case "drawer":
      btn.innerHTML = '<i class="bi bi-list"></i>';
      break;
    default:
      btn.classList.add("d-none");
  }
}

// ==============================
// 左アクション処理
// ==============================
function handleHeaderLeftAction(type) {
  switch (type) {
    case "back":
      // document.addEventListener("DOMContentLoaded", syncToggleFromStorage);
      // window.addEventListener("pageshow", syncToggleFromStorage);
      window.history.back();
      window.addEventListener("pageshow", syncToggleFromStorage);
      break;

    case "drawer":
      const bsOffcanvas = new bootstrap.Offcanvas('#appOffcanvas');
      bsOffcanvas.show();
      break;
  }
}

// ==============================
// 右ボタン描画
// ==============================
function renderRightButton(headerSetJsonRight, headerDomRight) {
  // 右ボタンのプロパティチェック
  if (!headerSetJsonRight || !headerSetJsonRight.visible) {
    headerDomRight.classList.add("d-none");
    headerDomRight.onclick = null;
    return;
    headerDomRight.innerText = headerSetJsonRight.text || "";
  }
 // 右側のテキストボタン表示

  headerDomRight.innerText = headerSetJsonRight.text || "";
}

// ==============================
// 右アクション処理（完了/done | 設定/set | リンク/link | 編集/edit | 決定/ok）
// ==============================
function handleHeaderRightAction(action) {
  switch (action) {
    // JSON更新後、前の画面へ戻る
    case "done":
      window.history.back();
      break;

    // 電気代チェック画面へ遷移
    case "set":
      window.history.back();
      break;

    // 指定リンクへ遷移
    case "link":
      const rightBtn = document.getElementById('headerRightBtn');
      const target = getJsonValue('headerSet.electricityBillCheck.right.target');
      if (rightBtn) {
        rightBtn.href = target;
      }
      break;

    // 現在の画面が編集可能になる
    case "edit":
      window.history.back();
      break;

    // タッチ気流、窓位置設定のポインターがロックされる
    case "ok":
      window.history.back();
      break;
  }
}

/******************************************
 * 運転モード選択ボタン, 操作パネル表示処理
 ******************************************/
const driveModeSwitchBtnAndSettingPanelOperation = () => {
  let currentMode = getJsonValue("currentMode");
  document.getElementById("driveModeSwitchBtn").classList.add(getJsonValue(`driveModeSelectBtn.${currentMode}.style`));
  document.getElementById("currentModeLabel").innerText = getJsonValue(`driveModeSelectBtn.${currentMode}.label`);
  document.getElementById("currentModeIcon").src = getJsonValue(`driveModeSelectBtn.${currentMode}.icon`);
  document.getElementById("tempDisplay").className = getJsonValue(`driveModeSelectBtn.${currentMode}.settingDisplay`);
};

window.addEventListener("DOMContentLoaded", () => {
  setTimeout(() => {
    const footerButtons = document.querySelectorAll(".footer-button");
    footerButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        setJsonValue("currentPage", btn.dataset.appPage);
      });
    });
  }, 100);
});

/******************************************
 * フッターアイコン初期表示
 * アイコンをクリックするとページが切り替わるため、初期表示のみで対応
 ******************************************/
window.addEventListener("load", () => {
  setTimeout(() => {
    // 0. フッターが存在しない画面の処理
    const footerElement = document.getElementsByClassName("content-footer")[0];
    if (footerElement.className.includes("d-none")) {
      return;
    }

    // 1. リセット
    const currentPage = getJsonValue("currentPage");
    const footerButtons = document.querySelectorAll(".footer-button");
    footerButtons.forEach((btn) => {
      btn.classList.remove("active");
    });

    // 2. 初期表示
    footerButtons.forEach((btn) => {
      const page = btn.dataset.appPage;
      if (page === currentPage) {
        btn.classList.add("active");
      }
    });

    // 3. JSON更新
    footerButtons.forEach((btn) => {
      footerButtons.forEach(btn => {
        btn.addEventListener('click', () => {
          setJsonValue("currentPage", btn.dataset.appPage);
        });
      });
    });
  }, 100);
});

/******************************************
 * BS5 モーダルフォーカス解除
 ******************************************/
window.addEventListener("hide.bs.modal", () => {
  document.activeElement.blur();
});

/******************************************
 * トグルスイッチ関連
 ******************************************/

// JSONの値を取得⇒ ラベル表示更新
const renderToggleSwitchLabel = () => {
  getJsonValue("isThermalImageManagement")
    ? syncThermalImageManagement(true)
    : syncThermalImageManagement(false);
};

// DOM処理
const syncThermalImageManagement = (value) => {
  document.querySelectorAll(".js-toggle-switch").forEach(toggle => {
    // トグルスイッチの状態を更新
    toggle.checked = value;
    // ラベル表示を更新
    if (toggle.nextElementSibling) {
      toggle.nextElementSibling.innerText = value ? "ON" : "OFF";
    }
    // カードのリンクを更新
    const element = document.querySelector(".stretched-link-none");
    if(element) element.style.pointerEvents = value ? "auto" : "none";
  });
};

// 熱画像の表示⇔非表示の切り替え関数
const renderThermalImage = (value) => {
  const thermalImageElement = document.querySelector(".js-img");
  thermalImageElement.style.visibility = value ? "visible" : "hidden";
}
