function automationCheck() {
  // URLパスの判定で、環境（ローカル、レビュー、試験、本番）に依存しない処理
  try {
    if (document.referrer === "") {
      // リファラが空の場合はセッションを再構築する
      storeJsonData();
      return;
    }
    
    const referrerPath = new URL(document.referrer).pathname;
    
    if (referrerPath === "/home/mymu/demo/" ||
        referrerPath === "/home/mymu/demo/mymu/" ||
        referrerPath === "/home/mymu/demo/mymu/index.html") {
      storeJsonData();  // セッション再構築
    }
  } catch (e) {
    // 無効なURLの場合は何もしない
    console.error("Invalid referrer URL:", e);
  }
}

automationCheck();
setJsonValue("currentPage", "automation");
console.log(document.referrer);