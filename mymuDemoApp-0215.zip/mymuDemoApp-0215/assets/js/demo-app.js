/******************************************
 * テンプレートファイル読み込み
 ******************************************/
document.addEventListener("DOMContentLoaded", async () => {
  try {
    const [alert, header, footer, modal, drawer] = await Promise.all([
      fetch("../../partials/alert.txt").then((r) => r.text()),
      fetch("../../partials/header.txt").then((r) => r.text()),
      fetch("../../partials/footer.txt").then((r) => r.text()),
      fetch("../../partials/modal.txt").then((r) => r.text()),
      fetch("../../partials/drawer-menu.txt").then((r) => r.text()),
    ]);

    document.querySelector(".content-alert").innerHTML = alert;
    document.querySelector(".content-header").innerHTML = header;
    document.querySelector(".content-footer").innerHTML = footer;
    document.querySelector(".content-modal").innerHTML = modal;
    document.querySelector(".content-drawer").innerHTML = drawer;
    initUI();
  } catch (err) {
    console.error("Failed to load partials:", err);
  }
});

function initUI() {
  // モーダル
  // initModalDriveModeSelectButtons();
  initFooterButtons();
  initFooterButtonsState();
  initHeader();
  // 基本機能 画面
  // renderDriveModeSwitchBtnAndSettingPanelOperation();
}

/******************************************
 * JSON取得（ブラケット版）
 ******************************************/
const getJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }

  if (!data) return undefined;

  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }

  return current;
};

/******************************************
 * JSON更新（ブラケット版）
 ******************************************/
const setJsonValue = (propertyPath, value) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : {};
  } catch (e) {
    data = {};
  }

  // ブラケット記法をドット記法に変換
  // "buttons[0].label" → "buttons.0.label"
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let i = 0; i < props.length - 1; i++) {
    const prop = props[i];

    // 数字 → 配列アクセス
    const index = Number(prop);
    const isIndex = !isNaN(index);

    if (isIndex) {
      if (!Array.isArray(current)) {
        current = [];
      }
      if (current[index] === undefined) {
        current[index] = {};
      }
      current = current[index];
    } else {
      if (!current[prop] || typeof current[prop] !== "object") {
        current[prop] = {};
      }
      current = current[prop];
    }
  }

  // 最終プロパティ
  const lastProp = props[props.length - 1];
  const lastIndex = Number(lastProp);

  if (!isNaN(lastIndex)) {
    if (!Array.isArray(current)) current = [];
    current[lastIndex] = value;
  } else {
    current[lastProp] = value;
  }

  // 確認用ログ
  sessionStorage.setItem("appData", JSON.stringify(data));
  // console.log(data.automation.items["auto-1"].actions[0]);
};

/******************************************
 * JSON取得（ブラケット版）ヘッダー用
 ******************************************/
const getHeaderJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("headerSet");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }

  if (!data) return undefined;

  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }

  return current;
};

/******************************************
 * JSON更新（ブラケット版）ヘッダー用
 ******************************************/
const setHeaderJsonValue = (propertyPath, value) => {
  const storedJson = sessionStorage.getItem("headerSet");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : {};
  } catch (e) {
    data = {};
  }

  // ブラケット記法をドット記法に変換
  // "buttons[0].label" → "buttons.0.label"
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let i = 0; i < props.length - 1; i++) {
    const prop = props[i];

    // 数字 → 配列アクセス
    const index = Number(prop);
    const isIndex = !isNaN(index);

    if (isIndex) {
      if (!Array.isArray(current)) {
        current = [];
      }
      if (current[index] === undefined) {
        current[index] = {};
      }
      current = current[index];
    } else {
      if (!current[prop] || typeof current[prop] !== "object") {
        current[prop] = {};
      }
      current = current[prop];
    }
  }

  // 最終プロパティ
  const lastProp = props[props.length - 1];
  const lastIndex = Number(lastProp);

  if (!isNaN(lastIndex)) {
    if (!Array.isArray(current)) current = [];
    current[lastIndex] = value;
  } else {
    current[lastProp] = value;
  }

  // 確認用ログ
  sessionStorage.setItem("headerSet", JSON.stringify(data));
  // console.log(data.automation.items["new"].triggers[0].days);
};


/******************************************
 * ユーティリティ：ヘッダーのアイテムを設定する
 * 対象：各画面のヘッダー
 * アクション：ヘッダー要素の初期化
 ******************************************/
function initHeader() {
  // ==============================
  // DOM取得
  // ==============================
  const headerDom = {
    leftBtn: document.getElementById("headerLeftBtn"),
    title: document.getElementById("headerTitle"),
    rightBtn: document.getElementById("headerRightBtn"),
  };

  if (!headerDom.leftBtn || !headerDom.title || !headerDom.rightBtn) {
    console.warn("header DOM がまだ準備できていません");
    return;
  }

  // ==============================
  // headerSetBodyKeyキー取得
  // ==============================
  const currentHeaderSetKey = document.body.dataset.appHeaderSet;
  if (!currentHeaderSetKey) {
    console.warn("data-app-header-set が指定されていません");
    return;
  }

  // ==============================
  // headerSetJson 取得
  // ==============================
  const headerSetJson = getHeaderJsonValue(`${currentHeaderSetKey}`);
  if (!headerSetJson) {
    console.warn(`headerSet.${currentHeaderSetKey} が見つかりません`);
    return;
  }

  // ==============================
  // タイトル
  // ==============================
  headerDom.title.innerHTML = headerSetJson.title;

  // ==============================
  // 左ボタン
  // ==============================
  renderLeftButton(headerSetJson.left?.type, headerDom.leftBtn);
  headerDom.leftBtn.onclick = () =>
    handleHeaderLeftAction(headerSetJson.left?.type);

  // ==============================
  // 右ボタン
  // ==============================
  renderRightButton(headerSetJson.right, headerDom.rightBtn);
  headerDom.rightBtn.onclick = () =>
    handleHeaderRightAction(headerSetJson.right?.action);
}

// ==============================
// 左ボタン描画
// ==============================
// リセット
function renderLeftButton(type, btn) {
  btn.innerHTML = "";
  btn.classList.remove("d-none");
  // アイコン設定
  switch (type) {
    case "back":
      btn.innerHTML = '<i class="bi bi-chevron-left"></i>';
      break;
    case "drawer":
      btn.innerHTML = '<i class="bi bi-list"></i>';
      break;
    default:
      btn.classList.add("d-none");
  }
}

// ==============================
// 左アクション処理
// ==============================
function handleHeaderLeftAction(type) {
  switch (type) {
    case "back":
      // document.addEventListener("DOMContentLoaded", syncToggleFromStorage);
      // window.addEventListener("pageshow", syncToggleFromStorage);
      window.history.back();
      break;

    case "drawer":
      const bsOffcanvas = new bootstrap.Offcanvas("#appOffcanvas");
      bsOffcanvas.show();
      break;
  }
}

// ==============================
// 右ボタン描画
// ==============================
function renderRightButton(headerSetJsonRight, headerDomRight) {
  // 右ボタンのプロパティチェック
  if (!headerSetJsonRight || !headerSetJsonRight.visible) {
    headerDomRight.classList.add("d-none");
    headerDomRight.onclick = null;
    return;
  }

  // 表示
  headerDomRight.classList.remove("d-none");

  // text / icon / svg すべて対応
  headerDomRight.innerHTML = headerSetJsonRight.text || "";

  // クリック処理（あれば）
  headerDomRight.onclick = () => {
    handleHeaderRightAction(headerSetJsonRight.action, headerSetJsonRight);
  };
}

// ==============================
// 右アクション処理（完了/done | 設定/set | リンク/link | 編集/edit | 決定/ok）
// ==============================
function handleHeaderRightAction(action) {
  switch (action) {
    // JSON更新後、前の画面へ戻る
    case "done":
      window.history.back();
      break;

    // 電気代チェック画面へ遷移
    case "set":
      window.history.back();
      break;

    // 指定リンクへ遷移
    case "link":
      const rightBtn = document.getElementById("headerRightBtn");
      const target = getJsonValue(
        "headerSet.electricityBillCheck.right.target",
      );
      if (rightBtn) {
        rightBtn.href = target;
      }
      break;

    // 現在の画面が編集可能になるtouch-airflow-back
    case "edit":
      window.history.back();
      break;

    // タッチ気流、窓位置設定のポインターがロックされる
    case "ok":
      window.history.back();
      break;

    // アラート表示schedule-done
    case "alert":
      alert(
        "デモアプリではこのボタンは操作できません。＜ ボタンで戻ってください",
      );
      break;

    // スケジュール画面で完了
    case "schedule-done":
      setJsonValue("isAutoMationSetDone", true);
      window.location.href = "../schedule/";
      break;

    // アラート表示
    case "touch-airflow-back":
      alert(
        "風向を設定しました。やり直す場合は画像をダブルタップしてください。",
      );
      break;
  }
}

/******************************************
 * イニシャライズ：フッター
 * 対象：フッターのアイコン
 * アクション：JSON更新(currentPage)
 ******************************************/
const initFooterButtons = () => {
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      setJsonValue("currentPage", btn.dataset.appPage);
    });
  });
};

/******************************************
 * レンダリング：フッターアイコン表示更新
 * 対象：フッターのアイコン
 * アクション：アクティブページのフッターアイコンの表示更新
 ******************************************/
const initFooterButtonsState = () => {
  // フッターが存在しない画面
  const footerElement = document.getElementsByClassName("content-footer")[0];
  if (footerElement.className.includes("d-none")) {
    return;
  }
  // スタイルリセット
  const currentPage = getJsonValue("currentPage");
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.classList.remove("active");
  });
  // レンダリング
  footerButtons.forEach((btn) => {
    const page = btn.dataset.appPage;
    if (page === currentPage) {
      btn.classList.add("active");
    }
  });
};

/******************************************
 * ユーティリティ：全画面
 * 対象：トグルスイッチ（button要素内にあるスイッチ）
 * アクション：クリック時の伝播を防ぐ
 ******************************************/
document.querySelectorAll(".form-check-input").forEach((toggle) => {
  toggle.addEventListener("click", (e) => {
    e.stopPropagation();
  });
});

/******************************************
 * ユーティリティ：全画面
 * 対象：button要素、スイッチ要素
 * アクション：「デモアプリではこのボタンは操作できません。」を表示する
 ******************************************/
document.addEventListener("click", (e) => {
  const target = e.target.closest(".demo-toggle-alert");
  if (!target) return;

  // 現在の状態を保持（クリック後の状態）
  const currentChecked = target.checked;
  e.stopPropagation();

  alert("デモアプリではこのボタンは操作できません。");

  // 元の状態に戻す
  target.checked = !currentChecked;
});

  // 機器名、アイコンのマスター管理（以降の処理で使用するため）
    const DEVICE_MASTER = {
      "rac-1": {
        label: "リビングのエアコン",
        icon: "../assets/img/icon_AC_40pt.svg",
        settings: "../device-settings-rac/",
      },
      "rac-2": {
        label: "寝室のエアコン",
        icon: "../assets/img/icon_AC_40pt.svg",
        settings: "../device-settings-rac/",
      },
      "eq": {
        label: "給湯機",
        icon: "../assets/img/product_Icon_EQ_40pt.svg",
        settings: "../device-settings-eq/",
      },
    };

    // 機器情報取得
  const getDeviceInfo = (deviceId) => {
    return (
      DEVICE_MASTER[deviceId] ?? {
        label: "不明な機器",
        icon: "../assets/img/icon_AC_40pt.svg",
      }
    );
  };




/******************************************
 * アクション：エントリー用のオートメーションIDをJSONに保存して、編集画面へ遷移する
 ******************************************/
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".js-automation-id");
  if (!btn) return;

  const key = btn.dataset.appKey;
  setJsonValue("entryId", key);
  window.location.href = "../edit-automation/";
});

// オートメーション編集画面のレンダリング
const renderEditAutomationScreen = () => {
  // 変数をセット（オートメーションID、初期表示トリガーイベント）
  const entryId = getJsonValue("entryId");
  const entryTrigger =  getJsonValue(`${entryId}.entryTrigger`);

  // トリガーイベントボタンのアクティブ状態を設定
  const setActiveTriggerEvent = (entryTrigger) => {
    const targetElements = document.querySelectorAll(".js-trigger-event");

    targetElements.forEach((el) => {
      const key = el.dataset.appKey;

      if (key === entryTrigger) {
        el.classList.add("active");
        el.setAttribute("aria-pressed", "true");
      } else {
        el.classList.remove("active");
        el.setAttribute("aria-pressed", "false");
      }
    });
  };

  // トリガーイベントセクションの表示制御
  const renderTriggerSection = (triggerKey) => {
    const targetElements = document.querySelectorAll(".trigger-section");

    targetElements.forEach((el) => {
      if (el.dataset.appKey === triggerKey) {
        el.style.display = "";
      } else {
        el.style.display = "none";
      }
    });
  };

  // オートメーション名を代入
  const renderAutomationName = (entryId) => {
    const el = document.getElementById("autoName");
    const automationName = getJsonValue(`${entryId}.name`);

    if (!el) return;
    const name = automationName?.trim();
    if (name) {
      el.textContent = name;
    } else {
      el.textContent = "オートメーション名（未設定）";
    }
  };

  // 時間を代入
  const renderScheduleStartTime = (entryId) => {
    const el = document.getElementById("autoStartTime");
    const automationTime = getJsonValue(`${entryId}.triggers.schedule.time`);

    if (!el) return;
    const time = automationTime?.trim();
    if (time) {
      el.textContent = time;
    } else {
      el.textContent = "開始時間（未設定）";
    }
  };

  // 曜日を代入
  const renderScheduleDays = (entryId) => {
    const targetElements = document.querySelectorAll(".day-of-the-week");
    if (!targetElements.length) return;

    // schedule.days を安全に取得
    const days = getJsonValue(`${entryId}.triggers.schedule.days`) ?? [];

    targetElements.forEach((el) => {
      const day = el.dataset.appScheduleDay;
      const isActive = days.includes(day);

      el.classList.toggle("active", isActive);
      el.setAttribute("aria-pressed", String(isActive));
    });
  };

  // 曜日説明文を代入
  const renderScheduleDescription = (entryId) => {
    const updateScheduleDescription = (days) => {
      const allDays = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
      const dayNames = {
        sun: "日",
        mon: "月",
        tue: "火",
        wed: "水",
        thu: "木",
        fri: "金",
        sat: "土",
      };

      let description = "";
      if (days.length === 0) {
        // 何も選択されていない：一度だけ実行
        description = "一度だけ実行します";
      } else if (days.length === 7) {
        // 全て選択：毎日実行
        description = "毎日実行します";
      } else {
        // 一部選択：選択された曜日に実行
        const selectedDayNames = days
          .sort((a, b) => allDays.indexOf(a) - allDays.indexOf(b))
          .map((day) => dayNames[day])
          .join("");
        description = `毎週${selectedDayNames}曜日に実行します`;
      }
      // 説明文を表示する要素を探して更新
      const descriptionElement = document.getElementById("scheduleText");
      if (descriptionElement) {
        descriptionElement.textContent = description;
      }
    };

    const scheduleTrigger = getJsonValue(`${entryId}.triggers.schedule`);

    if (!scheduleTrigger) return;
    const days = scheduleTrigger.days ?? [];
    updateScheduleDescription(days);
  };

  // 通知するユーザーを代入
  const renderLocationUsers = (entryId) => {
    // location セクション内の checkbox を取得
    const checkboxes = document.querySelectorAll(
      '[data-app-key="location"] input[type="checkbox"]',
    );
    if (!checkboxes.length) return;

    // location trigger を取得
    const locationTrigger = getJsonValue(`${entryId}.triggers.location`);
    if (!locationTrigger) return;

    const selectedUsers = locationTrigger.users || [];

    checkboxes.forEach((checkbox) => {
      const userName = checkbox.value;

      const isChecked = selectedUsers.includes(userName);
      checkbox.checked = isChecked;
    });
  };

  // 位置条件のイベントを代入
  const renderLocationCondition = (entryId) => {
    const selectedCondition = getJsonValue(
      `${entryId}.triggers.location.event`,
    );

    function renderLocationCondition(selectedCondition) {
      // location 条件ボタンをすべて取得
      const targetElements = document.querySelectorAll(".js-location-condition");

      targetElements.forEach((el) => {
        const condition = el.dataset.appLocationCondition;

        if (condition === selectedCondition) {
          // 選択中
          el.setAttribute("aria-pressed", "true");
          el.classList.add("active");
        } else {
          // 非選択
          el.setAttribute("aria-pressed", "false");
          el.classList.remove("active");
        }
      });
    }

    const locationCondition = getJsonValue(
      `${entryId}.triggers.location.event`,
    ); // close / away

    renderLocationCondition(locationCondition);
  };

  // 機器名、アイコンのマスター管理（以降の処理で使用するため）
  //   const DEVICE_MASTER = {
  //     "rac-1": {
  //       label: "リビングのエアコン",
  //       icon: "../assets/img/icon_AC_40pt.svg",
  //       settings: "../device-settings-rac/",
  //     },
  //     "rac-2": {
  //       label: "寝室のエアコン",
  //       icon: "../assets/img/icon_AC_40pt.svg",
  //       settings: "../device-settings-rac/",
  //     },
  //     "eq": {
  //       label: "給湯機",
  //       icon: "../assets/img/product_Icon_EQ_40pt.svg",
  //       settings: "../device-settings-eq/",
  //     },
  //   };

  //   // 機器情報取得
  // const getDeviceInfo = (deviceId) => {
  //   return (
  //     DEVICE_MASTER[deviceId] ?? {
  //       label: "不明な機器",
  //       icon: "../assets/img/icon_AC_40pt.svg",
  //     }
  //   );
  // };

  // アクションボタンからのリンク
  const goToDeviceSettings = (deviceId) => {
    const device = DEVICE_MASTER[deviceId];
    if (!device) return;

    window.location.href = device.settings;
  };    

  // 機器の状態を代入
  const renderDeviceTrigger = (entryId) => {
    const trigger = getJsonValue(`${entryId}.triggers.devices`);
    if (!trigger) return;

    const container = document.getElementById("roomTemperatureThresholdButton");
    if (!container) return;

    const nameEl = container.querySelector(".name");
    const descEl = container.querySelector(".description");
    const tempEl = container.querySelector(".temperature");
    const imgEl = container.querySelector("img");

    const device = getDeviceInfo(trigger.id);

    // 機器名（マスターから取得）
    if (nameEl) nameEl.textContent = device.label;

    // 条件文
    if (descEl) descEl.textContent = trigger.condition ?? "";

    // 温度
    if (tempEl && trigger.threshold != null) {
      tempEl.textContent = `${trigger.threshold}℃`;
    }

    // アイコン
    if (imgEl) imgEl.src = device.icon;
  };

  // アクションを描画
  const renderActions = (entryId) => {
    const actions = getJsonValue(`${entryId}.actions`) ?? [];

    const container = document.getElementById("actionButtonsContainer");
    const template = document.getElementById("actionTemplate");
    if (!container || !template) return;

    const getDeviceDescription = (action) => {
      if (action.drive === "off") return "運転停止";

      if (action.drive === "on") {
        if (action.mode && action.temp) {
          return `${action.mode} ${action.temp}℃`;
        }
        return "運転開始";
      }

      return "";
    };

    const setActionButtonContent = (button, action) => {
      const nameEl = button.querySelector(".name");
      const descEl = button.querySelector(".description");
      const tempEl = button.querySelector(".temperature");
      const imgEl = button.querySelector(".source");

      if (!nameEl || !descEl || !tempEl || !imgEl) return;

      if (action.type === "devices") {
        const device = getDeviceInfo(action.id);

        button.dataset.deviceId = action.id;
        nameEl.textContent = device.label;
        descEl.textContent = getDeviceDescription(action);
        tempEl.textContent = "";
        imgEl.src = device.icon;
      }

      if (action.type === "notify") {
        nameEl.textContent = "通知";
        descEl.textContent = action.target ?? "";
        tempEl.textContent = "";
        imgEl.src = "../assets/img/icon_Notifications_40.svg";
      }
    };

    // 既存削除（テンプレ除外）
    container
      .querySelectorAll("button:not(#actionTemplate)")
      .forEach((el) => el.remove());

    // 描画
    actions.forEach((action) => {
      const button = template.cloneNode(true);
      button.removeAttribute("id");
      button.style.display = "";

      setActionButtonContent(button, action);
  if (action.type === "devices") {
    button.addEventListener("click", () => {
      goToDeviceSettings(action.id);
    });
  }

      container.appendChild(button);
    });
  };

const initScheduleDayButtons = () => {
  const buttons = document.querySelectorAll(".day-of-the-week");
  if (!buttons.length) return;

  buttons.forEach((button) => {
    button.addEventListener("click", () => {
      const entryId = getJsonValue("entryId");
      const day = button.dataset.appScheduleDay;

      // 現在の days を取得
      const days =
        getJsonValue(`${entryId}.triggers.schedule.days`) ?? [];

      // ON / OFF を切り替え
      const index = days.indexOf(day);
      if (index === -1) {
        days.push(day);
      } else {
        days.splice(index, 1);
      }

      console.log(day);

      // JSON に反映
      setJsonValue(`${entryId}.triggers.schedule.days`, days);
      // appData[entryId].triggers.schedule.days = days;

      // 再描画（← ここが重要）
      renderScheduleDays(entryId);
      renderScheduleDescription(entryId);
    });
  });
};

  // 実行する関数
  setActiveTriggerEvent(entryTrigger);
  renderTriggerSection(entryTrigger);
  renderAutomationName(entryId);
  renderScheduleStartTime(entryId);
  renderScheduleDays(entryId);
  renderScheduleDescription(entryId);
  renderLocationUsers(entryId);
  renderLocationCondition(entryId);
  renderDeviceTrigger(entryId);
  renderActions(entryId);
  initScheduleDayButtons();

  // トリガーイベントボタン クリック処理
  const initTriggerEventButtons = () => {
    const buttons = document.querySelectorAll(".js-trigger-event");
    if (!buttons.length) return;

    buttons.forEach((btn) => {
      btn.addEventListener("click", () => {
        const entryId = getJsonValue("entryId");
        const triggerKey = btn.dataset.appKey;

        // JSONを書き換える
        setJsonValue(`${entryId}.entryTrigger`, triggerKey);

        // 再描画
        renderEditAutomationScreen();
      });
    });
  };
    initTriggerEventButtons();
};

// 描画は何度でもOK
renderEditAutomationScreen();

/******************************************
 * イニシャライズ：オートメーション 画面
 * 対象：＋ボタン
 * アクション：新規オートメーション画面へ遷移する
 ******************************************/
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".js-add-automation");
  if (!btn) return;
  window.location.href = "../proposal-automation/";
});



document.addEventListener("click", (e) => {
  const btn = e.target.closest(".js-device-id");
  if (!btn) return;

  const key = btn.dataset.deviceId;
  setJsonValue("currentDeviceId", key);
});


const deviceSettngsRac = () => {
  const entryId = getJsonValue("entryId");
  const currentDeviceId = getJsonValue("currentDeviceId");
  const actions = getJsonValue(`${entryId}.actions`);
  const targetAction = actions.find(
    action => action.id === currentDeviceId
  );

let deviceName = "";

if (!targetAction) return;

if (targetAction.name) {
  // actions に直接 name がある場合
  deviceName = targetAction.name;
} else if (targetAction.type === "devices") {
  // device マスタから取得
  const device = getDeviceInfo(targetAction.id);
  deviceName = device?.label ?? "";
}
console.log(deviceName);

}