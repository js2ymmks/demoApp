/******************************************
 * テンプレートファイル読み込み
 ******************************************/
document.addEventListener("DOMContentLoaded", async () => {
  try {
    const [alert, header, date, footer, modal, drawer] = await Promise.all([
      fetch("../partials/alert.txt").then((r) => r.text()),
      fetch("../partials/header.txt").then((r) => r.text()),
      fetch("../partials/date.html").then((r) => r.text()),
      fetch("../partials/footer.txt").then((r) => r.text()),
      fetch("../partials/modal.txt").then((r) => r.text()),
      fetch("../partials/drawer-menu.txt").then((r) => r.text()),

      // 本番環境では下記を使用する
      // fetch("/home/mymu/demo/rac/partials/alert.txt").then((r) => r.text()),
      // fetch("/home/mymu/demo/rac/partials/header.txt").then((r) => r.text()),
      // fetch("/home/mymu/demo/rac/partials/date.html").then((r) => r.text()),
      // fetch("/home/mymu/demo/rac/partials/footer.txt").then((r) => r.text()),
      // fetch("/home/mymu/demo/rac/partials/modal.txt").then((r) => r.text()),
      // fetch("/home/mymu/demo/rac/partials/drawer-menu.txt").then((r) => r.text()),
    ]);

    document.querySelector(".content-alert").innerHTML = alert;
    document.querySelector(".content-header").innerHTML = header;
    document.querySelector(".content-date").innerHTML = date ?? "";
    document.querySelector(".content-footer").innerHTML = footer;
    document.querySelector(".content-modal").innerHTML = modal;
    document.querySelector(".content-drawer").innerHTML = drawer;
    initUI();
  } catch (err) {
    console.error("Failed to load partials:", err);
  }
});

function initUI() {
  // モーダル
  initModalDriveModeSelectButtons();
  initFooterButtons();
  initFooterButtonsState();
  initHeader();
  // 基本機能 画面
  // renderDriveModeSwitchBtnAndSettingPanelOperation();
}

/******************************************
 * イニシャライズ：モーダル
 * 対象：モーダル内の運転モード選択ボタン
 * アクション：JSON更新
 ******************************************/
const initModalDriveModeSelectButtons = () => {
  const modalDriveModeButtons = document.querySelectorAll(
    ".modal-drive-select-btn",
  );
  modalDriveModeButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      setJsonValue("currentMode", btn.dataset.appMode);
      const driveMode = getJsonValue("currentMode");
      const isAiAutoMode = driveMode.includes("ai-auto");
      if (!isAiAutoMode) {
        setJsonValue("isTouchAirflow", false);
      }
      renderDriveModeSwitchBtnAndSettingPanelOperation();
      renderWindControlOverlayOnOff();
      renderAirSettingDisplayForPerfationMode();
      updateDisplay(); // 温湿度風速設定値ディスプレイ更新
    });
  });
};

/******************************************
 * イニシャライズ：フッターアイコン
 * 対象：フッターのアイコン
 * アクション：JSON更新(currentPage)
 ******************************************/
const initFooterButtons = () => {
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      setJsonValue("currentPage", btn.dataset.appPage);
    });
  });
};

/******************************************
 * ユーティリティ：JSON取得（ブラケット版）
 * 対象：セッションストレージ内のJSONリテラル
 * アクション：セッションストレージ内のJSONから値を取得
 ******************************************/
const getJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }

  if (!data) return undefined;

  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }

  return current;
};

/******************************************
 * ユーティリティ：JSON更新（ブラケット版）
 * 対象：セッションストレージ内のJSONリテラル
 * アクション：セッションストレージ内のJSONの値を更新
 ******************************************/
const setJsonValue = (propertyPath, value) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : {};
  } catch (e) {
    data = {};
  }

  // ブラケット記法をドット記法に変換
  // "buttons[0].label" → "buttons.0.label"
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let i = 0; i < props.length - 1; i++) {
    const prop = props[i];

    // 数字 → 配列アクセス
    const index = Number(prop);
    const isIndex = !isNaN(index);

    if (isIndex) {
      if (!Array.isArray(current)) {
        current = [];
      }
      if (current[index] === undefined) {
        current[index] = {};
      }
      current = current[index];
    } else {
      if (!current[prop] || typeof current[prop] !== "object") {
        current[prop] = {};
      }
      current = current[prop];
    }
  }

  // 最終プロパティ
  const lastProp = props[props.length - 1];
  const lastIndex = Number(lastProp);

  if (!isNaN(lastIndex)) {
    if (!Array.isArray(current)) current = [];
    current[lastIndex] = value;
  } else {
    current[lastProp] = value;
  }

  sessionStorage.setItem("appData", JSON.stringify(data));
};

/******************************************
 * ユーティリティ：無効ボタンをクリックしたときの処理
 * 対象：.demo-disabled-button クラスを持つ要素
 * 対象：.demo-preventing-spread クラスを持つ要素
 * アクション：アラート表示
 ******************************************/
document.addEventListener("click", (e) => {
  // 親要素のクリックイベント伝播を防止
  if (e.target.closest(".demo-preventing-spread")) {
    e.stopPropagation();
    return;
  }

  // クリックされた要素、またはその親要素が指定のクラスを持っているか判定
  if (e.target.closest(".demo-disabled-button")) {
    alert("デモアプリではこのボタンは操作できません。");
    e.target.checked = !e.target.checked;
    return;
  }

  // クリックされた要素、またはその親要素が指定のクラスを持っているか判定
  if (e.target.closest(".demo-disabled-button-no-use")) {
    alert("デモアプリでは風速・風向の設定はできません。");
    e.target.checked = !e.target.checked;
    return;
  }

  // モーダル内部のクリックではモーダルを閉じない（以下の処理をスキップさせるため）
  if (e.target.closest(".modal-dialog")) {
    return;
  }

  // 開いているモーダルがあれば閉じる
  document.querySelectorAll(".modal.show").forEach((modalEl) => {
    const modalInstance =
      bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
    modalInstance.hide();
    return;
  });

});

/******************************************
 * ユーティリティ：無効ボタンをクリックしたときの処理
 * 対象：#tempDisplayのみ適用（クラスがJSONで自動作成されるため個別処置が必要）
 * アクション：アラート表示
 ******************************************/
document.addEventListener("click", (e) => {
  // 親要素のクリックイベント伝播を防止
  // クリックされた要素、またはその親要素が指定のクラスを持っているか判定
  // if (e.target.closest("#tempDisplay")) {
  //   alert("デモアプリではこのボタンは操作できません。");
  // }
});

/******************************************
 * ユーティリティ：モーダル表示
 * 対象：modal.html のモーダル
 * アクション：モーダル表示
 ******************************************/
const showModal = (modalId) => {
  const modalEl = document.getElementById(modalId);
  if (!modalEl) return;

  const modal = new bootstrap.Modal(modalEl);
  modal.show();
};

/******************************************
 * ユーティリティ：モーダルフォーカス解除
 * 対象：modal.html のモーダル
 * アクション：モーダルをクローズ後のフォーカス解除
 ******************************************/
window.addEventListener("hide.bs.modal", () => {
  document.activeElement.blur();
});

/******************************************
 * イニシャライズ：全ての 画面
 * 対象：関係するボタン
 * アクション：データ属性からメッセージを取得してトーストを表示する
 ******************************************/
let toastTimer = null;
function showToast(message, duration = 1500) {
  const toast = document.getElementById("appToast");
  if (!toast) return;

  // タイマーリセット
  if (toastTimer) {
    clearTimeout(toastTimer);
  }

  // 一旦消して再フローさせる（再アニメーション対策）
  toast.classList.remove("is-show");
  void toast.offsetWidth;

  toast.innerHTML = message;
  toast.classList.add("is-show");

  toastTimer = setTimeout(() => {
    toast.classList.remove("is-show");
  }, duration);
}

/******************************************
 * ユーティリティ：ヘッダーのアイテムを設定する
 * 対象：各画面のヘッダー
 * アクション：ヘッダー要素の初期化
 ******************************************/
window.addEventListener("load", () => {
  setTimeout(initHeader, 100);
});

function initHeader() {
  // ==============================
  // DOM取得
  // ==============================
  const headerDom = {
    leftBtn: document.getElementById("headerLeftBtn"),
    title: document.getElementById("headerTitle"),
    rightBtn: document.getElementById("headerRightBtn"),
  };

  if (!headerDom.leftBtn || !headerDom.title || !headerDom.rightBtn) {
    console.warn("header DOM がまだ準備できていません");
    return;
  }

  // ==============================
  // headerSetBodyKeyキー取得
  // ==============================
  const currentHeaderSetKey = document.body.dataset.appHeaderSet;
  if (!currentHeaderSetKey) {
    console.warn("data-app-header-set が指定されていません");
    return;
  }

  // ==============================
  // headerSetJson 取得
  // ==============================
  const headerSetJson = getJsonValue(`headerSet.${currentHeaderSetKey}`);
  if (!headerSetJson) {
    console.warn(`headerSet.${currentHeaderSetKey} が見つかりません`);
    return;
  }

  // ==============================
  // タイトル
  // ==============================
  headerDom.title.innerHTML = headerSetJson.title;

  // ==============================
  // 左ボタン
  // ==============================
  renderLeftButton(headerSetJson.left?.type, headerDom.leftBtn);
  headerDom.leftBtn.onclick = () =>
    handleHeaderLeftAction(headerSetJson.left?.type);

  // ==============================
  // 右ボタン
  // ==============================
  renderRightButton(headerSetJson.right, headerDom.rightBtn);
  headerDom.rightBtn.onclick = () =>
    handleHeaderRightAction(headerSetJson.right?.action);
}

// ==============================
// 左ボタン描画
// ==============================
// リセット
function renderLeftButton(type, btn) {
  btn.innerHTML = "";
  btn.classList.remove("d-none");
  // アイコン設定
  switch (type) {
    case "back":
      btn.innerHTML = '<i class="bi bi-chevron-left"></i>';
      break;
    case "drawer":
      btn.innerHTML = '<i class="bi bi-list"></i>';
      break;
    default:
      btn.classList.add("d-none");
  }
}

// ==============================
// 左アクション処理
// ==============================
function handleHeaderLeftAction(type) {
  switch (type) {
    case "back":
      // document.addEventListener("DOMContentLoaded", syncToggleFromStorage);
      // window.addEventListener("pageshow", syncToggleFromStorage);
      window.history.back();
      break;

    case "drawer":
      const bsOffcanvas = new bootstrap.Offcanvas("#appOffcanvas");
      bsOffcanvas.show();
      break;
  }
}

// ==============================
// 右ボタン描画
// ==============================
function renderRightButton(headerSetJsonRight, headerDomRight) {
  // 右ボタンのプロパティチェック
  if (!headerSetJsonRight || !headerSetJsonRight.visible) {
    headerDomRight.classList.add("d-none");
    headerDomRight.onclick = null;
    return;
  }
  // 右側のテキストボタン表示
  headerDomRight.innerText = headerSetJsonRight.text || "";

  // ★ ボーダー制御
  if (headerSetJsonRight.bordered) {
    headerDomRight.classList.add("header-right-bordered");
  } else {
    headerDomRight.classList.remove("header-right-bordered");
  }

}

// ==============================
// 右アクション処理（完了/done | 設定/set | リンク/link | 編集/edit | 決定/ok）
// ==============================
function handleHeaderRightAction(action) {
  switch (action) {
    // JSON更新後、前の画面へ戻る
    case "done":
      window.history.back();
      break;

    // 電気代チェック画面へ遷移
    case "set":
      window.history.back();
      break;

    // 指定リンクへ遷移
    case "link":
      const rightBtn = document.getElementById("headerRightBtn");
      const target = getJsonValue(
        "headerSet.electricityBillCheck.right.target",
      );
      if (rightBtn) {
        rightBtn.href = target;
      }
      break;

    // 現在の画面が編集可能になるtouch-airflow-back
    case "edit":
      window.history.back();
      break;

    // タッチ気流、窓位置設定のポインターがロックされる
    case "ok":
      window.history.back();
      break;

    // アラート表示schedule-done
    case "alert":
      alert(
        "デモアプリではこのボタンは操作できません。＜ ボタンで戻ってください",
      );
      break;

    // スケジュール画面で完了
    case "schedule-done":
      setJsonValue("isAutoMationSetDone", true);
      window.location.href = '../schedule/';
      break;

    // アラート表示
    case "touch-airflow-back":
      // alert(
      //   "風向を設定しました。",
      // );
      showToast("タッチ気流をONしました。<br />A.I.自動で運転します。");
      break;
  }
}

/******************************************
 * レンダリング：フッターアイコン表示更新
 * 対象：フッターのアイコン
 * アクション：アクティブページのフッターアイコンの表示更新
 ******************************************/
const initFooterButtonsState = () => {
  // 0. フッターが存在しない画面の処理
  const footerElement = document.getElementsByClassName("content-footer")[0];
  if (footerElement.className.includes("d-none")) {
    return;
  }
  // スタイルリセット
  const currentPage = getJsonValue("currentPage");
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.classList.remove("active");
  });
  // レンダリング
  footerButtons.forEach((btn) => {
    const page = btn.dataset.appPage;
    if (page === currentPage) {
      btn.classList.add("active");
    }
  });
};

/******************************************
 * レンダリング：基本機能 画面
 * 対象：熱画像ホルダー
 * アクション：表示/非表示
 ******************************************/
const renderThermalImageOnOff = () => {
  const isThermalImageManagement = getJsonValue("isThermalImageManagement");
  const thermalImageElement = document.getElementById("thermalImageContainer");
  isThermalImageManagement
    ? (thermalImageElement.style.visibility = "visible")
    : (thermalImageElement.style.visibility = "hidden");
};

/******************************************
 * レンダリング：基本機能 画面
 * 対象：操作パネル（運転モード選択ボタン／ラベル／アイコン／設定表示（温度／湿度・送風））
 * アクション：操作パネルの更新
 ******************************************/
const renderDriveModeSwitchBtnAndSettingPanelOperation = () => {
  let currentMode = getJsonValue("currentMode");
  const switchBtn = document.getElementById("driveModeSwitchBtn");
  const switchBtnLabel = document.getElementById("currentModeLabel");
  const switchBtnIcon = document.getElementById("currentModeIcon");
  const switchBtnTempDisplay = document.getElementById("tempDisplay");
  // クラスをリセット
  let initialStyle =
    "btn rounded-pill d-flex justify-content-center align-items-center gap-2 mt-3 app-drive-btn";
  document.getElementById("driveModeSwitchBtn").className = initialStyle;
  // クラス、ラベル、アイコン、設定表示を更新
  switchBtn.classList.add(
    getJsonValue(`driveModeSelectBtn.${currentMode}.style`),
  );
  switchBtnLabel.innerText = getJsonValue(
    `driveModeSelectBtn.${currentMode}.label`,
  );
  switchBtnIcon.src = getJsonValue(`driveModeSelectBtn.${currentMode}.icon`);
  switchBtnTempDisplay.className = getJsonValue(
    `driveModeSelectBtn.${currentMode}.settingDisplay`,
  );
};

/******************************************
 * レンダリング：基本機能 画面
 * 対象：風速上下風向左右風向ホルダー
 * アクション：オーバーレイ表示/非表示
 ******************************************/
const renderWindControlOverlayOnOff = () => {
  const overlay = document.querySelector(".wind-overlay");
  const mode = getJsonValue("currentMode");
  const image01 = document.getElementById("image01");
  const image02 = document.getElementById("image02");
  const image03 = document.getElementById("image03");
  const image04 = document.getElementById("image04");
  const image05 = document.getElementById("image05");
  const image06 = document.getElementById("image06");
  const image07 = document.getElementById("image07");
  const image08 = document.getElementById("image08");

  image01.style.display = "none";
  image02.style.display = "none";
  image03.style.display = "none";
  image04.style.display = "none";
  image05.style.display = "none";
  image06.style.display = "none";
  image07.style.display = "none";
  image08.style.display = "none";

  function displayCHangeOn() {
    overlay.style.display = "block"
    image02.style.display = "block";
    image05.style.display = "inline-block";
    image06.style.display = "inline-block";
    image08.style.display = "block";
  }

  function displayCHangeOff() {
    overlay.style.display = "none"
    image01.style.display = "block";
    image03.style.display = "inline-block";
    image04.style.display = "inline-block";
    image07.style.display = "block";
  }

  mode.includes("ai-auto")
    ? displayCHangeOn()
    : displayCHangeOff();

};

/******************************************
 * レンダリング：基本機能
 * 対象：運転する⇔停止する ボタンのスタイルとラベル名
 * アクション：ボタンの表示更新（運転する／停止する）
 ******************************************/
const renderDriveOnOffButton = () => {
  const btn = document.getElementById("btnRunStop");
  if (!btn) return;
  const isRunning = getJsonValue("modalDrive.isRunning");
  // 運転中の場合
  if (isRunning) {
    btn.style.backgroundColor = "white";
    btn.style.color = "var(--app-color-cooling)";
    btn.innerText = "停止する";
    // 停止中の場合
  } else {
    btn.style.backgroundColor = "var(--app-color-cooling)";
    btn.style.color = "white";
    btn.innerText = "運転する";
  }
};

/******************************************
 * イニシャライズ：基本機能 画面
 * 対象：運転する⇔停止する ボタン
 * アクション：モーダル表示
 ******************************************/
document.addEventListener("click", (e) => {
  const trigger = e.target.closest(".js-drive-trigger");
  if (!trigger) return;

  const isRunning = getJsonValue("modalDrive.isRunning");
  const modal = document.getElementById("modalRacStartStop");
  if (!modal) return;

  const messageEl = modal.querySelector("#modalRacStartStopMessage");
  const okBtn = modal.querySelector(".js-modal-drive");

  if (!messageEl || !okBtn) return;

  if (isRunning) {
    messageEl.textContent = trigger.dataset.messageRun;
    okBtn.dataset.appDrive = "runToStop";
  } else {
    messageEl.textContent = trigger.dataset.messageStop;
    okBtn.dataset.appDrive = "stopToRun";
  }

  showModal("modalRacStartStop");
});

/******************************************
 * イニシャライズ：基本機能 画面
 * 対象：運転する⇔停止する ボタン
 * アクション：クリック後のJSON更新
 ******************************************/
document.addEventListener("pointerup", (e) => {
  const btn = e.target.closest(".js-modal-drive");
  if (!btn) return;

  btn.dataset.appDrive === "stopToRun" ? handleRacStart() : handleRacStop();

  const modalEl = btn.closest(".modal");
  bootstrap.Modal.getInstance(modalEl).hide();

  renderDriveOnOffButton();
});
// 停止⇒ 運転
const handleRacStart = () => {
  setJsonValue("modalDrive.isRunning", true);
};
// 運転⇒ 停止
const handleRacStop = () => {
  setJsonValue("modalDrive.isRunning", false);
  setJsonValue("isTouchAirflow", false);
};

/******************************************
 * イニシャライズ：基本機能 画面
 * 熱画像 イメージ
 * アクション：クリック後の表示を、熱画像／タッチ気流のどちらかへリンクする
 ******************************************/
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".js-thermal-image");
  if (!btn) return;
  const isTouchAirflowOn = getJsonValue("isTouchAirflow");
  isTouchAirflowOn
    ? window.location.href = "../touch-airflow/"
    : window.location.href = "../thermal-image/";
});

/******************************************
 * レンダリング：基本機能 画面
 * 対象：「停止中」表示⇔非表示 ホルダー
 * アクション：表示/非表示
 ******************************************/
// 「停止中」を非表示
const elementsDisplayDefault = () => {
  const setValueDisplay = document.getElementById("setValueDisplay");
  const airControl = document.getElementById("airControl");
  const statusStopped = document.getElementById("statusStopped");
  // 各要素の表示・非表示を制御
  setValueDisplay.classList.remove("d-none");
  airControl.classList.remove("d-none");
  statusStopped.classList.add("d-none");
};

// 「停止中」を表示
const elementsDisplayNone = () => {
  const setValueDisplay = document.getElementById("setValueDisplay");
  const airControl = document.getElementById("airControl");
  const statusStopped = document.getElementById("statusStopped");
  // 各要素の表示・非表示を制御
  setValueDisplay.classList.add("d-none");
  airControl.classList.add("d-none");
  statusStopped.classList.remove("d-none");
};

const renderStatusStoppedEl = () => {
  const isRunning = getJsonValue("modalDrive.isRunning");
  if (isRunning) {
    elementsDisplayDefault();
  } else {
    elementsDisplayNone();
  }
};

/******************************************
 * イニシャライズ：その他機能 画面
 * 対象：タッチ気流トグルスイッチa
 * アクション：JSONの値からモーダル表示
 ******************************************/
document.addEventListener("click", (e) => {
  const toggle = e.target.closest("#toggleTouchAirflow");
  if (!toggle) return;

  const isThermalImageManagement = getJsonValue("isThermalImageManagement");
  const isRunning = getJsonValue("modalDrive.isRunning");
  const driveMode = getJsonValue("currentMode");

  // =========================
  // OFF → ON にしようとした
  // =========================
  if (toggle.checked) {
    // 熱画像OFF
    if (!isThermalImageManagement) {
      showModal("modalThermalImageManagementRequirement");
      renderTouchAirflowToggle(); // JSON基準で戻す
      return;
    }

    // 停止中
    if (!isRunning) {
      showModal("modalTouchAirflowRequirement");
      renderTouchAirflowToggle();
      return;
    }

    // モードチェック
    switch (driveMode) {
      case "cooling":
        setJsonValue("currentMode", "ai-auto-cooling");
        break;

      case "heating":
        setJsonValue("currentMode", "ai-auto-heating");
        break;

      case "perflation":
      case "dehumidifying":
        showModal("modalTouchAirflowRequirement");
        renderTouchAirflowToggle();
        return;
    }

    // ON 確定
    setJsonValue("isTouchAirflow", true);
    renderTouchAirflowToggle();
    showToast("タッチ気流をONしました。<br />A.I.自動で運転します。");

    return;
  }

  // =========================
  // ON → OFF
  // =========================
  setJsonValue("isTouchAirflow", false);
  renderTouchAirflowToggle();
  showToast("タッチ気流をOFFしました");

});

document.addEventListener("click", (e) => {
  const toggle = e.target.closest("#toggleTouchAirflow");
  if (!toggle) return;

  const isChecked = toggle.checked;
  if (isChecked) {
    // ON処理
    // console.log("ONにしました");
    // showToast("オンになりました");
  } else {
    // OFF処理
    // console.log("OFFにしました");
    // showToast("オフになりました");
  }
});

/******************************************
 * レンダリング：その他機能画面
 * 対象：タッチ気流トグルスイッチa
 * アクション：タッチ気流トグルスイッチの表示更新
 ******************************************/
// タッチ気流トグルスイッチ
const renderTouchAirflowToggle = () => {
  const value = getJsonValue("isTouchAirflow");
  const btn = document.getElementById("toggleTouchAirflow");
  if (value) {
    btn.checked = true;
    btn.nextElementSibling.innerText = "ON";
    document.getElementById("touchAirflowCardLink").classList.remove("stretched-link-none");
  } else {
    btn.checked = false;
    btn.nextElementSibling.innerText = "OFF";
    document.getElementById("touchAirflowCardLink").classList.add("stretched-link-none");
  }
};

/******************************************
 * レンダリング：熱画像管理画面
 * 対象：熱画像トグルスイッチ
 * アクション：トグルスイッチの表示更新
 ******************************************/
const renderThermalImageManagementToggle = () => {
  const value = getJsonValue("isThermalImageManagement");
  const toggle = document.getElementById("thermalImageManagement");
  if (value) {
    toggle.checked = true;
  } else {
    toggle.checked = false;
  }
};

/******************************************
 * イニシャライズ：熱画像管理画面
 * 対象：熱画像トグルスイッチa
 * アクション：JSONの値を更新（タッチ気流のJSONも更新）
 ******************************************/
document.addEventListener("click", (e) => {
  const targetSwitch = e.target.closest("#thermalImageManagement");
  if (!targetSwitch) return;
  const isTouchAirflow = getJsonValue("isTouchAirflow");

  targetSwitch.addEventListener("change", () => {
    // 熱画像トグルスイッチ　OFF → ON でJSON更新
    if (targetSwitch.checked) {
      setJsonValue("isThermalImageManagement", true);
      // 熱画像トグルスイッチ　ON → OFF でJSON更新
    } else {
      setJsonValue("isThermalImageManagement", false);
      setJsonValue("isTouchAirflow", false); // タッチ気流を強制OFF
    }
  });
});

/******************************************
 * レンダリング：スケジュール 画面
 * 対象：3つ目のオートメーションの各値表示
 * アクション：JSONの値を各要素に反映
 ******************************************/
const renderScheduleDetails3 = () => {
  const isScheduleEnabled = getJsonValue("isAutoMationSetDone");
  if (!isScheduleEnabled) return;
  // 3つ目のスケジュールカード表示
  document.getElementById("scheduleDetail3").style.display = "block";
  // スケジュール名
  document.getElementById("scheduleName3").innerText =
    getJsonValue("schedule[0].name");
  // 時間
  document.getElementById("scheduleTime3").innerText = getJsonValue(
    "schedule[0].startTime",
  );
  // 繰り返し
  document.getElementById("scheduleRepeat3").innerText = getJsonValue(
    "schedule[0].dayOfTheWeekLabel",
  );
  // 運転／停止
  document.getElementById("scheduleDriveOnOff3").innerText = getJsonValue(
    "schedule[0].isDrive",
  )
    ? "運転"
    : "停止";
  // モード
  document.getElementById("scheduleDriveMode3").innerText =
    getJsonValue("schedule[0].mode");
  // 設定温度
  document.getElementById("scheduleSetValue3").innerText =
    getJsonValue("schedule[0].setValue") + "℃";
};

/******************************************
 * イニシャライズ：スケジュール編集 画面
 * 対象：オートメーション削除ボタン
 * アクション：削除ボタンをクリックするとJSONの値を更新
 ******************************************/
const initDeleteAutomation = () => {
  setJsonValue("isAutoMationSetDone", false);
  setJsonValue("schedule[0].dayOfTheWeek", false);
  setJsonValue("schedule[0].isDrive", true);
  setJsonValue("schedule[0].mode", "冷房");
  setJsonValue("automationMode", null);
  window.location.href = "../schedule/";
};

document.addEventListener("click", (e) => {
  // クリックされた要素、またはその親要素が指定のクラスを持っているか判定
  const target = e.target.closest(".js-automation-create");
  if (!target) return;
  setJsonValue("automationMode", "create");
});

document.addEventListener("click", (e) => {
  // クリックされた要素、またはその親要素が指定のクラスを持っているか判定
  const target = e.target.closest("#scheduleDetail3");
  if (!target) return;
  setJsonValue("automationMode", "edit");
});


/******************************************
 * レンダリング：スケジュール編集 画面
 * 対象：3つ目のオートメーション
 * アクション：isAutoMationSetDone の値に応じて表示/非表示
 ******************************************/
const renderDeleteTheAutomationButton = () => {
  const automationDeleteBtn = document.getElementById("btnDeleteTheAutomation");
  const automationMode = getJsonValue("automationMode");
  const isAutoMationSetDone = getJsonValue("isAutoMationSetDone");

  if (automationMode === "edit" && isAutoMationSetDone === true) {
    automationDeleteBtn.classList.remove("d-none");
  } else {
    automationDeleteBtn.classList.add("d-none");
  }

};


/******************************************
 * スケジュール表示処理
 ******************************************/
// 曜日表示用マップ
const DAY_LABEL_MAP = {
  sun: "日",
  mon: "月",
  tue: "火",
  wed: "水",
  thu: "木",
  fri: "金",
  sat: "土",
};

// スケジュール表示テキスト取得関数（スケジュール 画面用）
function getScheduleText() {
  const dayOfTheWeek = getJsonValue("schedule[0].dayOfTheWeek");
  const activeDays = Object.entries(dayOfTheWeek)
    .filter(([, value]) => value === true)
    .map(([key]) => key);

  // 何も選択されていない
  if (activeDays.length === 0) {
    return "一度だけ実行します";
  }

  // 全て選択
  if (activeDays.length === 7) {
    return "毎日実行します";
  }

  // 一部選択
  const labelText = activeDays.map((day) => DAY_LABEL_MAP[day]).join("、");

  return `毎週${labelText}曜日に実行します`;
}

// スケジュール表示テキスト取得関数（スケジュール編集 画面用）
function getScheduleTextShort() {
  const dayOfTheWeek = getJsonValue("schedule[0].dayOfTheWeek");
  const activeDays = Object.entries(dayOfTheWeek)
    .filter(([, value]) => value === true)
    .map(([key]) => key);

  // 何も選択されていない
  if (activeDays.length === 0) {
    return null;
  }

  // 全て選択
  if (activeDays.length === 7) {
    return "毎日";
  }

  // 一部選択
  const labelText = activeDays.map((day) => DAY_LABEL_MAP[day]).join("");

  return `${labelText}`;
}

// 表示アップデート 関数
function renderDayOfWeekToggle() {
  const dayOfTheWeek = getJsonValue("schedule[0].dayOfTheWeek");

  document.querySelectorAll(".day-of-the-week").forEach((button) => {
    const dayKey = button.dataset.appScheduleDay; // sun, mon...

    if (dayOfTheWeek[dayKey]) {
      button.classList.add("active");
      button.setAttribute("aria-pressed", "true");
    } else {
      button.classList.remove("active");
      button.setAttribute("aria-pressed", "false");
    }
  });

  updateScheduleText();
}

// トグルスイッチのクリックイベントをバインド 関数（JSON → トグル + 文言）
function bindDayOfWeekEvents() {
  document.querySelectorAll(".day-of-the-week").forEach((button) => {
    button.addEventListener("click", () => {
      const dayKey = button.dataset.appScheduleDay;
      const isActive = button.classList.contains("active");

      const path = `schedule[0].dayOfTheWeek.${dayKey}`;
      setJsonValue(path, isActive);

      updateScheduleText();
    });
  });
}

// 文言更新のみ 関数
function updateScheduleText() {
  const textEl = document.getElementById("scheduleText");
  // スケジュール 画面用
  if (textEl) {
    textEl.innerText = getScheduleText();
  }
  // スケジュール編集 画面用onclick="inputFormToJsonAutomationName()">
  setJsonValue("schedule[0].dayOfTheWeekLabel", getScheduleTextShort());
}

document.addEventListener("DOMContentLoaded", () => {
  const offcanvasLinkHandler = () => {
    const link = document.getElementById("transition-link");
    const myOffcanvasElement = document.getElementById("appOffcanvas");
  };

  offcanvasLinkHandler();
});

/******************************************
 * イニシャライズ：スケジュール編集 画面
 * 対象：オートメーション名入力フォーム
 * アクション：決定ボタンをクリックするとJSONの値を更新
 ******************************************/
const inputFormToJsonAutomationName = () => {
  const input = document.getElementById("scheduleName");
  const value = input.value;
  setJsonValue("schedule[0].name", value);
  document.getElementById("scheduleName3").innerText = value;
};

/******************************************
 * イニシャライズ：電気代チェック 画面
 * 対象：電気代／電力量タブ
 * アクション：JSONの値を更新
 ******************************************/
document.addEventListener("click", (e) => {
  // クリックされた要素、またはその親要素が指定のクラスを持っているか判定
  const target = e.target.closest("#electricityBillTab");
  if (target) {
    setJsonValue("electricityBill.isSelected", true);
    setJsonValue("electricityConsumption.isSelected", false);
    renderElectricityBillCheckTab();
    renderElectricityBillPeriodButton();
  }
});

document.addEventListener("click", (e) => {
  // クリックされた要素、またはその親要素が指定のクラスを持っているか判定
  const target = e.target.closest("#electricityConsumptionTab");
  if (target) {
    setJsonValue("electricityBill.isSelected", false);
    setJsonValue("electricityConsumption.isSelected", true);
    renderElectricityBillCheckTab();
    renderElectricityBillPeriodButton();
  }
});

/******************************************
 * レンダリング：電気代チェック 画面
 * 対象：電気代／電力量タブ
 * アクション：JSONの値を取得して表示更新
 ******************************************/
const renderElectricityBillCheckTab = () => {
  const isElectricityBillSelected = getJsonValue("electricityBill.isSelected");
  const electricityBillTab = document.getElementById("electricityBillTab");
  const electricityConsumptionTab = document.getElementById("electricityConsumptionTab");

  // リセット
  electricityBillTab.classList.remove("selected-tab");
  electricityConsumptionTab.classList.remove("selected-tab");
  // レンダリング 
  isElectricityBillSelected ? electricityBillTab.classList.add("selected-tab") : electricityConsumptionTab.classList.add("selected-tab");
};

/******************************************
 * レンダリング：電気代チェック 画面
 * 対象：月間／年間ボタン
 * アクション：JSONの値を取得して表示更新
 ******************************************/
const renderElectricityBillPeriodButton = () => {
  // 選択されたタブ（直接変数に）
  const targetTab = getJsonValue("electricityBill.isSelected") ? "electricityBill" : "electricityConsumption";

  // 初期化
  document.querySelectorAll(".js-period-btn").forEach((btn) => {
    btn.classList.remove("selected-period-btn");
  });

  const monthlyBtn = document.querySelector('.js-period-btn[data-app-period-type="monthly"]');
  const yearlyBtn = document.querySelector('.js-period-btn[data-app-period-type="yearly"]');
  const targetImg = document.querySelector(".js-electricity-bill-check-image"); // ← クラス名に注意
  const isMonthlySelected = getJsonValue(`${targetTab}.period.monthly.isSelected`);

  // 要素の存在チェック
  if (!monthlyBtn || !yearlyBtn || !targetImg) return;

  // ボタン選択（共通処理）
  const selectedBtn = isMonthlySelected ? monthlyBtn : yearlyBtn;
  selectedBtn.classList.add("selected-period-btn");

  // 画像パスを組み立てる（targetTab に応じたベース名を作る）
  const base = targetTab === "electricityBill" ? "electricity-bill" : "electricity-consumption";
  const period = isMonthlySelected ? "monthly" : "yearly";
  targetImg.src = `../assets/img/${base}-${period}.svg`;
};

/******************************************
 * イニシャライズ：電気代チェック 画面
 * 対象：年間／月間スイッチボタン
 * アクション：JSONの値を更新
 ******************************************/
document.addEventListener("click", (e) => {
  // 選択されたタブを取得
  const selectedTab = () => {
    const isElectricityBillSelected = getJsonValue("electricityBill.isSelected");
    return isElectricityBillSelected ? "electricityBill" : "electricityConsumption";
  };

  const targetBtn = e.target.closest(".js-period-btn");
  if (!targetBtn) return;
  const targetBtnDataset = targetBtn.dataset.appPeriodType;
  const targetTab = selectedTab();

  if (!targetBtn) return;

  switch (targetTab) {
    case "electricityBill":
      if (targetBtnDataset === "monthly") {
        setJsonValue(`${targetTab}.period.monthly.isSelected`, true);
        setJsonValue(`${targetTab}.period.yearly.isSelected`, false);
      }
      if (targetBtnDataset === "yearly") {
        setJsonValue(`${targetTab}.period.monthly.isSelected`, false);
        setJsonValue(`${targetTab}.period.yearly.isSelected`, true);
      }
      break;
    case "electricityConsumption":
      if (targetBtnDataset === "monthly") {
        setJsonValue(`${targetTab}.period.monthly.isSelected`, true);
        setJsonValue(`${targetTab}.period.yearly.isSelected`, false);
      }
      if (targetBtnDataset === "yearly") {
        setJsonValue(`${targetTab}.period.monthly.isSelected`, false);
        setJsonValue(`${targetTab}.period.yearly.isSelected`, true);
      }
      break;
    default:
      return;
  }

  renderElectricityBillPeriodButton();
});

/******************************************
 * イニシャライズ：関係する画面
 * 対象：トグルスイッチボタン
 * アクション：クリック後のアラート（デモアプリでは使用できません）を表示する
 ******************************************/
document.addEventListener("click", (e) => {
  const target = e.target.closest(".demo-toggle-alert");
  if (!target) return;

  // 現在の状態を保持（クリック後の状態）
  const currentChecked = target.checked;
  e.stopPropagation();

  alert("デモアプリではこのボタンは操作できません。");

  // 元の状態に戻す
  target.checked = !currentChecked;
});

/******************************************
 * レンダリング：基本機能画面
 * 対象：温湿度風速設定値ディスプレイ／送風アイコン
 * アクション：運転モードが送風の場合の送風アイコンを表示
 ******************************************/
const renderAirSettingDisplayForPerfationMode = () => {
  const currentMode = getJsonValue("currentMode");
  const setValueDisplay = document.getElementById("setValueDisplay");
  const perflationIconDisplayHolder = document.getElementById("perflationIconDisplayHolder");
  const isPerflationMode = currentMode === "perflation" ? true : false;
  if (isPerflationMode) {
    perflationIconDisplayHolder.style.display = "block";
    setValueDisplay.style.display = "none";

  } else {
    perflationIconDisplayHolder.style.display = "none";
    setValueDisplay.style.display = "block";
  }
};

/******************************************
 * レンダリング：基本機能画面
 * 対象：温湿度風速設定値ディスプレイ
 * アクション：運転モードを切り替えると温湿度風速設定値ディスプレイを更新（JSONなし）
 ******************************************/
function updateDisplay() {
  const currentMode = getJsonValue("currentMode");

  // ---------- 表示 ----------
  if (currentMode === "cooling" || currentMode === "heating" || currentMode === "ai-auto-cooling" || currentMode === "ai-auto-heating") {
    const fixed = currentTemp.toFixed(1);
    const [intPart, decPartRaw] = fixed.split(".");
    tempIntEl.textContent = intPart;
    tempDecEl.textContent = "." + decPartRaw;
    tempUnitEl.innerText = TEMP_UNIT;
  }

  if (currentMode === "dehumidifying") {
    tempIntEl.textContent = currentHumidity;
    tempDecEl.textContent = "";
    tempUnitEl.innerText = HUMIDITY_UNIT;
  }

  if (currentMode === "perflation") {
    tempIntEl.textContent = PERFLATION_MODES[currentPerflationIndex];
    tempDecEl.textContent = "";
    tempUnitEl.innerText = "";
  }

  // ---------- ボタン制御 ----------
  let isMin = false;
  let isMax = false;

  if (currentMode === "cooling" || currentMode === "heating" || currentMode === "ai-auto-cooling" || currentMode === "ai-auto-heating") {
    isMin = currentTemp <= MIN_TEMP;
    isMax = currentTemp >= MAX_TEMP;
  }

  if (currentMode === "dehumidifying") {
    isMin = currentHumidity <= MIN_HUMIDITY;
    isMax = currentHumidity >= MAX_HUMIDITY;
  }

  if (currentMode === "perflation") {
    isMin = currentPerflationIndex <= 0;
    isMax = currentPerflationIndex >= PERFLATION_MODES.length - 1;
  }

  btnDown.classList.toggle("disabled", isMin);
  btnUp.classList.toggle("disabled", isMax);
}

/******************************************
 * レンダリング：スケジュール画面
 * 対象：モード切替ボタン
 * アクション：運転モードを切り替えると設定温度ボタン領域が無効
 ******************************************/
const renderSetupTemperatureButtonDisabled = () => {
  const modeButtons = document.querySelectorAll(".js-mode-switch");
  const targetElement = document.getElementById("btnScheduleSetValue");
  const temperature = document.querySelector(".settingTemp");
  const windSection = document.querySelectorAll("#windSection .windSectionBtn");

  // 共通処理（modeに応じて無効化/有効化）
  const applyMode = (mode) => {
    if (!mode) return;
    const m = String(mode).trim();
    if (m === "除湿" || m === "送風") {
      temperature.innerText = "--";
      targetElement.classList.add("opacity-50", "bg-body-secondary", "border-0");
      windSection.forEach(el => el.classList.remove("opacity-50", "bg-body-secondary", "border-0"));
      windSection.forEach(el => {
        el.querySelectorAll("button, input[type='checkbox'], input[type='radio']").forEach((element) => {
          element.disabled = false;
        });
      });
      targetElement.style.pointerEvents = "none";
    } else if (m === "A.I.自動(冷房)" || m === "A.I.自動(暖房)") {
      windSection.forEach(el => el.classList.add("opacity-50", "bg-body-secondary", "border-0"));
      windSection.forEach(el => {
        el.querySelectorAll("button, input[type='checkbox'], input[type='radio']").forEach((element) => {
          element.disabled = true;
        });
      });
    } else {
      temperature.innerText = "27.0℃";
      targetElement.classList.remove("opacity-50", "bg-body-secondary", "border-0");
      windSection.forEach(el => el.classList.remove("opacity-50", "bg-body-secondary", "border-0"));
      windSection.forEach(el => {
        el.querySelectorAll("button, input[type='checkbox'], input[type='radio']").forEach((element) => {
          element.disabled = false;
        });
      });
      targetElement.style.pointerEvents = "";
    }
  };

  // ボタンクリック時の処理（クリックしたボタンのデータ属性を使う）
  modeButtons.forEach(button => {
    button.addEventListener("click", function () {
      const clickedMode = this.dataset.appScheduleMode;
      applyMode(clickedMode);

      // 必要ならここでJSON（状態）を更新する処理を呼ぶ
      // updateJsonValue("schedule[0].mode", clickedMode);
    });
  });

  // 初期ロード時：JSONから選択中のモードを取得して適用
  const initialMode = getJsonValue("schedule[0].mode");
  applyMode(initialMode);
};

/******************************************
 * レンダリング：基本機能 画面
 * 対象：モード切替ボタン
 * アクション：運転モードに合わせて設定値のモーダルを切り替えて表示する
 ******************************************/
function openModalByMode() {
  const currentMode = getJsonValue("currentMode");
  // currentMode → モーダルID
  const modeToModalMap = {
    cooling: "scheduletemperatureModal",
    heating: "scheduletemperatureModal",
    "ai-auto-cooling": "scheduletemperatureModal",
    "ai-auto-heating": "scheduletemperatureModal",
    dehumidifying: "scheduledehumidifyingModal",
    perflation: "schedulePerflationModal"
  };

  const modalId = modeToModalMap[currentMode];

  if (!modalId) {
    console.warn("該当するモーダルがありません:", currentMode);
    return;
  }

  const modalElement = document.getElementById(modalId);

  if (!modalElement) {
    console.warn("モーダル要素が見つかりません:", modalId);
    return;
  }

  const modalInstance = new bootstrap.Modal(modalElement);
  modalInstance.show();
}

document.addEventListener("click", (e) => {
  // クリックされた要素、またはその親要素が指定のクラスを持っているか判定
  const target = e.target.closest(".js-modal");
  if (target) {
    openModalByMode();
  }
});

/******************************************
 * シーンのプリセット追加
 * 2026/09
 ******************************************/
//ホーム画面｜カスタムドロップダウンの初期化
function renderHomeScreen() {
  renderCostumeDropdown();
  initCustomDropdown();
  renderStatusStoppedEl();
  renderDriveOnOffButton();
  renderThermalImageOnOff();
  renderWindControlOverlayOnOff();
  renderDriveModeSwitchBtnAndSettingPanelOperation();
  renderAirSettingDisplayForPerfationMode();
}

// function renderHomeScreen() {
//   renderCostumeDropdown();
//   initCustomDropdown();
// }

// シーン設定画面
function renderSceneSettingsScreen() {
  createPresetSceneCards();
}

/******************************************
 * クリックイベント
 ******************************************/
// ホーム画面｜シーンプリセットボタンをクリックしたときの処理
document.addEventListener("click", (e) => {
  const scenePresetBtn = e.target.closest(".js-scene-preset-01-btn");
  if (scenePresetBtn) {
    showModal("modalConfirmRunPresetScene");
  }
});

// スケジュール画面｜運転ボタン（運転・停止）｜下部セクションの活性⇔非活性
document.addEventListener("click", (e) => {
  const driveModeBtn = e.target.closest(".js-drive-switch");
  if (!driveModeBtn) return;
  const driveMode = driveModeBtn.dataset.appScheduleDrive;
  const modeSection = document.querySelector('#modeSection');
  const tempSection = document.querySelector('#btnScheduleSetValue');
  const windSection = document.querySelector('#windSection');
  if (driveMode === 'true') {
    modeSection.classList.remove('pe-none', 'opacity-25')
    tempSection.classList.remove('pe-none', 'opacity-25')
    windSection.classList.remove('pe-none', 'opacity-25')
  } else {
    modeSection.classList.add('pe-none', 'opacity-25')
    tempSection.classList.add('pe-none', 'opacity-25')
    windSection.classList.add('pe-none', 'opacity-25')
  }
});


/******************************************
 * ハンドリング
 ******************************************/
// ホーム画面｜カスタムドロップダウンの初期化
function initCustomDropdown() {
  const scenePresetToggle = document.getElementById("scenePresetToggle");
  const backdrop = document.querySelector(".scene-preset-backdrop");
  const presetSceneBtn = document.querySelector(".js-preset-scene-btn");

  scenePresetToggle.addEventListener("shown.bs.dropdown", () => {
    presetSceneBtn.src = "../assets/img/icon-preset-close.svg";
    backdrop.classList.remove("d-none");
  });

  scenePresetToggle.addEventListener("hidden.bs.dropdown", () => {
    presetSceneBtn.src = "../assets/img/icon-preset.svg";
    backdrop.classList.add("d-none");
  });

  backdrop.addEventListener("click", () => {
    const dropdown = bootstrap.Dropdown.getOrCreateInstance(scenePresetToggle);
    presetSceneBtn.src = "../assets/img/icon-preset.svg";
    dropdown.hide();
  });
}

/******************************************
 * マスターデータ
 ******************************************/
// プリセットシーンのマスターデータ
const MASTER_PRESET_SCENE = {
  "presetScene01": {
    "name": "夏のペット思いモード",
    "icon": "../assets/img/icon-preset-pet.svg",
    "mode": "冷房",
    "temp": "28℃",
  },
  "presetScene02": {
    "name": "冬のペット思いモード",
    "icon": "../assets/img/icon-preset-pet.svg",
    "mode": "暖房",
    "temp": "20℃",
  },
  "presetScene03": {
    "name": "夏のお風呂上り",
    "icon": "../assets/img/99_scene_after_summer_bath.svg",
    "mode": "冷房",
    "temp": "25℃",
  },
  "presetScene04": {
    "name": "就寝",
    "icon": "../assets/img/13_scene_sleep.svg",
    "mode": "停止",
  },

}

// シーン設定画面｜プリセットシーンカードを生成する
function createPresetSceneCards() {
  const template = document.getElementById("presetSceneCardsTemplate");
  const container = document.getElementById("presetSceneCardsContainer");
  if (!template || !container) return;

  // コンテナを初期化
  container.innerHTML = "";

  const sceneEntries = Object.entries(MASTER_PRESET_SCENE || {});
  if (!sceneEntries.length) return;

  sceneEntries.forEach(([sceneKey, scene]) => {
    const clone = template.content.cloneNode(true);
    const button = clone.querySelector(".js-preset-scene-btn");
    if (!button) return;

    button.dataset.sceneKey = sceneKey;

    const sceneName = clone.querySelector(".scene-name");
    const sceneIcon = clone.querySelector(".scene-icon");
    const sceneMode = clone.querySelector(".scene-mode");
    const sceneTemp = clone.querySelector(".scene-temp");

    if (sceneName) sceneName.textContent = scene?.name || "";
    if (sceneIcon) sceneIcon.src = scene?.icon || "";
    if (sceneIcon) sceneIcon.alt = scene?.name || "";
    if (sceneMode) sceneMode.textContent = scene?.mode || "";
    if (sceneTemp) sceneTemp.textContent = scene?.temp || "";

    container.appendChild(clone);
  });
}

// ホーム画面｜プリセットのカスタムドロップのコンテンツ作成
function renderCostumeDropdown() {
  const dropdownMenu = document.querySelector(".dropdown-menu");
  if (!dropdownMenu) return;

  const sceneEntries = Object.entries(MASTER_PRESET_SCENE || {});
  if (!sceneEntries.length) return;

  sceneEntries.forEach(([, scene], index) => {
    const dropdownItem = dropdownMenu.children[index];

    const sceneName = dropdownItem?.querySelector("span.scene-name");
    const sceneIcon = dropdownItem?.querySelector("img.scene-icon");

    if (sceneName) {
      sceneName.textContent = scene.name || "";
    }

    if (sceneIcon) {
      sceneIcon.src = scene.icon || "";
      sceneIcon.alt = scene.name || "";
    }
  });
}

function setHomeScreenForPetSummer() {
  setJsonValue('currentMode', 'cooling');
  setJsonValue('modalDrive.isRunning', true); // 追加
  renderDriveModeSwitchBtnAndSettingPanelOperation();
  renderWindControlOverlayOnOff();
  renderAirSettingDisplayForPerfationMode();
  updateDisplay(); // 温湿度風速設定値ディスプレイ更新
  document.querySelector('#tempInt').textContent = getJsonValue('driveModeSelectBtn.ai-auto-cooling.temperature') || '';
}

/******************************************
 * 風向・風速 制御
 ******************************************/
// 状態管理
let windSettingsState = {};
let windSettingsDraft = {};
windSettingsState = getJsonValue('windSettingsState') || {};

// 操作設定画面｜レンダリング｜風向・風速のアイコン
function renderWindSettingsBtnIcons() {
  const speed = windSettingsState.speed
  const verticalLeft = windSettingsState.verticalLeft
  const verticalRight = windSettingsState.verticalRight
  const horizontal = windSettingsState.horizontal
  const speedIcon = document.querySelector(".js-speed-icon");
  const verticalLeftIcon = document.querySelector(".js-vertical-left-icos");
  const verticalRightIcon = document.querySelector(".js-vertical-right-icos");
  const horizontalIcon = document.querySelector(".js-horizontal-icon");
  const speedIcos = {
    quiet: 'icon_quiet.svg',
    low: 'icon_low.svg',
    medium: 'icon_medium.svg',
    high: 'icon_high.svg',
    long: 'icon_long.svg',
    auto: 'icon_auto.svg',
  }
  const verticalLeftIcos = {
    leftUp: 'icon_leftUp.svg',
    leftSlightlyUp: 'icon_leftSlightlyUp.svg',
    leftCenter: 'icon_leftCenter.svg',
    leftSlightlyDown: 'icon_leftSlightlyDown.svg',
    leftDown: 'icon_leftDown.svg',
    leftSwing: 'icon_leftSwing.svg',
    leftAuto: 'icon_leftAuto.svg',
  }
  const verticalRightIcos = {
    rightUp: 'icon_rightUp.svg',
    rightSlightlyUp: 'icon_rightSlightlyUp.svg',
    rightCenter: 'icon_rightCenter.svg',
    rightSlightlyDown: 'icon_rightSlightlyDown.svg',
    rightDown: 'icon_rightDown.svg',
    rightSwing: 'icon_rightSwing.svg',
    rightAuto: 'icon_rightAuto.svg',
  }
  const horizontalIcos = {
    1: 'icon_01.svg',
    2: 'icon_02.svg',
    3: 'icon_03.svg',
    4: 'icon_04.svg',
    5: 'icon_05.svg',
    6: 'icon_06.svg',
    7: 'icon_07.svg',
    8: 'icon_08.svg',
    9: 'icon_09.svg',
    10: 'icon_10.svg',
    11: 'icon_11.svg',
    12: 'icon_12.svg',
    13: 'icon_13.svg',
  }
  speedIcon.src = `../assets/img/${speedIcos[speed]}`;
  verticalLeftIcon.src = `../assets/img/${verticalLeftIcos[verticalLeft]}`;
  verticalRightIcon.src = `../assets/img/${verticalRightIcos[verticalRight]}`;
  horizontalIcon.src = `../assets/img/${horizontalIcos[horizontal]}`;
}

// 風速・左右風向モーダル｜初期化｜使用例 initWindSettingsState('speed')
function initWindSettingsState(btnGroupId) {
  // ボタン部
  document.querySelectorAll(`#${btnGroupId} .btn`).forEach((btn) => {
    btn.setAttribute("fill", "white");
    btn.setAttribute("stroke", "#4C6EE8");
  });
  // ラベル部
  document.querySelectorAll(`#${btnGroupId} .label`).forEach((label) => {
    label.setAttribute("fill", "#4C6EE8");
  });
  // マーク部（左・右それぞれのグループだけを初期化）
  const markIds = btnGroupId === 'verticalLeft'
    ? ['leftAutoMark', 'leftSwingMark']
    : btnGroupId === 'verticalRight'
      ? ['rightAutoMark', 'rightSwingMark']
      : [];

  markIds.forEach((markId) => {
    document.querySelector(`#${markId}`).style.display = 'none';
  });
};

// 風速・左右風向モーダル｜レンダリング｜使用例 renderWindSettingsBtn(windSettingsState.speed)
function renderWindSettingsBtn(btnId) {
  const targetElement = document.querySelector(`#${btnId}`);
  const btn = targetElement.querySelector('.btn');
  const labels = targetElement.querySelectorAll('.label');
  btn.setAttribute('fill', '#4C6EE8');
  btn.setAttribute('stroke', 'none');
  labels.forEach(label => {
    label.setAttribute('fill', '#FFFFFF');
  });

  if(btnId.includes("Swing")){
    document.querySelector(`#${btnId}Mark`).style.display = 'block';
  }
  if(btnId.includes("Auto")){
    document.querySelector(`#${btnId}Mark`).style.display = 'block';
  }
}

// 左右風向モーダル｜レンダリング
function renderWindHorizontalModal() {
  // windSettingsDraft = { ...windSettingsState };
  document.querySelectorAll('[data-wind-value]').forEach(cell => {
    const direction = Number(cell.dataset.windValue);
    const img = cell.querySelector('img');
    if (!img) return;
    const suffix =
      direction === windSettingsDraft.horizontal
        ? '_on.svg'
        : '_off.svg';
    img.src = img.src.replace(/_(on|off)\.svg$/, suffix);
  });
}

// 風速モーダル｜クリックイベント｜風速
document.addEventListener("click", (e) => {
  const windspeedBtn = e.target.closest(".js-windspeed-btn");
  if (!windspeedBtn) return;
  initWindSettingsState('speed');
  windSettingsDraft.speed = windspeedBtn.dataset.windValue;
  renderWindSettingsBtn(windSettingsDraft.speed);
  renderWindSettingsBtnIcons()
});

// 風向モーダル｜クリックイベント｜上下風向 左
document.addEventListener("click", (e) => {
  const windDirectionUpDownBtn = e.target.closest(".js-left-winddirection-ud-btn");
  if (!windDirectionUpDownBtn) return;
  initWindSettingsState('verticalLeft');
  windSettingsDraft.verticalLeft = windDirectionUpDownBtn.dataset.windValue;
  renderWindSettingsBtn(windSettingsDraft.verticalLeft);
  renderWindSettingsBtnIcons()
});

// 風向モーダル｜クリックイベント｜上下風向 右
document.addEventListener("click", (e) => {
  const windDirectionUpDownBtn = e.target.closest(".js-right-winddirection-ud-btn");
  if (!windDirectionUpDownBtn) return;
  initWindSettingsState('verticalRight');
  windSettingsDraft.verticalRight = windDirectionUpDownBtn.dataset.windValue;
  renderWindSettingsBtn(windSettingsDraft.verticalRight);
  renderWindSettingsBtnIcons()
});

// 風向モーダル｜クリックイベント｜左右風向
document.addEventListener("click", (e) => {
  const windDirectionLeftRightBtn = e.target.closest(".wind-setting-cell");
  if (!windDirectionLeftRightBtn) return;
  windSettingsDraft.horizontal = Number(windDirectionLeftRightBtn.dataset.windValue);
  renderWindHorizontalModal();
  renderWindSettingsBtnIcons()
});

// スケジュール画面｜クリックイベント｜風向・風速設定のトグル
document.addEventListener("change", (e) => {
  const windSettingsToggle = e.target.closest(".form-switch");
  if (!windSettingsToggle) return;
  // 風設定のトグルスイッチが変更されたときの処理
  if (e.target.checked) {
    // オン（Checked）のときの処理
      setJsonValue('windSettingsState.settings', true);
    // オフのときの処理
    } else {
      setJsonValue('windSettingsState.settings', false);
    }  
    renderWindSection();
});

// トグルボタンのオン／オフからセクションの表示制御
function renderWindSection() {
  const toggleState = getJsonValue('windSettingsState.settings');
  const windSection = document.getElementById('windSection');
  const speedElm = document.getElementById('speedElm');
  const verticalElm = document.getElementById('verticalElm');
  const horizontalElm = document.getElementById('horizontalElm');
  if (toggleState === null) return;

  if (toggleState) {
      // オン（Checked）のときの処理
      renderWindSettingsBtnIcons();
      document.querySelector(".js-app-wind-toggle").checked = true;
      speedElm.classList.toggle('d-none', false);
      verticalElm.classList.toggle('d-none', false);
      horizontalElm.classList.toggle('d-none', false);
      windSection.querySelectorAll('button').forEach(button => {
        button.disabled = false;
      });
    } else {
      renderWindSettingsBtnIcons();
      document.querySelector(".js-app-wind-toggle").checked = false;
      speedElm.classList.toggle('d-none', true);
      verticalElm.classList.toggle('d-none', true);
      horizontalElm.classList.toggle('d-none', true);
      windSection.querySelectorAll('button').forEach(button => {
        button.disabled = true;
      });
    }  
}

/******************************************
 * クリックイベント（風向・風速）
 ******************************************/
// document.addEventListener("click", (e) => {
//   const el = e.target;

// 操作設定画面｜風速｜モーダル表示
// const windSpeedBtn = el.closest(".js-wind-speed-btn");
// if (windSpeedBtn) {
//   windSettingsDraft = { ...windSettingsState };
//   renderWindSettingsBtn(windSettingsDraft.speed);
//   showModal("setWindspeedModal");
// }

// 操作設定画面｜上下風向｜モーダル表示
// const windDrectionUdBtn = el.closest(".js-wind-direction-ud-btn");
// if (windDrectionUdBtn) {
//   windSettingsDraft = { ...windSettingsState };
//   renderWindSettingsBtn(windSettingsDraft.verticalLeft);
//   renderWindSettingsBtn(windSettingsDraft.verticalRight);
//   showModal("setWindDirectionUdModal");
// }

// 操作設定画面｜左右風向｜モーダル表示
// const windDrectionLrBtn = el.closest(".js-wind-direction-lr-btn");
// if (windDrectionLrBtn) {
//   windSettingsDraft = { ...windSettingsState };
//   renderWindHorizontalModal();
//   showModal("setWindDirectionLrModal");
// }

// ↑ クリックイベント
// })

// windSettingsDraftのデータをwindSettingsStateへ反映させる関数
function applyWindSettingsDraft() {
  windSettingsState = { ...windSettingsDraft };
  renderWindSettingsBtnIcons();
}

function setPetSummerMode() {
  const isPetSummerMode = getJsonValue('isPetSummerMode');
  setJsonValue('isPetSummerMode', !isPetSummerMode);
  currentTemp = getJsonValue('isPetSummerMode') ? 28.0 : 23.0;
  updateDisplay();
  renderHomeScreen();
}


function showLeftRightModal() {
  const mode = getJsonValue('currentMode');
  if (mode !== 'perflation') {
    showModal("selectWinddirectionLeftRight");
  } else {
    showModal("selectWinddirectionLeftRightDisabled");
  }
}
