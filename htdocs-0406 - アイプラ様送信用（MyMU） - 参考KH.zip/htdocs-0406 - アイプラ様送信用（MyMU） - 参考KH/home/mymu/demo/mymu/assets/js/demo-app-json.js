const initiAppData = {
  cardOnStatus: ["rac-1", "rac-2", "eq"], // (card1 | card2 | card3) card4なし
  currentPage: "mymu", // (mymu | automation | mymuPlus | notice)
  currentTriggerEvent: "schedule", // (schedule | location | devices)
  currentScene: null, // (allOff | sleep | returnWinter)
  entryId: "auto-1", // オートメーションID（新規作成時は"new"）
  entryDeviceCard: null, // 機器の状態を追加（trigger）／機器の操作を追加（action）
  isAutoMationSetDone: false, // オートメーション機能　有効/無効　(true　|　false)
  // 登録済み-1
  "auto-1": {
    status: true,
    entryDeviceCard: null, // 機器の状態を追加（trigger）／機器の操作を追加（action）
    entryTrigger: "schedule",
    name: "冬の帰宅", // オートメーション名
    triggers: {
      schedule: {
        time: "18:00",
        days: ["mon", "tue", "wed", "thu", "fri"],
      },
    },
    actions: [
      {
        actionId: "3bbd243dc2",
        type: "devices",
        id: "rac-1",
        drive: "on",
        mode: "暖房",
        temp: "20.0",
      },
      {
        actionId: "338ee58f80",
        type: "devices",
        id: "eq",
        name: "給湯機1",
        drive: "on",
      },
    ],
  },
  // 登録済み-2
  "auto-2": {
    status: true,
    entryDeviceCard: null, // 機器の状態を追加（trigger）／機器の操作を追加（action）
    entryTrigger: "schedule",
    name: "夏の帰宅", // オートメーション名
    triggers: {
      schedule: {
        time: "19:00",
        days: ["mon", "wed", "fri"],
      },
    },
    actions: [
      {
        actionId: "ab77559c95",
        type: "devices",
        id: "rac-1",
        drive: "on",
        mode: "冷房",
        temp: "27.0",
      },
    ],
  },

  // 登録済み-3
  "auto-3": {
    status: true,
    entryDeviceCard: null, // 機器の状態を追加（trigger）／機器の操作を追加（action）
    entryTrigger: "devices",
    name: "高温おしらせ", // オートメーション名
    triggers: {
      devices: {
        id: "rac-1",
        name: "リビングのエアコン",
        condition: "室温がしきい値を超えたとき",
        threshold: 27,
      },
    },
    actions: [
      {
        actionId: "9e29149ae8",
        type: "devices",
        id: "rac-1",
        drive: "on",
        mode: "冷房",
        temp: "27.0",
      },
      {
        actionId: "02e81f744d",
        type: "notify",
        id: "notify-1",
        users: ["お母さん"],
      },
    ],
  },

  // 提案-1
  "temp-1": {
    status: true,
    entryDeviceCard: null, // 機器の状態を追加（trigger）／機器の操作を追加（action）
    entryTrigger: "devices",
    name: "高温おしらせ", // オートメーション名
    triggers: {
      devices: {
        id: "rac-1",
        name: "リビングのエアコン",
        condition: "室温がしきい値を超えたとき",
        threshold: "28.0",
      },
    },
    actions: [
      {
        actionId: "eb094c3eb4",
        type: "notify",
        id: "notify-1",
        users: ["お母さん"],
      },
    ],
  },
  // 提案-2
  "temp-2": {
    status: true,
    entryDeviceCard: null, // 機器の状態を追加（trigger）／機器の操作を追加（action）
    entryTrigger: "devices",
    name: "低温おしらせ", // オートメーション名
    triggers: {
      devices: {
        id: "rac-1",
        name: "リビングのエアコン",
        condition: "室温がしきい値を下回ったとき",
        threshold: "15.0",
      },
    },
    actions: [
      {
        actionId: "4460a97b89",
        type: "notify",
        id: "notify-1",
        users: ["お母さん"],
      },
    ],
  },

  // 提案-3
  "temp-3": {
    status: true,
    entryDeviceCard: null, // 機器の状態を追加（trigger）／機器の操作を追加（action）
    entryTrigger: "location",
    name: "おかえりON", // オートメーション名
    triggers: {
      location: {
        users: ["お父さん", "お母さん", "たかし", "あいこ"], //
        event: "close", // 自宅に近づいたとき/離れたとき
      },
    },
    actions: [
      {
        actionId: "a6b2be4ea2",
        type: "devices",
        id: "rac-1",
        drive: "on",
        mode: "冷房",
        temp: "28.0",
        startupTemp: "28.0",
        description: "室温28.0℃以上で冷房28.0℃運転",
      },
    ],
  },

  // 提案-4
  "temp-4": {
    status: true,
    entryDeviceCard: null, // 機器の状態を追加（trigger）／機器の操作を追加（action）
    entryTrigger: "location",
    name: "おでかけOFF", // オートメーション名
    triggers: {
      location: {
        users: ["お父さん", "お母さん", "たかし", "あいこ"], //
        event: "away", // 自宅に近づいたとき/離れたとき
      },
    },
    actions: [
      {
        actionId: "d55c27b94c",
        type: "devices",
        id: "rac-1",
        drive: "off",
      },
    ],
  },

  // 提案-5
  "temp-5": {
    status: true,
    entryDeviceCard: null, // 機器の状態を追加（trigger）／機器の操作を追加（action）
    entryTrigger: "schedule",
    name: "エアコン入タイマー", // オートメーション名
    triggers: {
      schedule: {
        time: "17:00",
        days: [],
      },
    },
    actions: [
      {
        actionId: "7f132b48e0",
        type: "devices",
        id: "rac-1",
        drive: "on",
        mode: "冷房",
        temp: "28.0",
      },
    ],
  },

  // 提案-6
  "temp-6": {
    status: true,
    entryDeviceCard: null, // 機器の状態を追加（trigger）／機器の操作を追加（action）
    entryTrigger: "schedule",
    name: "エアコン切タイマー", // オートメーション名
    triggers: {
      schedule: {
        time: "09:00",
        days: [],
      },
    },
    actions: [
      {
        actionId: "0218e8c8da",
        type: "devices",
        id: "rac-1",
        drive: "off",
      },
    ],
  },

  // 新規
  new: {
    status: false,
    entryDeviceCard: null, // 機器の状態を追加（trigger）／機器の操作を追加（action）
    entryTrigger: "schedule",
    name: "オートメーション", // オートメーション名
    triggers: {
      schedule: {
        time: "12:00",
        days: [],
      },
      location: {
        users: ["お父さん"], //
        event: "",
      },
      devices: {
        id: "",
        name: "",
        condition: "",
        threshold: null,
      },
    },
    actions: [],
  },
  // シーン設定（追加）
  isSceneSetDone: false, // シーン設定完了フラグ (true | false)
  entryScene: null, // proposal / custom
  entryScreen: null, // home / catarog
  entryDevice: null, // rac-1 / rac-2 / eq
  showDeleteButton: false, // シーン削除ボタン表示フラグ (true | false)
  scenes: {
    "customScene-1": {
      name: "カスタムシーン", // シーン名
      icon: "../assets/img/01_scene_home.svg",
      status: false,
      devices: {
        "rac-1": {
          status: false,
          id: "rac-1",
          name: "リビングのエアコン",
          drive: "on",
          mode: "冷房",
          temp: "28.0℃",
          icon: "../assets/img/icon_AC_40pt.svg",
          description: "運転開始 冷房 28.0℃",
        },
        "rac-2": {
          status: false,
          id: "rac-2",
          name: "寝室のエアコン",
          drive: "on",
          mode: "冷房",
          temp: "28.0℃",
          icon: "../assets/img/icon_AC_40pt.svg",
          description: "運転開始 冷房 28.0℃",
        },
        eq: {
          status: false,
          id: "eq",
          name: "給湯機1",
          drive: "on",
          icon: "../assets/img/product_Icon_EQ_40pt.svg",
          description: "ふろ自動開始",
        },
      },
    },
    "proposalScene-1": {
      name: "夏の帰宅",
      icon: "../assets/img/11_scene_gohome_heating.svg",
      status: true,
      devices: {
        "rac-1": {
          status: true,
          id: "rac-1",
          name: "リビングのエアコン",
          drive: "on",
          mode: "冷房",
          temp: "28.0℃",
          icon: "../assets/img/icon_AC_40pt.svg",
          description: "運転開始 冷房 28.0℃",
        },
        "rac-2": {
          status: false,
          id: "rac-2",
          name: "寝室のエアコン",
          drive: "off",
          mode: "冷房",
          temp: "28.0℃",
          icon: "../assets/img/icon_AC_40pt.svg",
          description: "運転開始 冷房 28.0℃",
        },
        eq: {
          status: true,
          id: "eq",
          name: "給湯機1",
          drive: "on",
          icon: "../assets/img/product_Icon_EQ_40pt.svg",
          description: "ふろ自動開始",
        },
      },
    },
    "proposalScene-2": {
      name: "冬の起床",
      icon: "../assets/img/16_scene_getup_cooling.svg",
      status: true,
      devices: {
        "rac-1": {
          status: true,
          id: "rac-1",
          name: "リビングのエアコン",
          drive: "on",
          mode: "暖房",
          temp: "20.0℃",
          icon: "../assets/img/icon_AC_40pt.svg",
          description: "運転開始 暖房 20.0℃",
        },
        "rac-2": {
          status: true,
          id: "rac-2",
          name: "寝室のエアコン",
          drive: "on",
          mode: "暖房",
          temp: "20.0℃",
          icon: "../assets/img/icon_AC_40pt.svg",
          description: "運転開始 暖房 20.0℃",
        },
        eq: {
          status: false,
          id: "eq",
          name: "給湯機1",
          drive: "off",
          icon: "../assets/img/product_Icon_EQ_40pt.svg",
          description: "ふろ自動停止",
        },
      },
    },
    "proposalScene-3": {
      name: "夏のペットモード",
      icon: "../assets/img/05_scene_sunny.svg",
      status: true,
      devices: {
        "rac-1": {
          status: true,
          id: "rac-1",
          name: "リビングのエアコン",
          drive: "on",
          mode: "冷房",
          temp: "28.0℃",
          icon: "../assets/img/icon_AC_40pt.svg",
          description: "運転開始 冷房 28.0℃",
        },
        "rac-2": {
          status: false,
          id: "rac-2",
          name: "寝室のエアコン",
          drive: "off",
          mode: "冷房",
          temp: "28.0℃",
          icon: "../assets/img/icon_AC_40pt.svg",
          description: "運転開始 冷房 28.0℃",
        },
        eq: {
          status: false,
          id: "eq",
          name: "給湯機1",
          drive: "on",
          icon: "../assets/img/product_Icon_EQ_40pt.svg",
          description: "",
        },
      },
    },
    "registeredScene-1": {
      name: "外出一括オフ",
      icon: "../assets/img/04_scene_off.svg",
      status: true,
      devices: {
        "rac-1": {
          status: true,
          id: "rac-1",
          name: "リビングのエアコン",
          drive: "off",
          mode: "冷房",
          temp: "28.0℃",
          icon: "../assets/img/icon_AC_40pt.svg",
          description: "運転停止",
        },
        "rac-2": {
          status: true,
          id: "rac-2",
          name: "寝室のエアコン",
          drive: "off",
          mode: "冷房",
          temp: "28.0℃",
          icon: "../assets/img/icon_AC_40pt.svg",
          description: "運転停止",
        },
        eq: {
          status: true,
          id: "eq",
          name: "給湯機1",
          drive: "off",
          icon: "../assets/img/product_Icon_EQ_40pt.svg",
          description: "ふろ自動停止",
        },
      },
    },
    "registeredScene-2": {
      name: "就寝",
      icon: "../assets/img/13_scene_sleep.svg",
      status: true,
      devices: {
        "rac-1": {
          status: true,
          id: "rac-1",
          name: "リビングのエアコン",
          drive: "off",
          mode: "冷房",
          temp: "28.0℃",
          icon: "../assets/img/icon_AC_40pt.svg",
          description: "運転停止",
        },
        "rac-2": {
          status: false,
          id: "rac-2",
          name: "寝室のエアコン",
          drive: "off",
          mode: "冷房",
          temp: "28.0℃",
          icon: "../assets/img/icon_AC_40pt.svg",
          description: "運転開始 冷房 28.0℃",
        },
        eq: {
          status: true,
          id: "eq",
          name: "給湯機1",
          drive: "off",
          icon: "../assets/img/product_Icon_EQ_40pt.svg",
          description: "ふろ自動停止",
        },
      },
    },
    "registeredScene-3": {
      name: "冬の帰宅",
      icon: "../assets/img/10_scene_gohome.svg",
      status: true,
      devices: {
        "rac-1": {
          status: true,
          id: "rac-1",
          name: "リビングのエアコン",
          drive: "on",
          mode: "暖房",
          temp: "20.0℃",
          icon: "../assets/img/icon_AC_40pt.svg",
          description: "運転開始 暖房 20.0℃",
        },
        "rac-2": {
          status: false,
          id: "rac-2",
          name: "寝室のエアコン",
          drive: "off",
          mode: "冷房",
          temp: "28.0℃",
          icon: "../assets/img/icon_AC_40pt.svg",
          description: "運転開始 冷房 28.0℃",
        },
        eq: {
          status: true,
          id: "eq",
          name: "給湯機1",
          drive: "",
          icon: "../assets/img/product_Icon_EQ_40pt.svg",
          description: "ふろ自動開始",
        },
      },
    },
    "temporaryScene": {
      name: "",
      icon: "",
      status: false,
      devices: {
        "rac-1": {
          status: false,
          id: "rac-1",
          name: "リビングのエアコン",
          drive: "",
          mode: "",
          temp: "",
          icon: "../assets/img/icon_AC_40pt.svg",
          description: "",
        },
        "rac-2": {
          status: false,
          id: "rac-2",
          name: "寝室のエアコン",
          drive: "",
          mode: "",
          temp: "",
          icon: "../assets/img/icon_AC_40pt.svg",
          description: "",
        },
        eq: {
          status: false,
          id: "eq",
          name: "給湯機1",
          drive: "",
          icon: "../assets/img/product_Icon_EQ_40pt.svg",
          description: "",
        },
      },
      
    },
  },
};

const headerSet = {
  home: {
    left: {
      type: "drawer",
    },
    title: "MyMU",
    right: {
      text: '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="9" stroke="black" stroke-width="1.5"/><circle cx="10" cy="8" r="3" fill="black"/><path fill-rule="evenodd" clip-rule="evenodd" d="M5 17C5 14.2386 7.23858 12 10 12C12.7614 12 15 14.2386 15 17V17.3846L12.5 18.4615L10 19C10 19 8.45714 18.7708 7.5 18.4615C6.54286 18.1523 5 17.3846 5 17.3846V17Z" fill="black"/></svg>',
      visible: true,
      action: "mymu",
    },
  },
  automation: {
    left: {
      type: "drawer",
    },
    title: "MyMU",
    right: {
      text: '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="9" stroke="black" stroke-width="1.5"/><circle cx="10" cy="8" r="3" fill="black"/><path fill-rule="evenodd" clip-rule="evenodd" d="M5 17C5 14.2386 7.23858 12 10 12C12.7614 12 15 14.2386 15 17V17.3846L12.5 18.4615L10 19C10 19 8.45714 18.7708 7.5 18.4615C6.54286 18.1523 5 17.3846 5 17.3846V17Z" fill="black"/></svg>',
      visible: true,
      action: "mymu",
    },
  },
  proposalAutomation: {
    left: {
      type: "back",
    },
    title: "新規オートメーション",
    right: {
      visible: false,
    },
  },
  deviceSettingsEq: {
    left: {
      type: "back",
    },
    title: "操作設定",
    right: {
      text: "完了",
      visible: true,
    },
  },
  applianceSelection: {
    left: {
      type: "back",
    },
    title: "機器を選択",
    right: {
      visible: false,
    },
  },
  customAutomation: {
    left: {
      type: "back",
    },
    title: "新規オートメーション",
    right: {
      visible: false,
    },
  },
  selectScene: {
    left: {
      type: "back",
    },
    title: "シーンを選択",
    right: {
      visible: false,
    },
  },
  editAutomation: {
    left: {
      type: "backToAutomation",
    },
    title: "オートメーション編集",
    right: {
      text: "完了",
      visible: true,
      action: "editAutomation",
    },
  },
  selectDeviceOperation: {
    left: {
      type: "back",
    },
    title: "機器の状態を選択",
    right: {
      visible: false,
    },
  },
  setupScene: {
    left: {
      type: "back",
    },
    title: "シーン設定",
    right: {
      text: "完了",
      visible: true,
    },
  },
  selectRoomTemperatureStatusOver: {
    left: {
      type: "back",
    },
    title: "室温がしきい値を超えたとき",
    right: {
      text: "完了",
      visible: true,
    },
  },
  selectRoomTemperatureStatusUnder: {
    left: {
      type: "back",
    },
    title: "室温がしきい値を下回ったとき",
    right: {
      text: "完了",
      visible: true,
    },
  },
  homeLocationSettings: {
    left: {
      type: "back",
    },
    title: "自宅位置設定",
    right: {
      text: "完了",
      visible: true,
    },
  },
  selectDevice: {
    left: {
      type: "back",
    },
    title: "機器を選択",
    right: {
      visible: false,
    },
  },
  selectNotice: {
    left: {
      type: "back",
    },
    title: "通知設定を選択",
    right: {
      text: "完了",
      visible: true,
    },
  },
  sceneSettings: {
    left: {
      type: "back",
    },
    title: "シーン設定",
    right: {
      text: "完了",
      visible: true,
    },
  },
  selectDeviceOperation: {
    left: {
      type: "back",
    },
    title: "機器の状態を選択",
    right: {
      visible: false,
    },
  },
  deviceSettingsRac: {
    left: {
      type: "back",
    },
    title: "操作設定",
    right: {
      text: "完了",
      visible: true,
    },
  },
  selectIcon: {
    left: {
      type: "back",
    },
    title: "アイコン選択",
    right: {
      visible: false,
    },
  },
  editScene: {
    left: {
      type: "goToSelectSceneToEdit",
    },
    title: "シーン編集",
    right: {
      text: "完了",
      visible: true,
    },
  },
  editSceneNew: {
    left: {
      type: "goToSelectSceneToEdit",
    },
    title: "新規シーン",
    right: {
      text: "完了",
      visible: true,
    },
  },
  createProposalScene: {
    left: {
      type: "back",
    },
    title: "シーン作成",
    right: {
      visible: false,
    },
  },
  sceneCatalog: {
    left: {
      type: "back",
    },
    title: "シーン作成",
    right: {
      visible: false,
    },
  },
  selectSceneToEdit: {
    left: {
      type: "back",
    },
    title: "シーン編集",
    right: {
      visible: false,
    },
  },
  selectDeviceScene: {
    left: {
      type: "back",
    },
    title: "操作設定",
    right: {
      visible: false,
    },
  },
  deviceSettingsRacScene: {
    left: {
      type: "back",
    },
    title: "操作設定",
    right: {
      text: "完了",
      visible: true,
      action: "updateJsonData",
    },
  },
  deviceSettingsEqScene: {
    left: {
      type: "back",
    },
    title: "操作設定",
    right: {
      text: "完了",
      visible: true,
      action: "updateJsonData",
    },
  },
  deviceSettingsRacScene: {
    left: {
      type: "back",
    },
    title: "操作設定",
    right: {
      text: "完了",
      visible: true,
      action: "updateJsonData",
    },
  },
};

// セッションストレージに展開
function storeJsonData() {
  try {
    sessionStorage.setItem("appData", JSON.stringify(initiAppData));
    sessionStorage.setItem("appDataEdit", JSON.stringify(initiAppData));
    sessionStorage.setItem("headerSet", JSON.stringify(headerSet));
  } catch (error) {
    showAlert("JSONデータの保存に失敗しました。", "error");
  }
}
