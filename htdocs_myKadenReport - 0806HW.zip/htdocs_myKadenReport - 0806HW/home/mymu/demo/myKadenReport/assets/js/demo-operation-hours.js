const operationData = [
  // 2025年
  { year: 2025, month: 1, days: 31, hours: 206 },
  { year: 2025, month: 2, days: 28, hours: 219 },
  { year: 2025, month: 3, days: 31, hours: 174 },
  { year: 2025, month: 4, days: 30, hours: 32 },
  { year: 2025, month: 5, days: 31, hours: 63 },
  { year: 2025, month: 6, days: 30, hours: 186 },
  { year: 2025, month: 7, days: 31, hours: 228 },
  { year: 2025, month: 8, days: 31, hours: 218 },
  { year: 2025, month: 9, days: 30, hours: 121 },
  { year: 2025, month: 10, days: 31, hours: 35 },
  { year: 2025, month: 11, days: 30, hours: 161 },
  { year: 2025, month: 12, days: 31, hours: 195 },
  // 2026年
  { year: 2026, month: 1, days: 31, hours: 206 },
  { year: 2026, month: 2, days: 28, hours: 219 },
  { year: 2026, month: 3, days: 31, hours: 174 },
  { year: 2026, month: 4, days: 30, hours: 32 },
  { year: 2026, month: 5, days: 31, hours: 63 },
  { year: 2026, month: 6, days: 30, hours: 186 },
  { year: 2026, month: 7, days: 31, hours: 228 },
  { year: 2026, month: 8, days: 31, hours: 218 },
  { year: 2026, month: 9, days: 30, hours: 121 },
  { year: 2026, month: 10, days: 31, hours: 35 },
  { year: 2026, month: 11, days: 30, hours: 161 },
  { year: 2026, month: 12, days: 31, hours: 195 },
  // 2027年
  { year: 2027, month: 1, days: 31, hours: 239 },
  { year: 2027, month: 2, days: 28, hours: 228 },
  { year: 2027, month: 3, days: 31, hours: 179 },
  { year: 2027, month: 4, days: 30, hours: 31 },
  { year: 2027, month: 5, days: 31, hours: 43 },
  { year: 2027, month: 6, days: 30, hours: 230 },
  { year: 2027, month: 7, days: 31, hours: 249 },
  { year: 2027, month: 8, days: 31, hours: 239 },
  { year: 2027, month: 9, days: 30, hours: 39 }
];

// 累計運転時間を求める関数

/**
 * 2025/1/1から指定日までの累積運転時間を取得
 * ※指定日は含めない
 *
 * @param {Date} targetDate
 * @returns {number}
 */
function getOperationHours(targetDate) {

    const baseYear = 2025;
    const baseMonth = 1;

    const year = targetDate.getFullYear();
    const month = targetDate.getMonth() + 1;
    const day = targetDate.getDate();

    const monthIndex = (year - baseYear) * 12 + (month - baseMonth);

    // データ範囲チェック
    if (monthIndex < 0) {
        throw new Error("指定日は2025年1月1日以降を指定してください。");
    }

    if (monthIndex > operationData.length) {
        throw new Error("指定日はoperationDataの範囲外です。");
    }

    let total = 0;

    // 前月まで合計
    for (let i = 0; i < Math.min(monthIndex, operationData.length); i++) {
        total += operationData[i].hours;
    }

    // 最終月の翌月1日以外は日割り計算
    if (monthIndex < operationData.length) {
        const current = operationData[monthIndex];
        total += current.hours * ((day - 1) / current.days);
    }

    return total;
}


/**
 * 指定期間の累積運転時間を取得
 * ※開始日は含む
 * ※終了日は含まない
 *
 * 例）
 * 2026/9/1～2027/9/30
 * start = new Date(2026,8,1)
 * end   = new Date(2027,9,1)
 *
 * @param {Date} startDate
 * @param {Date} endDate
 * @returns {number}
 */


function getOperationHoursBetween(startDate, endDate) {

    if (!(startDate instanceof Date) || isNaN(startDate)) {
        throw new Error("startDateが不正です。");
    }

    if (!(endDate instanceof Date) || isNaN(endDate)) {
        throw new Error("endDateが不正です。");
    }

    if (startDate > endDate) {
        throw new Error("開始日は終了日以前を指定してください。");
    }

    return getOperationHours(endDate) - getOperationHours(startDate);
}// 使用例
// const target = new Date(2027, 8, 9); // 2027/9/9（※月は0始まり）
const start = new Date(2026, 8, 1);
const end = new Date(2027, 9, 1);

const hours = getOperationHoursBetween(start, end);

console.log(hours);    // 1989