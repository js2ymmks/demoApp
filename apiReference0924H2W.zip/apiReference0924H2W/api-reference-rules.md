# APIリファレンス作成ルール

このファイルは、`api.yaml` を編集・ビルドするときに確認するルールをまとめたものです。

## 1. 基本構造

OpenAPI 2.0 の基本構造は次の順序にします。

```yaml
swagger: "2.0"
info:
  title: APIタイトル
  version: 1.0.0
host: example.com
basePath: /mymeApi
schemes:
  - https
tags:
  - name: タグ名
paths:
  /path:
    get:
      summary: API概要
```

新しく全体を作る場合、`swagger`、`info`、`host`、`basePath`、`schemes`、`tags`、`paths` は必要に応じて残します。既存の API 定義だけを削除する場合は、`paths:` を残し、その配下を空にします。

## 2. `paths` のインデント

`paths:` 配下の URL は2スペース、HTTPメソッドはURLからさらに2スペース下げます。

```yaml
paths:
  /v1/users:
    get:
      summary: ユーザー情報取得
```

次の形式は誤りです。

```yaml
paths:
/v1/users:
```

インデントが崩れると、URLが `paths` の配下として認識されず、API が表示されない、または YAML の構造エラーになります。

## 3. YAML の重複キー

同じオブジェクト内で、`post`、`tags`、`responses` などのキーを二重に定義しません。

```yaml
/if/COM_VW03:
  post:
    tags:
      - プレゼンテーション
```

同じ `post:` ブロックを途中から再度貼り付けると、`duplicated mapping key` エラーになります。エラー行は重複したキーの位置を示すことが多いため、直前に同じキーがないか確認します。

## 4. 説明文の箇条書き

`description: |` の本文は YAML の値です。箇条書きにする場合は、本文のインデントをそろえ、項目の先頭に `-` を付けます。

```yaml
description: |
  ダイアログ表示内容
  - title: 【required】タイトル
  - currentValue[]: 初期表示ナンバー
  - displayedValue[]: 選択値リスト
    - unit: 項目タイトル
    - selectValue: 選択項目
```

項目名と説明の区切りには、原則として `:` を使います。

## 5. `COM_VW03` の扱い

`COM_VW03` は次の2つの情報として表示されます。

- `operationId: COM_VW03`: Redoc の API 識別子
- `/internal/COM_VW03`: API のパス

`operationId` が設定されている API は、Redoc のサイドバーに `COM_VW03` として表示されます。これは、その API だけが生成されたという意味ではありません。

他の API が表示されないように見える場合は、次を確認します。

1. Redoc のタグを展開する
2. URL に残っている `#tag/.../COM_VW03` を削除する
3. ブラウザをキャッシュ無視で再読み込みする
4. 生成元と表示先が同じファイルか確認する

## 6. スキーマ参照

存在しない定義への `$ref` は使いません。

```yaml
$ref: "#/definitions/ShowPickerPopupRequest"
```

この参照を使う場合は、OpenAPI 2.0 のトップレベルに対応する定義が必要です。

```yaml
definitions:
  ShowPickerPopupRequest:
    type: object
```

定義を用意しない場合は、対象箇所に直接スキーマを記述します。

```yaml
schema:
  type: object
```

## 7. 認証なし API

認証なしの API は、必要に応じて操作単位に次を設定します。

```yaml
security: []
```

認証ありの API では、ヘッダーの説明だけでなく、必要な認証定義との整合性も確認します。

## 8. ビルド確認

`api.yaml` の編集後は、次のコマンドで確認します。

```bash
npx redocly lint api.yaml
npx redocly build-docs api.yaml --output=index.html
```

`lint` の警告とエラーを区別します。`duplicated mapping key`、`paths expected an object`、`Can't resolve $ref` などのエラーは修正が必要です。タグ説明やライセンス不足などの警告は、ビルドを止めない場合があります。

## 9. 編集時の手順

1. エラー行の前後を確認する
2. YAML のインデントと重複キーを確認する
3. `$ref` の参照先を確認する
4. 必要最小限の範囲を修正する
5. `npx redocly lint api.yaml` を実行する
6. `npx redocly build-docs api.yaml --output=index.html` を実行する
7. ブラウザで生成された HTML を再読み込みする

## 10. 現在のファイルに関する注意

現在の `api.yaml` には、公開 API と内部 API の両方が `paths` 配下に定義されています。

- `/v1/...`: クラウド API
- `/v2/...`: バージョン違いのクラウド API
- `/internal/...`: アプリ内部 API

Redoc ではタグ単位で API が折りたたまれるため、表示されないように見えても、生成 HTML に定義が含まれているかを先に確認します。

## 11. CSV項目の転記ルール

CSVの項目は、Swagger 2.0 の標準フィールドと独自拡張フィールドに分けて転記します。

| CSV項目           | Swagger 2.0 の転記先                                  | 種別        | 備考                                                 |
| ----------------- | ----------------------------------------------------- | ----------- | ---------------------------------------------------- |
| 定義              | `paths` のパス、または `operationId`                  | 標準        | 例: `/internal/COM_VW03`、`COM_VW03`                 |
| 名称              | `summary`                                             | 標準        | APIの短い名称                                        |
| 機能              | `description`                                         | 標準        | APIの機能説明                                        |
| 引数.パラメータ型 | `schema.type` または `schema.properties.<name>.type`  | 標準        | `string`、`number`、`object` など                    |
| 引数.パラメータ名 | `parameters[].name` または `schema.properties` のキー | 標準        | bodyの場合は `properties` 配下                       |
| 引数.[I/O]        | `x-io`                                                | 拡張        | `I` は入力、`O` は出力                               |
| 引数.意味・範囲   | `description`、`enum`、`minimum`、`maximum` など      | 標準        | 表現できる内容は標準フィールドへ分解                 |
| 戻り値            | `responses`、`schema`                                 | 標準        | HTTPレスポンスとして定義                             |
| 制約/注意事項     | `x-constraints` または `description`                  | 拡張 / 標準 | 標準フィールドで表現できる制約は標準フィールドへ設定 |
| 詳細仕様          | `x-details` または `description`                      | 拡張 / 標準 | Redocに説明として表示する場合は `description` が適切 |

## 12. 標準フィールドと拡張フィールド

「標準フィールドと独自仕様を混在させない」とは、同じ YAML に両方を書かないという意味ではありません。役割を明確に分けて、同じ API 定義内に並べて記述します。

Swagger 2.0 に存在する情報は、標準フィールドへ設定します。

```yaml
summary: ピッカーダイアログ表示
description: ピッカーを表示する
schema:
  type: number
  enum:
    - 1
    - 2
```

Swagger 2.0 に存在しない独自情報は、`x-` で始まるベンダー拡張へ設定します。

```yaml
x-io: I
x-constraints:
  - 分・秒は2桁で設定する
x-details: 画面仕様書を参照
```

`[I/O]` をそのまま YAML のキーにはしません。

```yaml
# 推奨
x-io: I

# 非推奨
[I/O]: I
```

## 13. CSV項目からの転記例

CSVの内容が次のような場合を例とします。

| 項目              | 内容                   |
| ----------------- | ---------------------- |
| 定義              | `COM_VW03`             |
| 名称              | ピッカーダイアログ表示 |
| 機能              | ピッカーを表示する     |
| 引数.パラメータ型 | `number`               |
| 引数.パラメータ名 | `datatype`             |
| 引数.[I/O]        | `I`                    |
| 引数.意味・範囲   | `1: 時間、2: その他`   |
| 戻り値            | 選択番号               |
| 制約/注意事項     | 分・秒は2桁            |
| 詳細仕様          | 画面仕様書を参照       |

Swagger 2.0 では次のように転記します。

```yaml
/internal/COM_VW03:
  post:
    operationId: COM_VW03
    summary: ピッカーダイアログ表示
    description: ピッカーを表示する

    parameters:
      - in: body
        name: request
        required: true
        schema:
          type: object
          properties:
            datatype:
              type: number
              description: |
                ピッカータイプ
                - 1: 時間
                - 2: その他
              enum:
                - 1
                - 2
              x-io: I

    responses:
      "200":
        description: 選択結果
        schema:
          type: number

    x-constraints:
      - 分・秒は2桁で設定する

    x-details: 画面仕様書を参照
```

## 14. 転記時の判断基準

- 標準仕様で表現できる情報は、Swagger 2.0 の標準フィールドへ設定する
- 標準仕様に存在しない独自情報は、`x-` で始まる拡張フィールドへ設定する
- `[I/O]` は標準フィールドではないため、`x-io` として扱う
- `戻り値` は独自フィールドではなく、HTTP APIの戻り値として `responses` に定義する
- `意味・範囲` は、可能なら `description` だけでなく `enum`、`minimum`、`maximum` などにも分解する
- `制約/注意事項` と `詳細仕様` は、Redocで本文表示したい場合は `description`、独自メタデータとして保持したい場合は `x-constraints`／`x-details` を使う
- CSV上では標準項目と拡張項目を分けて管理し、変換後の YAML では同じ API 定義内に記述してよい

## 15. 長文項目の箇条書き

CSVの次の項目は文章が長くなりやすいため、YAMLでは一文を詰め込まず、見出しと箇条書きに分けます。

- `引数.意味・範囲`
- `戻り値`
- `制約/注意事項`
- `詳細仕様`

### 意味・範囲

値の一覧、条件、階層がある場合は、`description` の本文を箇条書きにします。機械的に検証できる値は、`enum`、`minimum`、`maximum` などの標準フィールドにも設定します。

```yaml
description: |
  ピッカータイプ
  - 1: 時間ピッカー
  - 2: その他のピッカー
enum:
  - 1
  - 2
```

### 戻り値

戻り値は、HTTPステータスごとの `responses` に定義します。複数の結果や条件がある場合は、`description` を箇条書きにします。

```yaml
responses:
  "200":
    description: |
      - 時間ピッカー: 選択値の文字列または `undefined`
      - その他のピッカー: 選択番号または `-1`
    schema:
      type: string
```

### 制約・注意事項

制約や注意事項は、1項目1行を基本として `x-constraints` に配列で記述します。Redocの本文に表示する必要がある場合は、`description` 内にも箇条書きで記述します。

```yaml
x-constraints:
  - 分・秒の選択値は2桁で設定する
  - タイトルは10文字未満にする
```

### 詳細仕様

詳細仕様は、概要、入力条件、処理内容、参照資料などに分けます。長い説明を1行にせず、`description: |` または `x-details: |` の複数行本文にします。

```yaml
x-details: |
  - 概要: ピッカーダイアログを表示する
  - 入力条件: `datatype` と `data` を指定する
  - 処理内容: 選択結果を返却する
  - 参照資料: 画面仕様書_standApp.xlsx
```

### 箇条書き化の判断

- 値の一覧は、`-` の箇条書きにする
- 親子関係がある項目は、2スペース下げて入れ子にする
- 検証可能な制約は、`enum`、`minimum`、`maximum`、`required` などの標準フィールドにも設定する
- 説明だけの補足は `description`、独自情報として保持する内容は `x-constraints`／`x-details` に設定する
- 長文を無理に1つの `description` にまとめず、項目ごとに分割する

## 16. 表外にある記述の扱い

CSVの表外にある前任者のメモは、すぐに仕様として転記したり削除したりしません。まず、内容を分類してから扱います。

| 分類                               | 扱い                                 | 転記先の例                               |
| ---------------------------------- | ------------------------------------ | ---------------------------------------- |
| 仕様を補足する明確な説明           | 仕様として採用し、箇条書きに整理する | `description`、`x-details`               |
| 制約・注意事項                     | 制約として整理する                   | `x-constraints`、`required`、`enum` など |
| 入力・出力に関する説明             | 入出力情報として整理する             | `x-io`                                   |
| 参照先・出典                       | 出典情報として残す                   | `x-details`、`x-source`                  |
| 意味が不明、または判断できないメモ | 未確認として保留する                 | `x-notes` または作業用メモ               |
| 現在の仕様と矛盾する記述           | 採用せず、確認事項として残す         | `x-notes` または作業用メモ               |

### 転記の判断手順

1. メモがどの API、引数、戻り値に関係するかを特定する
2. 内容が仕様として明確か確認する
3. 標準フィールドで表現できるか確認する
4. 標準フィールドにない場合は `x-` 拡張フィールドへ整理する
5. 判断できない場合は、未確認として保留する
6. 出典と確認状態を CSV または作業用メモに残す

### 表外メモの管理用CSV項目

表外記述を別管理する場合は、次の列を追加します。

| CSV項目        | 内容                                             |
| -------------- | ------------------------------------------------ |
| 対象API        | どの `operationId` またはパスに関係するか        |
| 対象項目       | 引数、戻り値、制約などのどの項目に関係するか     |
| 原文           | 前任者のメモを改変せずに保存する                 |
| 分類           | 補足、制約、出典、未確認、矛盾など               |
| 確認状態       | 未確認、確認済み、採用、保留、却下               |
| 転記先         | `description`、`x-details`、`x-constraints` など |
| 確認者・確認日 | 誰がいつ判断したか                               |

### 未確認メモの例

意味が不明な記述は、標準フィールドに無理に変換しません。確認前であることが分かる形で保留します。

```yaml
x-notes:
  - status: 未確認
    text: 前任者メモの原文
    source: CSV表外メモ
```

確認後に仕様として採用できる場合は、`x-notes` から適切な標準フィールドまたは `x-` 拡張フィールドへ移します。採用できない場合も、原文と判断結果を作業用メモに残します。

### 注意点

- 表外記述を、根拠なく `summary`、`type`、`required`、`enum` などの標準フィールドへ設定しない
- 意味が不明なメモを、読みやすさだけを理由に仕様として断定しない
- 原文を変更した場合は、原文と整理後の内容を追跡できるようにする
- 仕様として採用した記述は、可能であれば担当者または関連資料で確認する

## 17. 後から追加する項目の暫定形式

後で仕様内容を `api.yaml` に追加する項目は、先に見出しだけを用意します。内容が確定していない段階では、推測した説明文や仮の値を追加しません。

```yaml
description: |
  ## 意味・範囲

  ## 戻り値

  ## 制約/注意事項

  ## 詳細仕様
```

表外メモも、後から内容を整理して追加する場合は見出しだけを残します。

```yaml
x-notes:
  - 表外メモ
```

正式な内容が確定した後に、各見出しの下へ箇条書きで追記します。


