          Observable&lt;unknown&gt;  
          - サービス登録成功時：成功
          - サービス登録失敗時：exception   APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照


          Observable&lt;unknown&gt;  
          - サービス更新成功時：成功
          - サービス更新失敗時：exception APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照

          Observable&lt;unknown&gt;  
          - サービス実行成功時： 成功
          - サービス実行失敗時： exception APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照

          Observable&lt;unknown&gt;  
          - サービステンプレート実行成功時： 成功
          - サービステンプレート実行失敗時： exception  APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照

          Observable&lt;GetDeviceInformationReturnValue&gt;  
          - 機器状態取得成功時：機器状態取得のレスポンスボディとアダプター接続状態
          - 機器状態取得失敗時：exception   APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照

          - 通信途絶の判定が不要の場合は、通信途絶判定時間に0秒を設定すること
          - 通信途絶判定時間が0の場合は、アダプター接続状態=false(非接続)で返すため参照しないこと

          S3/シーケンス図/[COM_PF10] 機器状態取得 参照

          Observable&lt;unknown&gt;  
          - 機器状態変更成功時：成功
          - 機器状態変更失敗時：exception APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照

          Observable&lt;unknown&gt;  
          - 機器状態送信要求成功時：成功
          - 機器状態送信要求失敗時：exception APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照

          Observable&lt;UniqueDataInterface&gt;
          - データ取得成功時：機器管理情報(機器種別が指定された場合は、対象の機器管理情報のみ抽出した結果)  
　　　　　　　返却データは下記記参照(参照元ファイル：MyMU_データ構造の定義.xlsx(svn-r11700))。
          - データ取得失敗時：exception(ApplicationException)

          リクエストされた機器種別の機器管理情報が存在しない場合、空のデータを返却する。

          Observable&lt;unknown&gt;  
          - ソリューション権限一覧取得成功時：ソリューション権限一覧取得のレスポンスボディ
          - ソリューション権限一覧取得失敗時：exception APIエラー処理仕様書_standApp.xlsx シート「 2. エラー処理(MyMU)」参照
                            
          S3/シーケンス図/[COM_MY01] ソリューション権限一覧取得 参照

          Observable&lt;unknown&gt;  
          - サービス利用禁止指定成功時: 成功
          - サービス利用禁止指定失敗時: exception APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照

          Observable&lt;unknown&gt;  
          - サービス利用禁止指定解除成功時: 成功
          - サービス利用禁止指定解除失敗時: exception APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照

          Observable&lt;ServiceUsageAuthorityConfirmation&gt; 
          - サービス利用権限確認成功時：サービス利用権限確認のレスポンスボディ
          - サービス利用権限確認失敗時：exception   APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照
                            
          S3/シーケンス図/[COM_PF26] サービス利用権限確認 参照

          GET TEXTメソッド実行成功時：  
          - 結果(OK)　※バージョン更新有の場合は遷移元MyMU画面へ遷移するため、バージョン更新無しの場合のみ戻り値が返る
          GET TEXTメソッド実行失敗時：  
          - exception (ApplicationException)
                            
          S3/シーケンス図/[COM_PF90] バージョン更新確認 参照

          リクエスト種別＝ネイティブ処理要求の場合のみ  
          - 成功時： ネイティブ応答データ、失敗時/例外発生時： エラー情報
          リクエスト種別=ネイティブ処理要求の通信データの型は、native通信コマンドにより異なる  
          - readCommonDataの場合　{key: string}
          - writeCommonDataの場合   {key: string,   value: string}
          S3/シーケンス図/[COM_MES00] メッセージ送信　参照

          Observable&lt;never&gt;  
          - exception 
            - APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照														
                            
          S3/シーケンス図/[COM_PF91] 物件管理エラー処理 参照
　														
          Observable&lt;never&gt;  
          - exception 
            - APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照														

          成功時： (キャッシュファイル生成=trueの場合)ファイルパス(左記以外の場合)レスポンスボディ、失敗時： 応答データ、例外発生時： エラー情報  
          ※ キャッシュファイルの生成に失敗した場合(過年度MyMU使用時のネイティブ関数実行エラーも含む)、エラー情報としてcode=0, message=File Create Failed.を返却する。

          - standAppがサポート対象とするコンテンツタイプは以下とする。
            - それ以外のコンテンツタイプをレスポンスで受信した場合は、エラー情報としてcode=0, message=File Create Failed.を呼び出し元に返却する。
            - text/plain, text/csv, application/pdf, application/json, application/json+hal, image/jpeg、image/png、image/gif、application/xml、application/x-www-form-urlencoded
          - レスポンスデータがjsonの場合のみ、パースした文字列を返却する。その他のデータ形式についてはアプリ側でパースすること。
          - ペイロードのContentTypeはapplication/jsonを指定する。
          - キャッシュファイル生成＝trueでファイル名が未指定の場合は、以下ファイル名で出力する。
            - tmp_現在日時.&lt;拡張子&gt;
          - 認証ヘッダ指定が未指定の場合は、認証ヘッダ指定＝要として扱う。
          - コンテンツタイプが未指定の場合は、application/jsonとして扱う。

          成功時： bodyデータ、失敗時： 応答データ、例外発生時： エラー情報														
          - CDNキャッシュ有効化が未指定の場合はCDNキャッシュ有効化=falseとして扱う。														
          - CDNキャッシュ有効化= falseの場合、送信パラメータ(キー：params)に現在日時を設定(now: new Date().getTime().toString())する。
          - CDNキャッシュ有効化= trueの場合、送信パラメータ(キー：params)はなしとする。														

          成功時： bodyデータ、失敗時： 応答データ、例外発生時： エラー情報
          - 認証ヘッダ指定が未指定の場合は認証ヘッダ指定＝要として扱う。
          - standAppがサポート対象とするコンテンツタイプは以下とする。
            - tそれ以外の種類を指定した場合は、エラー情報としてcode=0, message=Invalid Content Type.を返却する。
            - text/plain, text/csv, application/pdf, application/json, application/json+hal, image/jpeg、image/png、image/gif、application/xml、application/x-www-form-urlencoded
          - レスポンスデータがjsonの場合のみ、パースした文字列を返却する。その他のデータ形式についてはアプリ側でパースすること。
          - コンテンツタイプは、リクエスト、レスポンス共通とする。
          - コンテンツタイプが未指定の場合は、application/jsonとして扱う。

          - 認証ヘッダ指定が未指定の場合は認証ヘッダ指定＝要として扱う
          - standAppがサポート対象とするコンテンツタイプは以下とする
            - それ以外の種類を指定した場合は、エラー情報としてcode=0, message=Invalid Content Type.を返却する
            - text/plain, text/csv, application/pdf, application/json, application/json+hal, image/jpeg、image/png、image/gif、application/xml、application/x-www-form-urlencoded
          - コンテンツタイプが未指定の場合は、application/jsonとして扱う。

          - 認証ヘッダ指定が未指定の場合は認証ヘッダ指定＝要として扱う
          - standAppがサポート対象とするコンテンツタイプは以下とする
            - それ以外の種類を指定した場合は、エラー情報としてcode=0, message=Invalid Content Type.を返却する
            - text/plain, text/csv, application/pdf, application/json, application/json+hal, image/jpeg、image/png、image/gif、application/xml、application/x-www-form-urlencoded
          - レスポンスデータがjsonの場合のみ、パースした文字列を返却する。その他のデータ形式についてはアプリ側でパースすること
          - コンテンツタイプは、リクエスト、レスポンス共通とする
          - コンテンツタイプが未指定の場合は、application/jsonとして扱う

          リクエストURL、エンコードエラー
          - エンコードURIに含まれる{}の数とパスパラメータの数は一致させること
          - エンコードエラー=trueの場合は、呼び出し元でエラー処理(AppplicationExceptionを返す)を行うこと
          S3/アクティビティ図/[COM_CO06] エンコード済みURI生成処理　参照

















