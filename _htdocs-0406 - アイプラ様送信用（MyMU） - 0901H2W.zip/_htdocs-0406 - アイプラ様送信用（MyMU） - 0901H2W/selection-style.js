(function () {
  const defaultConfig = {
    fill: '#4C6EE8',
    stroke: '#163172',
    strokeWidth: 2,
  };

  function saveOriginalStyle(el) {
    if (!el || el.dataset.originalStyleApplied === 'true') return;

    const fill = el.getAttribute('fill') || getComputedStyle(el).fill || 'none';
    const stroke = el.getAttribute('stroke') || getComputedStyle(el).stroke || 'none';
    const strokeWidth = el.getAttribute('stroke-width') || getComputedStyle(el).strokeWidth || '0';

    el.dataset.originalFill = fill;
    el.dataset.originalStroke = stroke;
    el.dataset.originalStrokeWidth = strokeWidth;
    el.dataset.originalStyleApplied = 'true';
  }

  function restoreOriginalStyle(el) {
    if (!el) return;

    const fill = el.dataset.originalFill || 'none';
    const stroke = el.dataset.originalStroke || 'none';
    const strokeWidth = el.dataset.originalStrokeWidth || '0';

    el.classList.remove('is-selected');
    el.setAttribute('fill', fill);
    el.setAttribute('stroke', stroke);
    el.setAttribute('stroke-width', strokeWidth);
  }

  function applySelectedStyle(el, config = defaultConfig) {
    if (!el) return;

    saveOriginalStyle(el);
    el.classList.add('is-selected');
    el.setAttribute('fill', config.fill);
    el.setAttribute('stroke', config.stroke);
    el.setAttribute('stroke-width', String(config.strokeWidth));
  }

  function initializeSelection(options = {}) {
    const config = { ...defaultConfig, ...options };
    const selected = {
      current: null,
    };

    document.querySelectorAll('.js-selectable').forEach((el) => {
      saveOriginalStyle(el);

      el.addEventListener('click', () => {
        if (selected.current && selected.current !== el) {
          restoreOriginalStyle(selected.current);
        }

        selected.current = el;
        applySelectedStyle(el, config);
      });
    });
  }

  window.changeSelectedFillAndStroke = function (selectedFill, selectedStroke, width) {
    const config = {
      fill: selectedFill || defaultConfig.fill,
      stroke: selectedStroke || defaultConfig.stroke,
      strokeWidth: width || defaultConfig.strokeWidth,
    };

    const activeElement = document.querySelector('.js-selectable.is-selected');
    if (activeElement) {
      applySelectedStyle(activeElement, config);
    }
  };

  window.initializeSelection = initializeSelection;
})();
