/******************************************
 * テンプレートファイル読み込み
 ******************************************/
document.addEventListener("DOMContentLoaded", async () => {
  try {
    const [alert, header, date, footer, modal, drawer] = await Promise.all([
      fetch("../../partials/alert.txt").then((r) => r.text()),
      fetch("../../partials/header.txt").then((r) => r.text()),
      fetch("../../partials/date.html").then((r) => r.text()),
      fetch("../../partials/footer.txt").then((r) => r.text()),
      fetch("../../partials/modal.html").then((r) => r.text()),
      fetch("../../partials/drower-menu.txt").then((r) => r.text()),
    ]);

    document.querySelector(".content-alert").innerHTML = alert;
    document.querySelector(".content-header").innerHTML = header;
    document.querySelector(".content-date").innerHTML = date;
    document.querySelector(".content-footer").innerHTML = footer;
    document.querySelector(".content-modal").innerHTML = modal;
    document.querySelector(".content-drawer").innerHTML = drawer;
    initUI();
  } catch (err) {
    console.error("Failed to load partials:", err);
  }
});

function initUI() {
  // モーダル
  initModalDriveModeSelectButtons();
  initFooterButtons();
  initFooterButtonsState();
  initHeader();
  // 基本機能 画面
  // renderDriveModeSwitchBtnAndSettingPanelOperation();
}

/******************************************
 * イニシャライズ：モーダル
 * 対象：モーダル内の運転モード選択ボタン
 * アクション：JSON更新
 ******************************************/
const initModalDriveModeSelectButtons = () => {
  const modalDriveModeButtons = document.querySelectorAll(
    ".modal-drive-select-btn",
  );
  modalDriveModeButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      setJsonValue("currentMode", btn.dataset.appMode);
      renderDriveModeSwitchBtnAndSettingPanelOperation();
      renderWindControlOverlayOnOff();
    });
  });
};

/******************************************
 * イニシャライズ：フッターアイコン
 * 対象：フッターのアイコン
 * アクション：JSON更新(currentPage)
 ******************************************/
const initFooterButtons = () => {
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      setJsonValue("currentPage", btn.dataset.appPage);
    });
  });
};

/******************************************
 * ユーティリティ：JSON取得（ブラケット版）
 * 対象：セッションストレージ内のJSONリテラル
 * アクション：セッションストレージ内のJSONから値を取得
 ******************************************/
const getJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }

  if (!data) return undefined;

  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }

  return current;
};

/******************************************
 * ユーティリティ：JSON更新（ブラケット版）
 * 対象：セッションストレージ内のJSONリテラル
 * アクション：セッションストレージ内のJSONの値を更新
 ******************************************/
const setJsonValue = (propertyPath, value) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : {};
  } catch (e) {
    data = {};
  }

  // ブラケット記法をドット記法に変換
  // "buttons[0].label" → "buttons.0.label"
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let i = 0; i < props.length - 1; i++) {
    const prop = props[i];

    // 数字 → 配列アクセス
    const index = Number(prop);
    const isIndex = !isNaN(index);

    if (isIndex) {
      if (!Array.isArray(current)) {
        current = [];
      }
      if (current[index] === undefined) {
        current[index] = {};
      }
      current = current[index];
    } else {
      if (!current[prop] || typeof current[prop] !== "object") {
        current[prop] = {};
      }
      current = current[prop];
    }
  }

  // 最終プロパティ
  const lastProp = props[props.length - 1];
  const lastIndex = Number(lastProp);

  if (!isNaN(lastIndex)) {
    if (!Array.isArray(current)) current = [];
    current[lastIndex] = value;
  } else {
    current[lastProp] = value;
  }

  sessionStorage.setItem("appData", JSON.stringify(data));
};

/******************************************
 * ユーティリティ：無効ボタンをクリックしたときの処理
 * 対象：.demo-disabled-button クラスを持つ要素
 * アクション：アラート表示
 ******************************************/
document.addEventListener("click", (e) => {
  // クリックされた要素、またはその親要素が指定のクラスを持っているか判定
  const target = e.target.closest(".demo-disabled-button");
  if (target) {
    e.preventDefault(); // リンクの遷移を止める
    alert("デモアプリではこのボタンは操作できません。");
  }
});

/******************************************
 * ユーティリティ：モーダル表示
 * 対象：modal.html のモーダル
 * アクション：モーダル表示
 ******************************************/
const showModal = (modalId) => {
  const modalEl = document.getElementById(modalId);
  if (!modalEl) return;

  const modal = new bootstrap.Modal(modalEl);
  modal.show();
};

/******************************************
 * ユーティリティ：モーダルフォーカス解除
 * 対象：modal.html のモーダル
 * アクション：モーダルをクローズ後のフォーカス解除
 ******************************************/
window.addEventListener("hide.bs.modal", () => {
  document.activeElement.blur();
});

/******************************************
 * ユーティリティ：ヘッダーのアイテムを設定する
 * 対象：各画面のヘッダー
 * アクション：ヘッダー要素の初期化
 ******************************************/
window.addEventListener("load", () => {
  setTimeout(initHeader, 100);
});

function initHeader() {
  // ==============================
  // DOM取得
  // ==============================
  const headerDom = {
    leftBtn: document.getElementById("headerLeftBtn"),
    title: document.getElementById("headerTitle"),
    rightBtn: document.getElementById("headerRightBtn"),
  };

  if (!headerDom.leftBtn || !headerDom.title || !headerDom.rightBtn) {
    console.warn("header DOM がまだ準備できていません");
    return;
  }

  // ==============================
  // headerSetBodyKeyキー取得
  // ==============================
  const currentHeaderSetKey = document.body.dataset.appHeaderSet;
  if (!currentHeaderSetKey) {
    console.warn("data-app-header-set が指定されていません");
    return;
  }

  // ==============================
  // headerSetJson 取得
  // ==============================
  const headerSetJson = getJsonValue(`headerSet.${currentHeaderSetKey}`);
  if (!headerSetJson) {
    console.warn(`headerSet.${currentHeaderSetKey} が見つかりません`);
    return;
  }

  // ==============================
  // タイトル
  // ==============================
  headerDom.title.innerHTML = headerSetJson.title;

  // ==============================
  // 左ボタン
  // ==============================
  renderLeftButton(headerSetJson.left?.type, headerDom.leftBtn);
  headerDom.leftBtn.onclick = () =>
    handleHeaderLeftAction(headerSetJson.left?.type);

  // ==============================
  // 右ボタン
  // ==============================
  renderRightButton(headerSetJson.right, headerDom.rightBtn);
  headerDom.rightBtn.onclick = () =>
    handleHeaderRightAction(headerSetJson.right?.action);
}

// ==============================
// 左ボタン描画
// ==============================
// リセット
function renderLeftButton(type, btn) {
  btn.innerHTML = "";
  btn.classList.remove("d-none");
  // アイコン設定
  switch (type) {
    case "back":
      btn.innerHTML = '<i class="bi bi-chevron-left"></i>';
      break;
    case "drawer":
      btn.innerHTML = '<i class="bi bi-list"></i>';
      break;
    default:
      btn.classList.add("d-none");
  }
}

// ==============================
// 左アクション処理
// ==============================
function handleHeaderLeftAction(type) {
  switch (type) {
    case "back":
      // document.addEventListener("DOMContentLoaded", syncToggleFromStorage);
      // window.addEventListener("pageshow", syncToggleFromStorage);
      window.history.back();
      break;

    case "drawer":
      const bsOffcanvas = new bootstrap.Offcanvas("#appOffcanvas");
      bsOffcanvas.show();
      break;
  }
}

// ==============================
// 右ボタン描画
// ==============================
function renderRightButton(headerSetJsonRight, headerDomRight) {
  // 右ボタンのプロパティチェック
  if (!headerSetJsonRight || !headerSetJsonRight.visible) {
    headerDomRight.classList.add("d-none");
    headerDomRight.onclick = null;
    return;
  }
  // 右側のテキストボタン表示

  headerDomRight.innerText = headerSetJsonRight.text || "";
}

// ==============================
// 右アクション処理（完了/done | 設定/set | リンク/link | 編集/edit | 決定/ok）
// ==============================
function handleHeaderRightAction(action) {
  switch (action) {
    // JSON更新後、前の画面へ戻る
    case "done":
      window.history.back();
      break;

    // 電気代チェック画面へ遷移
    case "set":
      window.history.back();
      break;

    // 指定リンクへ遷移
    case "link":
      const rightBtn = document.getElementById("headerRightBtn");
      const target = getJsonValue(
        "headerSet.electricityBillCheck.right.target",
      );
      if (rightBtn) {
        rightBtn.href = target;
      }
      break;

    // 現在の画面が編集可能になるtouch-airflow-back
    case "edit":
      window.history.back();
      break;

    // タッチ気流、窓位置設定のポインターがロックされる
    case "ok":
      window.history.back();
      break;

    // アラート表示schedule-done
    case "alert":
      alert(
        "デモアプリではこのボタンは操作できません。＜ ボタンで戻ってください",
      );
      break;

    // スケジュール画面で完了
    case "schedule-done":
      setJsonValue("isAutoMationSetDone", true);
      window.location.href = '../schedule/';
      break;

    // アラート表示
    case "touch-airflow-back":
      alert(
        "風向を設定しました。やり直す場合は画像をダブルタップしてください。",
      );
      break;
  }
}

/******************************************
 * レンダリング：フッターアイコン表示更新
 * 対象：フッターのアイコン
 * アクション：アクティブページのフッターアイコンの表示更新
 ******************************************/
const initFooterButtonsState = () => {
  // 0. フッターが存在しない画面の処理
  const footerElement = document.getElementsByClassName("content-footer")[0];
  if (footerElement.className.includes("d-none")) {
    return;
  }
  // スタイルリセット
  const currentPage = getJsonValue("currentPage");
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.classList.remove("active");
  });
  // レンダリング
  footerButtons.forEach((btn) => {
    const page = btn.dataset.appPage;
    if (page === currentPage) {
      btn.classList.add("active");
    }
  });
};

/******************************************
 * レンダリング：基本機能 画面
 * 対象：熱画像ホルダー
 * アクション：表示/非表示
 ******************************************/
const renderThermalImageOnOff = () => {
  const isThermalImageManagement = getJsonValue("isThermalImageManagement");
  const thermalImageElement = document.getElementById("thermalImageContainer");
  isThermalImageManagement
    ? (thermalImageElement.style.visibility = "visible")
    : (thermalImageElement.style.visibility = "hidden");
};

/******************************************
 * レンダリング：基本機能 画面
 * 対象：操作パネル（運転モード選択ボタン／ラベル／アイコン／設定表示（温度／湿度・送風））
 * アクション：操作パネルの更新
 ******************************************/
const renderDriveModeSwitchBtnAndSettingPanelOperation = () => {
  let currentMode = getJsonValue("currentMode");
  const switchBtn = document.getElementById("driveModeSwitchBtn");
  const switchBtnLabel = document.getElementById("currentModeLabel");
  const switchBtnIcon = document.getElementById("currentModeIcon");
  const switchBtnTempDisplay = document.getElementById("tempDisplay");
  // クラスをリセット
  let initialStyle =
    "btn rounded-pill d-flex justify-content-center align-items-center gap-2 mt-3 app-drive-btn";
  document.getElementById("driveModeSwitchBtn").className = initialStyle;
  // クラス、ラベル、アイコン、設定表示を更新
  switchBtn.classList.add(
    getJsonValue(`driveModeSelectBtn.${currentMode}.style`),
  );
  switchBtnLabel.innerText = getJsonValue(
    `driveModeSelectBtn.${currentMode}.label`,
  );
  switchBtnIcon.src = getJsonValue(`driveModeSelectBtn.${currentMode}.icon`);
  switchBtnTempDisplay.className = getJsonValue(
    `driveModeSelectBtn.${currentMode}.settingDisplay`,
  );
};

/******************************************
 * レンダリング：基本機能 画面
 * 対象：風速上下風向左右風向ホルダー
 * アクション：オーバーレイ表示/非表示
 ******************************************/
const renderWindControlOverlayOnOff = () => {
  const overlay = document.querySelector(".wind-overlay");
  const mode = getJsonValue("currentMode");
  mode.includes("ai-auto")
    ? (overlay.style.display = "block")
    : (overlay.style.display = "none");
};

/******************************************
 * レンダリング：基本機能
 * 対象：運転する⇔停止する ボタンのスタイルとラベル名
 * アクション：ボタンの表示更新（運転する／停止する）
 ******************************************/
const renderDriveOnOffButton = () => {
  const btn = document.getElementById("btnRunStop");
  if (!btn) return;
  const isRunning = getJsonValue("modalDrive.isRunning");
  // 運転中の場合
  if (isRunning) {
    btn.style.backgroundColor = "white";
    btn.style.color = "var(--app-color-cooling)";
    btn.innerText = "停止する";
    // 停止中の場合
  } else {
    btn.style.backgroundColor = "var(--app-color-cooling)";
    btn.style.color = "white";
    btn.innerText = "運転する";
  }
};

/******************************************
 * イニシャライズ：基本機能 画面
 * 対象：運転する⇔停止する ボタン
 * アクション：モーダル表示
 ******************************************/
document.addEventListener("click", (e) => {
  const trigger = e.target.closest(".js-drive-trigger");
  if (!trigger) return;

  const isRunning = getJsonValue("modalDrive.isRunning");
  const modal = document.getElementById("modalRacStartStop");
  if (!modal) return;

  const messageEl = modal.querySelector("#modalRacStartStopMessage");
  const okBtn = modal.querySelector(".js-modal-drive");

  if (!messageEl || !okBtn) return;

  if (isRunning) {
    messageEl.textContent = trigger.dataset.messageRun;
    okBtn.dataset.appDrive = "runToStop";
  } else {
    messageEl.textContent = trigger.dataset.messageStop;
    okBtn.dataset.appDrive = "stopToRun";
  }

  showModal("modalRacStartStop");
});

/******************************************
 * イニシャライズ：基本機能 画面
 * 対象：運転する⇔停止する ボタン
 * アクション：クリック後のJSON更新
 ******************************************/
document.addEventListener("pointerup", (e) => {
  const btn = e.target.closest(".js-modal-drive");
  if (!btn) return;

  btn.dataset.appDrive === "stopToRun" ? handleRacStart() : handleRacStop();

  const modalEl = btn.closest(".modal");
  bootstrap.Modal.getInstance(modalEl).hide();

  renderDriveOnOffButton();
});
// 停止⇒ 運転
const handleRacStart = () => {
  setJsonValue("modalDrive.isRunning", true);
};
// 運転⇒ 停止
const handleRacStop = () => {
  setJsonValue("modalDrive.isRunning", false);
  setJsonValue("isTouchAirflow", false);
};

/******************************************
 * レンダリング：基本機能 画面
 * 対象：「停止中」表示⇔非表示 ホルダー
 * アクション：表示/非表示
 ******************************************/
// 「停止中」を非表示
const elementsDisplayDefault = () => {
  const setValueDisplay = document.getElementById("setValueDisplay");
  const airControl = document.getElementById("airControl");
  const statusStopped = document.getElementById("statusStopped");
  // 各要素の表示・非表示を制御
  setValueDisplay.classList.remove("d-none");
  airControl.classList.remove("d-none");
  statusStopped.classList.add("d-none");
};

// 「停止中」を表示
const elementsDisplayNone = () => {
  const setValueDisplay = document.getElementById("setValueDisplay");
  const airControl = document.getElementById("airControl");
  const statusStopped = document.getElementById("statusStopped");
  // 各要素の表示・非表示を制御
  setValueDisplay.classList.add("d-none");
  airControl.classList.add("d-none");
  statusStopped.classList.remove("d-none");
};

const renderStatusStoppedEl = () => {
  const isRunning = getJsonValue("modalDrive.isRunning");
  if (isRunning) {
    elementsDisplayDefault();
  } else {
    elementsDisplayNone();
  }
};

/******************************************
 * イニシャライズ：その他機能 画面
 * 対象：タッチ気流トグルスイッチa
 * アクション：JSONの値からモーダル表示
 ******************************************/
document.addEventListener("click", (e) => {
  const targetSwitch = e.target.closest("#toggleTouchAirflow");
  if (!targetSwitch) return;
  const driveMode = getJsonValue("currentMode");
  const isThermalImageManagement = getJsonValue("isThermalImageManagement");
  const isRunning = getJsonValue("modalDrive.isRunning");

  // タッチ気流トグルをONにしようとしたときの処理
  if (targetSwitch.checked) {
    // 熱画像がOFFの場合、モーダル表示してONにできないようにする
    if (!isThermalImageManagement) {
      showModal("modalThermalImageManagementRequirement"); // タッチ気流を設定する場合は…
      targetSwitch.checked = false; // 元に戻す
      return;
    }

    // 運転中でない場合、モーダル表示してONにできないようにする
    if (!isRunning) {
      showModal("modalTouchAirflowRequirement"); // タッチ気流を設定する場合は…
      targetSwitch.checked = false; // 元に戻す
      return;
    }
    // 運転中の場合、運転モードに応じた処理
    switch (driveMode) {
      // 冷房の場合
      case "cooling":
        setJsonValue("currentMode", "ai-auto-cooling"); // A.I.自動（冷房）に変更
        break;
      // 暖房の場合
      case "heating":
        setJsonValue("currentMode", "ai-auto-heating"); // A.I.自動（暖房）に変更
        break;
      // 送風の場合
      case "perflation":
        showModal("modalTouchAirflowRequirement"); // タッチ気流を設定する場合は…
        targetSwitch.checked = false; // 元に戻す
        break;
      // 除湿の場合
      case "dehumidifying":
        showModal("modalTouchAirflowRequirement"); // タッチ気流を設定する場合は…
        targetSwitch.checked = false; // 元に戻す
        break;
    }
  }
});

/******************************************
 * レンダリング：その他機能画面
 * 対象：タッチ気流トグルスイッチa
 * アクション：タッチ気流トグルスイッチの表示更新
 ******************************************/
// タッチ気流トグルスイッチ
const renderTouchAirflowToggle = () => {
  const value = getJsonValue("isTouchAirflow");
  const btn = document.getElementById("toggleTouchAirflow");
  if (value) {
    btn.checked = true;
    btn.nextElementSibling.innerText = "ON";
  } else {
    btn.checked = false;
    btn.nextElementSibling.innerText = "OFF";
  }
};

/******************************************
 * レンダリング：熱画像管理画面
 * 対象：熱画像トグルスイッチ
 * アクション：トグルスイッチの表示更新
 ******************************************/
const renderThermalImageManagementToggle = () => {
  const value = getJsonValue("isThermalImageManagement");
  const toggle = document.getElementById("thermalImageManagement");
  if (value) {
    toggle.checked = true;
  } else {
    toggle.checked = false;
  }
};

/******************************************
 * イニシャライズ：熱画像管理画面
 * 対象：熱画像トグルスイッチa
 * アクション：JSONの値を更新（タッチ気流のJSONも更新）
 ******************************************/
document.addEventListener("click", (e) => {
  const targetSwitch = e.target.closest("#thermalImageManagement");
  if (!targetSwitch) return;
  const isTouchAirflow = getJsonValue("isTouchAirflow");

  targetSwitch.addEventListener("change", () => {
    // 熱画像トグルスイッチ　OFF → ON でJSON更新
    if (targetSwitch.checked) {
      setJsonValue("isThermalImageManagement", true);
      // 熱画像トグルスイッチ　ON → OFF でJSON更新
    } else {
      setJsonValue("isThermalImageManagement", false);
      setJsonValue("isTouchAirflow", false); // タッチ気流を強制OFF
    }
  });
});

/******************************************
 * レンダリング：スケジュール 画面
 * 対象：3つ目のオートメーションの各値表示
 * アクション：JSONの値を各要素に反映
 ******************************************/
const renderScheduleDetails3 = () => {
  const isScheduleEnabled = getJsonValue("isAutoMationSetDone");
  if (!isScheduleEnabled) return;
  // 3つ目のスケジュールカード表示
  document.getElementById("scheduleDetail3").style.display = "block";
  // スケジュール名
  document.getElementById("scheduleName3").innerText =
    getJsonValue("schedule[0].name");
  // 時間
  document.getElementById("scheduleTime3").innerText = getJsonValue(
    "schedule[0].startTime",
  );
  // 繰り返し
  document.getElementById("scheduleRepeat3").innerText = getJsonValue(
    "schedule[0].dayOfTheWeekLabel",
  );
  // 運転／停止
  document.getElementById("scheduleDriveOnOff3").innerText = getJsonValue(
    "schedule[0].isDrive",
  )
    ? "運転"
    : "停止";
  // モード
  document.getElementById("scheduleDriveMode3").innerText =
    getJsonValue("schedule[0].mode");
  // 設定温度
  document.getElementById("scheduleSetValue3").innerText =
    getJsonValue("schedule[0].setValue") + "℃";
};

/******************************************
 * イニシャライズ：スケジュール編集 画面
 * 対象：オートメーション削除ボタン
 * アクション：削除ボタンをクリックするとJSONの値を更新
 ******************************************/
const initDeleteAutomation = () => {
  setJsonValue("isAutoMationSetDone", false);
  window.location.href = "../schedule/";
};

/******************************************
 * レンダリング：スケジュール編集 画面
 * 対象：3つ目のオートメーション
 * アクション：isAutoMationSetDone の値に応じて表示/非表示
 ******************************************/
const renderDeleteTheAutomationButton = () => {
  const automationDeleteBtn = document.getElementById("btnDeleteTheAutomation");
  const isAutoMationSetDone = getJsonValue("isAutoMationSetDone");
  isAutoMationSetDone
    ? (automationDeleteBtn.style.display = "block")
    : (automationDeleteBtn.style.display = "none");
};

/******************************************
 * スケジュール表示処理
 ******************************************/
// 曜日表示用マップ
const DAY_LABEL_MAP = {
  sun: "日",
  mon: "月",
  tue: "火",
  wed: "水",
  thu: "木",
  fri: "金",
  sat: "土",
};

// スケジュール表示テキスト取得関数（スケジュール 画面用）
function getScheduleText() {
  const dayOfTheWeek = getJsonValue("schedule[0].dayOfTheWeek");
  const activeDays = Object.entries(dayOfTheWeek)
    .filter(([, value]) => value === true)
    .map(([key]) => key);

  // 何も選択されていない
  if (activeDays.length === 0) {
    return "一度だけ実行します";
  }

  // 全て選択
  if (activeDays.length === 7) {
    return "毎日実行します";
  }

  // 一部選択
  const labelText = activeDays.map((day) => DAY_LABEL_MAP[day]).join("、");

  return `毎週${labelText}曜日に実行します`;
}

// スケジュール表示テキスト取得関数（スケジュール編集 画面用）
function getScheduleTextShort() {
  const dayOfTheWeek = getJsonValue("schedule[0].dayOfTheWeek");
  const activeDays = Object.entries(dayOfTheWeek)
    .filter(([, value]) => value === true)
    .map(([key]) => key);

  // 何も選択されていない
  if (activeDays.length === 0) {
    return null;
  }

  // 全て選択
  if (activeDays.length === 7) {
    return "毎日";
  }

  // 一部選択
  const labelText = activeDays.map((day) => DAY_LABEL_MAP[day]).join("");

  return `${labelText}`;
}

// 表示アップデート 関数
function renderDayOfWeekToggle() {
  const dayOfTheWeek = getJsonValue("schedule[0].dayOfTheWeek");

  document.querySelectorAll(".day-of-the-week").forEach((button) => {
    const dayKey = button.dataset.appScheduleDay; // sun, mon...

    if (dayOfTheWeek[dayKey]) {
      button.classList.add("active");
      button.setAttribute("aria-pressed", "true");
    } else {
      button.classList.remove("active");
      button.setAttribute("aria-pressed", "false");
    }
  });

  updateScheduleText();
}

// トグルスイッチのクリックイベントをバインド 関数（JSON → トグル + 文言）
function bindDayOfWeekEvents() {
  document.querySelectorAll(".day-of-the-week").forEach((button) => {
    button.addEventListener("click", () => {
      const dayKey = button.dataset.appScheduleDay;
      const isActive = button.classList.contains("active");

      const path = `schedule[0].dayOfTheWeek.${dayKey}`;
      setJsonValue(path, isActive);

      updateScheduleText();
    });
  });
}

// 文言更新のみ 関数
function updateScheduleText() {
  const textEl = document.getElementById("scheduleText");
  // スケジュール 画面用
  if (textEl) {
    textEl.innerText = getScheduleText();
  }
  // スケジュール編集 画面用onclick="inputFormToJsonAutomationName()">
  setJsonValue("schedule[0].dayOfTheWeekLabel", getScheduleTextShort());
}

document.addEventListener("DOMContentLoaded", () => {
  const offcanvasLinkHandler = () => {
    const link = document.getElementById("transition-link");
    const myOffcanvasElement = document.getElementById("appOffcanvas");
  };

  offcanvasLinkHandler();
});

/******************************************
 * イニシャライズ：スケジュール編集 画面
 * 対象：オートメーション名入力フォーム
 * アクション：決定ボタンをクリックするとJSONの値を更新
 ******************************************/
const inputFormToJsonAutomationName = () => {
  const input = document.getElementById("scheduleName");
  const value = input.value;
  setJsonValue("schedule[0].name", value);
  document.getElementById("scheduleName3").innerText = value;
};
