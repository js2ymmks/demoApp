## 外部IF一覧
| 階層                 | API種別                            | API通し番号 | API名称                       | フォルダ      | ファイル                    | クラス                        | メソッド                     |
| :------------------- | :--------------------------------- | :---------- | :---------------------------- | :------------ | :-------------------------- | :---------------------------- | :----------------------------- |
| プレゼンテーション   | ローディングアイコン表示/非表示API | COM_VW00    | ローディング表示              | view          | loading-view.component.ts   | LodingViewComponent           | show()                         |
| プレゼンテーション   | ローディングアイコン表示/非表示API | COM_VW01    | ローディング非表示            | view          | loading-view.component.ts   | LodingViewComponent           | hide()                         |
| プレゼンテーション   | ダイアログ表示API                  | COM_VW02    | ダイアログ表示                | view          | dialog-view.component.ts    | DialogViewComponent           | showMessageDialog()            |
| ビジネスロジック     | ピッカーダイアログ表示API          | COM_VW03    | ピッカーダイアログ表示        | model         | view.service.ts             | PickerService                 | showPickerPopup()              |
| ビジネスロジック     | ネイティブAPI                      | COM_NS00    | 戻るボタン操作                | model         | native.service.ts           | NativeService                 | handleBackAndroid()            |
| ビジネスロジック     | ネイティブAPI                      | COM_NS01    | MyMUアプリバージョン取得      | model         | native.service.ts           | NativeService                 | getVersionApp()                |
| ビジネスロジック     | ネイティブAPI                      | COM_NS02    | アプリ内WebView表示           | model         | native.service.ts           | NativeService                 | openBrowserUrl()               |
| ビジネスロジック     | ネイティブAPI                      | COM_NS03    | 外部Webブラウザ表示           | model         | native.service.ts           | NativeService                 | lanchBrowserUrl()              |
| ビジネスロジック     | ネイティブAPI                      | COM_NS04    | 初期化処理完了イベント監視    | model         | native.service.ts           | NativeService                 | onDeviceReady()                |
| ビジネスロジック     | ネイティブAPI                      | COM_NS05    | WebViewキャッシュクリア       | model         | native.service.ts           | NativeService                 | webViewCacheClear()            |
| ビジネスロジック     | ネイティブAPI                      | COM_NS06    | ネットワーク接続状態確認      | model         | native.service.ts           | NativeService                 | isConnectedNetwork()           |
| ビジネスロジック     | ネイティブAPI                      | COM_NS07    | QRコード読み取り              | model         | native.service.ts           | NativeService                 | scanQrCode()                   |
| ビジネスロジック     | ネイティブAPI                      | COM_NS08    | 共有機能呼び出し              | model         | native.service.ts           | NativeService                 | callSharesheet()               |
| ビジネスロジック     | ネイティブAPI                      | COM_NS09    | デバイストークン取得          | model         | native.service.ts           | NativeService                 | getNotificationToken()         |
| ビジネスロジック     | ネイティブAPI                      | COM_NS10    | ストア公開バージョン更新確認  | model         | native.service.ts           | NativeService                 | getStoreVersion()              |
| ビジネスロジック     | ネイティブAPI                      | COM_NS11    | アプリ内WebView表示(ITOT連携) | model         | native.service.ts           | NativeService                 | openBrowserUrl_ITOT()          |
| ビジネスロジック     | ネイティブAPI                      | COM_NS13    | アプリ存在確認                | model         | native.service.ts           | NativeService                 | checkAppExist()                |
| ビジネスロジック     | ネイティブAPI                      | COM_NS14    | Geofence監視開始              | model         | native.service.ts           | NativeService                 | startGeofence()                |
| ビジネスロジック     | ネイティブAPI                      | COM_NS15    | Geofence監視停止              | model         | native.service.ts           | NativeService                 | stopGeofence()                 |
| ビジネスロジック     | ネイティブAPI                      | COM_NS16    | Geofence位置情報一覧取得      | model         | native.service.ts           | NativeService                 | getGeofenceIdList()            |
| ビジネスロジック     | ネイティブAPI                      | COM_NS17    | 位置情報権限確認              | model         | native.service.ts           | NativeService                 | requestLocationPermission()    |
| ビジネスロジック     | ネイティブAPI                      | COM_NS18    | 現在位置情報取得              | model         | native.service.ts           | NativeService                 | getLocation()                  |
| ビジネスロジック     | ネイティブAPI                      | COM_NS20    | 画面回転状態設定              | model         | native.service.ts           | NativeService                 | setOrientation()               |
| ビジネスロジック     | ネイティブAPI                      | COM_NS21    | 画面回転状態取得              | model         | native.service.ts           | NativeService                 | getOrientation()               |
| ビジネスロジック     | ネイティブAPI                      | COM_NS22    | ストアレビューリクエスト      | model         | native.service.ts           | NativeService                 | requestStoreReview()           |
| ビジネスロジック     | ネイティブAPI                      | COM_NS23    | OSバージョン取得              | model         | native.service.ts           | NativeService                 | getOSVersion()                 |
| ビジネスロジック     | アプリ間連携API                    | COM_LS00    | アプリ切替                    | model         | linkage.service.ts          | LinkageService                | loadApp()                      |
| ビジネスロジック     | アプリ間連携API                    | COM_LS01    | 前アプリ読み込み              | model         | linkage.service.ts          | LinkageService                | loadAppPrevious()              |
| ビジネスロジック     | アプリ間連携API                    | COM_LS02    | アプリ間共有情報出力          | model         | linkage.service.ts          | LinkageService                | writeCommonData()              |
| ビジネスロジック     | アプリ間連携API                    | COM_LS03    | アプリ間共有情報取得          | model         | linkage.service.ts          | LinkageService                | readCommonDataOrDefault()      |
| ビジネスロジック     | 物件管理API                        | COM_PF00    | 物件一覧取得                  | model         | area.ts                     | AreaService                   | getAreas()                     |
| ビジネスロジック     | 物件管理API                        | COM_PF002   | 物件一覧取得v2                | model         | area.ts                     | AreaService                   | getAreasV2()                   |
| ビジネスロジック     | 物件管理API                        | COM_PF27    | 物件情報更新                  | model         | area.ts                     | AreaService                   | updatePropertyInformation()    |
| ビジネスロジック     | 物件管理API                        | COM_PF01    | 物件ユーザー情報一覧取得      | model         | area.ts                     | AreaUserInfoService           | getMemberList()                |
| ビジネスロジック     | 物件管理API                        | COM_PF02    | 物件機器一覧取得              | model         | area.ts                     | AreaDevicesService            | getAreaDevices()               |
| ビジネスロジック     | 物件管理API                        | COM_PF03    | 物件サービス一覧取得          | model         | area.ts                     | AreaServicesService           | getAreaServices()              |
| ビジネスロジック     | 物件管理API                        | COM_PF04    | サービス登録状況取得          | model         | area.ts                     | AreaServicesService           | getServiceRegistration()       |
| ビジネスロジック     | 物件管理API                        | COM_PF05    | サービス情報取得              | model         | area.ts                     | AreaServicesService           | getServiceInfomation()         |
| ビジネスロジック     | 物件管理API                        | COM_PF09    | 物件情報検索                  | model         | area.ts                     | AreaServicesService           | getAreaInfomation()            |
| ビジネスロジック     | 物件管理API                        | COM_PF06    | 物件サービス管理追加          | model         | area.ts                     | AreaServicesManagementService | addAreaServiceManagement()     |
| ビジネスロジック     | 物件管理API                        | COM_PF07    | 物件サービス管理一覧取得      | model         | area.ts                     | AreaServicesManagementService | getAreaServiceManagements()    |
| ビジネスロジック     | 物件管理API                        | COM_PF08    | 物件サービス管理確認          | model         | area.ts                     | AreaServicesManagementService | confirmAreaServiceManagement() |
| ビジネスロジック     | 物件管理API                        | COM_PF0A    | 物件機器削除                  | model         | area.ts                     | AreaDevicesService            | deleteAreaDevices()            |
| ビジネスロジック     | 機器管理API                        | COM_PF10    | 機器状態取得                  | model         | device.ts                   | DeviceStatusService           | getDeviceInformation()         |
| ビジネスロジック     | 機器管理API                        | COM_PF11    | 機器状態変更                  | model         | device.ts                   | DeviceStatusService           | updateDeviceStatus()           |
| ビジネスロジック     | 機器管理API                        | COM_PF12    | 機器状態送信要求              | model         | device.ts                   | DeviceStatusService           | requestDeviceStatus()          |
| ビジネスロジック     | 機器管理API                        | COM_PF20    | サービス登録                  | model         | device.ts                   | ServicesManagementService     | registerService()              |
| ビジネスロジック     | 機器管理API                        | COM_PF21    | サービス更新                  | model         | device.ts                   | ServicesManagementService     | updateService()                |
| ビジネスロジック     | 機器管理API                        | COM_PF22    | サービス実行                  | model         | device.ts                   | ServicesManagementService     | doAction()                     |
| ビジネスロジック     | 機器管理API                        | COM_PF23    | サービステンプレート実行      | model         | device.ts                   | ServicesManagementService     | executeService()               |
| ビジネスロジック     | 機器管理API                        | COM_DEV01   | 機器管理情報取得              | model         | device.ts                   | DeviceManagementService       | getDeviceManagements()         |
| ビジネスロジック     | サービス管理API                    | COM_PF24    | サービス利用禁止指定          | model         | area.ts                     | ServicePermissionService      | prohibitServiceUse()           |
| ビジネスロジック     | サービス管理API                    | COM_PF25    | サービス利用禁止指定解除      | model         | area.ts                     | ServicePermissionService      | deletePermission()             |
| ビジネスロジック     | サービス管理API                    | COM_PF26    | サービス利用権限確認          | model         | area.ts                     | ServicePermissionService      | confirmAuthUsageService()      |
| ビジネスロジック     | ソリューション権限管理API          | COM_MY01    | ソリューション権限一覧取得    | model         | solution.ts                 | SolutionPermissionMngService  | getSolutionPermissions()       |
| ビジネスロジック     | バージョン更新確認API              | COM_PF90    | バージョン更新確認            | model         | version-up-check.service.ts | VersionupCheckService         | confirmVersion()               |
| ビジネスロジック     | エラー処理API                      | COM_PF91    | 物件管理エラー処理            | model         | notification.service.ts     | AreaNotificationService       | areaMgmtErrorHandler()         |
| ビジネスロジック     | エラー処理API                      | COM_PF96    | サービス管理エラー処理        | model         | notification.service.ts     | AreaNotificationService       | serviceMgmtErrorHandler()      |
| ビジネスロジック     | エラー処理API                      | COM_PF92    | ユーザ・機器管理エラー処理    | model         | notification.service.ts     | DeviceNotificationService     | deviceMgmtErrorHandler()       |
| ビジネスロジック     | エラー処理API                      | COM_PF93    | ログアウトエラー処理          | model         | notification.service.ts     | ErrorService                  | logoutErrorHandler()           |
| ビジネスロジック     | エラー処理API                      | COM_PF94    | MyMUホーム遷移エラー処理      | model         | notification.service.ts     | ErrorService                  | loadMymuErrorHandler()         |
| ビジネスロジック     | エラー処理API                      | COM_PF95    | 通信エラー処理                | model         | notification.service.ts     | ErrorService                  | applicationErrorHandler()      |
| ビジネスロジック     | エラー処理API                      | COM_PF97    | サービス実行エラー処理        | model         | notification.service.ts     | DeviceNotificationService     | serviceExecutionErrorHandler() |
| ビジネスロジック     | エラー処理API                      | COM_PF98    | 管理者変更エラー処理          | model         | notification.service.ts     | AreaNotificationService       | changeMgmtSetHandler()         |
| ビジネスロジック     | アプリ管理API                      | COM_APP01   | アプリ管理情報取得            | model         | app.service.ts              | AppManagementService          | getAppManagements()            |
| インフラストラクチャ | HTTP通信API                        | COM_CO00    | GETメソッド実行               | Communication | com-outside.ts              | ComOutside                    | get()                          |
| インフラストラクチャ | HTTP通信API                        | COM_CO01    | GET TEXTメソッド実行          | Communication | com-outside.ts              | ComOutside                    | getText()                      |
| インフラストラクチャ | HTTP通信API                        | COM_CO02    | POSTメソッド実行              | Communication | com-outside.ts              | ComOutside                    | post()                         |
| インフラストラクチャ | HTTP通信API                        | COM_CO03    | DELETEメソッド実行            | Communication | com-outside.ts              | ComOutside                    | delete()                       |
| インフラストラクチャ | HTTP通信API                        | COM_CO04    | PUTメソッド実行               | Communication | com-outside.ts              | ComOutside                    | put()                          |
| インフラストラクチャ | HTTP通信API                        | COM_CO06    | エンコード処理済みURI生成     | Communication | com-outside.ts              | ComOutside                    | generateEncodedUri()           |
| インフラストラクチャ | 認証管理API                        | COM_AU00    | ITOT連携トークン更新実行      | Communication | authentication.ts           | Authentication                | executeTokenRefresh()          |
| インフラストラクチャ | 認証管理API                        | COM_AU01    | ITOT連携トークン取得実行      | Communication | authentication.ts           | Authentication                | executeGetToken()              |
| インフラストラクチャ | 認証管理API                        | COM_AU10    | Linovaトークン更新実行        | Communication | authentication.ts           | Authentication                | executeLinovaTokenRefresh()    |
| インフラストラクチャ | 認証管理API                        | COM_AU12    | Linovaトークン無効化          | Communication | authentication.ts           | Authentication                | revokeLinovaToken()            |
| インフラストラクチャ | postMessage通信API                 | COM_MES00   | メッセージ送信                | Communication | messanger.ts                | Messenger                     | postMessage()                  |
| インフラストラクチャ | postMessage通信API                 | COM_MES01   | ウィンドウ外遷移要求          | Communication | messanger.ts                | Messenger                     | routeExtWindow()               |
| その他               | タイマー処理API                    | COM_UT00    | タイマー作成                  | utility       | timer.services.ts           | TimerService                  | setInterval()                  |
| その他               | タイマー処理API                    | COM_UT01    | タイマー停止                  | utility       | timer.services.ts           | TimerService                  | clearAllInterval()             |
| その他               | タイマー処理API                    | COM_UT02    | 指定タイマー停止              | utility       | timer.services.ts           | TimerService                  | clearInterval()                |
| その他               | スクロールバー処理API              | COM_UT03    | 慣性スクロール動作停止        | utility       | scrollbar.service.ts        | ScrollbarService              | stopAnimation()                |
| その他               | ログ表示API                        | COM_UT04    | トレースレベルのログ出力      | utility       | log.ts                      | LogService                    | trace()                        |
| その他               | ログ表示API                        | COM_UT05    | デバッグレベルのログ出力      | utility       | log.ts                      | LogService                    | debug()                        |
| その他               | ログ表示API                        | COM_UT06    | 情報レベルのログ出力          | utility       | log.ts                      | LogService                    | info()                         |
| その他               | ログ表示API                        | COM_UT07    | 記録レベルのログ出力          | utility       | log.ts                      | LogService                    | log()                          |
| その他               | ログ表示API                        | COM_UT08    | 警告レベルのログ出力          | utility       | log.ts                      | LogService                    | warn()                         |
| その他               | ログ表示API                        | COM_UT09    | エラーエベルのログ出力        | utility       | log.ts                      | LogService                    | error()                        |
| その他               | ログ表示API                        | COM_UT10    | 致命的エラーレベルのログ出力  | utility       | log.ts                      | LogService                    | fatal()                        |
| その他               | データ変換API                      | COM_UT20    | バイナリテキスト変換          | utility       | convert.service.ts          | ConvertService                | blobToText()                   |




## フォルダ構成
| フォルダ名 |               |         | ファイル名                                  | クラス名                     |
| :--------- | :------------ | :------ | :------------------------------------------ | :--------------------------- |
| standApp   |               |         | app-injector.ts                             |                              |
| standApp   |               |         | app-native-event.ts                         |                              |
| standApp   |               |         | app.component.html                          |                              |
| standApp   |               |         | app.component.scss                          |                              |
| standApp   |               |         | app.component.ts                            |                              |
| standApp   |               |         | global-error-handler.ts                     |                              |
| standApp   |               |         | index.ts                                    |                              |
| standApp   |               |         | stand-app.module.ts                         |                              |
| standApp   | view          | dialog  | dialog-view.component.html                  |                              |
| standApp   | view          | dialog  | dialog-view.component.scss                  |                              |
| standApp   | view          | dialog  | dialog-view.component.ts                    |                              |
| standApp   | view          | loading | loading-view.component.html                 |                              |
| standApp   | view          | loading | loading-view.component.scss                 |                              |
| standApp   | view          | loading | loading-view.component.ts                   |                              |
| standApp   | view          | style   | anypicker-customize.scss                    |                              |
| standApp   | view          | style   | check-box.scss                              |                              |
| standApp   | view          | style   | index.scss                                  |                              |
| standApp   | view          | text    | ja.json                                     |                              |
| standApp   | model         |         | view.service.ts                             | LoadingService               |
| standApp   | model         |         |                                             | DialogService                |
| standApp   | model         |         |                                             | PickerService                |
| standApp   | model         |         | version-up-check.service.ts                 |                              |
| standApp   | model         |         | area.ts                                     | AreaService                  |
| standApp   | model         |         |                                             | AreaUserInfoService          |
| standApp   | model         |         |                                             | AreaDeviceService            |
| standApp   | model         |         |                                             | AreaServicesService          |
| standApp   | model         |         |                                             | AreaServicesManagmentService |
| standApp   | model         |         |                                             | ServicePermissionService     |
| standApp   | model         |         | device.ts                                   | DeviceStatusService          |
| standApp   | model         |         |                                             | ServicesManagementService    |
| standApp   | model         |         |                                             | DeviceManagementService      |
| standApp   | model         |         | solution.ts                                 | SolutionPermissionMngService |
| standApp   | model         |         | notification.service.ts                     | AreaNorificationService      |
| standApp   | model         |         |                                             | DeviceNotificationService    |
| standApp   | model         |         |                                             | CommonNotificationService    |
| standApp   | model         |         |                                             | ErrorService                 |
| standApp   | model         |         | native.service.ts                           |                              |
| standApp   | model         |         | linkage.service.ts                          |                              |
| standApp   | model         |         | app.service.ts                              | AppManagementService         |
| standApp   | native        |         | native-android.ts                           |                              |
| standApp   | native        |         | native-base.ts                              |                              |
| standApp   | native        |         | native-cooperation.ts                       |                              |
| standApp   | native        |         | native-ios.ts                               |                              |
| standApp   | native        |         | native-stub.ts                              |                              |
| standApp   | communication |         | com-outside.ts                              |                              |
| standApp   | communication | cognito | cognito.ts                                  |                              |
| standApp   | communication | http    | API_ErrTest.ts                              |                              |
| standApp   | communication | http    | http-base.ts                                |                              |
| standApp   | communication | http    | http-custom-error-response.ts               |                              |
| standApp   | communication | http    | communication\http\http-encoding.service.ts |                              |
| standApp   | communication | http    | http-error-code.ts                          |                              |
| standApp   | communication | http    | http-local.ts                               |                              |
| standApp   | communication | http    | http.ts                                     |                              |
| standApp   | const         |         | const.ts                                    |                              |
| standApp   | shared        |         | input-constraints.directive.ts              |                              |
| standApp   | shared        |         | prevent-multitouch-pull.directive.ts        |                              |
| standApp   | shared        |         | shared.module.ts                            |                              |
| standApp   | shared        |         | swipe-horizontal.directive.ts               |                              |
| standApp   | shared        |         | swipeback.directive.ts                      |                              |
| standApp   | utility       |         | app-util.ts                                 |                              |
| standApp   | utility       |         | byte.ts                                     |                              |
| standApp   | utility       |         | crypto.ts                                   |                              |
| standApp   | utility       |         | event-dispatcher.ts                         |                              |
| standApp   | utility       |         | http-interceptor.ts                         |                              |
| standApp   | utility       |         | log-base.ts                                 |                              |
| standApp   | utility       |         | log.ts                                      |                              |
| standApp   | utility       |         | scrollbar.service.ts                        |                              |
| standApp   | utility       |         | services_uuid.service.ts                    |                              |
| standApp   | utility       |         | timer.services.ts                           |                              |


^[ \t]*## 引数[ \t]*\r?\n[\s\S]*?^[ \t]*## メモ[ \t]*$

npx redocly build-docs api.yaml
npx @redocly/cli build-docs api.yaml -o output/IF仕様書_standApp.html

        > ⚠️ **注意**  
        > このエンドポイントはテスト環境でのみ動作します。

        >  **注意**  
        > このエンドポイントはテスト環境でのみ動作します。


          - Observable &lt; AreaListResponse &gt;

/Users/js2ymmks/github/myCurrentWork/Document/MarkdownDocument - 0918/_apiReference/apiReference/api-copy.yaml