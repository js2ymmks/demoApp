# API戻り値一覧

## COM_VW00

### 戻り値

なし

## COM_VW01

### 戻り値

なし

## COM_VW02

### 戻り値

ダイアログ非表示タイミング時に以下の情報を返す  
`1` 確認ダイアログ　⇒　処理あり/なし(boolean)  
`2` 入力ダイアログ　⇒　入力データ/undefined (string)   
`3` チェックボックス式選択ダイアログ ⇒ 選択ナンバー/-1 (Array<number>)  
`4` ラジオボタン式選択ダイアログ ⇒ 選択ナンバー/-1 (number)

## COM_VW03

### 戻り値

- Observable<string | undefined | Array<number> | -1>
- ダイアログ非表示タイミング時に以下の情報を返す  
  `1` 時間ピッカー ⇒ 選択値の文字列/undefined (string) 選択値の文字列の例：”1:45"  
  `2` 時間以外のピッカー ⇒ 選択ナンバー/-1 (number)

## COM_NS00

### 戻り値

なし

## COM_NS01

### 戻り値

- アプリケーション (string)

## COM_NS02

### 戻り値

- アプリケーション (string)

## COM_NS03

### 戻り値

なし

## COM_NS04

### 戻り値

なし

## COM_NS05

### 戻り値

なし

## COM_NS06

### 戻り値

- ネットワーク接続状態を返す。  
`true` 接続中  
`false` 途絶中

## COM_NS07

### 戻り値

- 読み取りデータ(string) / エラー情報

## COM_NS08

### 戻り値

エラー情報

## COM_NS09

### 戻り値

デバイストークン(string) / エラー

## COM_NS10

### 戻り値

- バージョン更新有無(boolean) / エラー

## COM_NS11

### 戻り値

なし

## COM_NS13

### 戻り値

- 存在する / 存在しない

## COM_NS14

### 戻り値

- 開始成功 / 開始失敗

## COM_NS15

### 戻り値

- 停止成功 / 停止失敗

## COM_NS16

### 戻り値

- 位置情報IDとGeofence実行状態のリスト　[{位置ID, 緯度, 経度, 半径}]

## COM_NS17

### 戻り値

- 権限あり / 権限なし

## COM_NS18

### 戻り値

- 現在位置情報 {latitude, longitude, altitude, accuracy, altitudeAccuracy, heading, speed, timestamp}

## COM_NS20

### 戻り値

- なし

## COM_NS21

### 戻り値

- String
- `portrait`  縦方向（ポートレート 肖像画）
- `landscape`  横方向（ランドスケープ 風景画）※ホームボタン右側  

## COM_NS22

### 戻り値

リクエスト成功

## COM_NS23

### 戻り値

- バージョン (string)

## COM_LS00

### 戻り値

なし

## COM_LS01

### 戻り値

なし

## COM_LS02

### 戻り値

- エラー情報(string)

## COM_LS03

### 戻り値

- 取得した値

## COM_PF00

### 戻り値

- Observable&lt;AreaListResponse&gt;
- 物件一覧取得成功時：
  - オーナーゲスト権限確認結果、管理者変更あり時：exception (LogoutException)
  - オーナーゲスト権限確認結果、管理者変更なし時：物件一覧取得のレスポンスボディ
  - オーナーゲスト権限確認なし時：物件一覧取得のレスポンスボディ
- 物件一覧取得失敗時： 
  - exception  APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照        ## 制約・注意事項

## COM_PF002

### 戻り値

Observable&lt;AreaListResponse&gt;  
- 物件一覧取得成功時：  
  - オーナーゲスト権限確認結果、管理者変更あり時：exception (LogoutException/returnAreaPermissionChangeException)
  - オーナーゲスト権限確認結果、管理者変更なし時：物件一覧取得のレスポンスボディ
  - オーナーゲスト権限確認なし時：物件一覧取得のレスポンスボディ
- 物件一覧取得失敗時：  
  - exception  APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照        ## 制約・注意事項

## COM_PF27

### 戻り値

- Observable&lt;unknown&gt;
  - 物件情報更新成功時：成功
  - 物件情報更新失敗時：exception   APIエラー処理仕様書_standApp.xlsxシート「 1. エラー処理(共通PF)」参照			

## COM_PF01

### 戻り値

Observable&lt;UserInformationListInterface&gt;  
- 物件ユーザー情報一覧取得成功時：物件ユーザー情報一覧取得のレスポンスボディ
- 物件ユーザー情報一覧取得失敗時：exception APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照        ## 制約・注意事項

## COM_PF02

### 戻り値

（記載なし）

## COM_PF03

### 戻り値

Observable&lt;Array&lt;AreaServices&gt;&gt;  
- 物件サービス一覧取得成功時：物件サービス一覧取得のレスポンスボディ
- 物件サービス一覧取得失敗時：exception  APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照

## COM_PF04

### 戻り値

```typescript
GetServiceRegistrationResponse {
selectedServiceId: string | null;  // サービス登録有無
serviceEnable: boolean;            // サービス有効無効
validService: boolean;             // サービスID
}
```

## COM_PF05

### 戻り値

Array&lt;AreaServiceAction[keyof AreaServiceAction] | AreaServiceEvent[keyof AreaServiceEvent] |  ''&gt;  
Key値のリスト

## COM_PF06

### 戻り値

Observable&lt;unknown&gt;  
物件サービス管理追加成功時：成功  
物件サービス管理追加失敗時：exception APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照

## COM_PF09

### 戻り値

検索条件のリスト  
- string key1: 取得したいオブジェクトの検索key
- any key2: 取得したいオブジェクトの検索keyの値

## COM_PF07

### 戻り値

Observable&lt;AreaServiceManagementListResponse&gt;  
- 物件サービス管理一覧取得成功時：物件サービス管理一覧取得のレスポンスボディ
- 物件サービス管理一覧取得失敗時：exception  APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照        ## 制約・注意事項  

## COM_PF08

### 戻り値

Observable&lt;'OK'&gt;
- 物件サービス管理一覧に対象のサービス管理IDが存在する場合：結果(OK)
- 物件サービス管理一覧に対象のサービス管理IDが存在しない場合：
  - ゲストフラグ=trueの場合：なし (遷移元MyMU画面へ遷移するため)
  - ゲストフラグ=falseの場合：結果(OK)
- 物件サービス管理一覧取得/物件サービス管理追加失敗時：exception   APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照

## COM_PF0A

### 戻り値

Observable&lt;{}&gt;  
  - 物件機器削除成功時：成功
  - 物件機器削除失敗時：exception   APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照

## COM_PF10

### 戻り値

Observable&lt;GetDeviceInformationReturnValue&gt;  
- 機器状態取得成功時：機器状態取得のレスポンスボディとアダプター接続状態
- 機器状態取得失敗時：exception   APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照

## COM_PF11

### 戻り値

Observable&lt;unknown&gt;  
- 機器状態変更成功時：成功
- 機器状態変更失敗時：exception APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照

## COM_PF12

### 戻り値

Observable&lt;unknown&gt;  
- 機器状態送信要求成功時：成功
- 機器状態送信要求失敗時：exception APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照

## COM_PF20

### 戻り値

Observable&lt;unknown&gt;  
- サービス登録成功時：成功
- サービス登録失敗時：exception   APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照

## COM_PF21

### 戻り値

Observable&lt;unknown&gt;  
- サービス更新成功時：成功
- サービス更新失敗時：exception APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照

## COM_PF22

### 戻り値

Observable&lt;unknown&gt;  
- サービス実行成功時： 成功
- サービス実行失敗時： exception APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照

## COM_PF23

### 戻り値

Observable&lt;unknown&gt;  
- サービステンプレート実行成功時： 成功
- サービステンプレート実行失敗時： exception  APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照

## COM_DEV01

### 戻り値

Observable&lt;UniqueDataInterface&gt;
- データ取得成功時：機器管理情報(機器種別が指定された場合は、対象の機器管理情報のみ抽出した結果)  
返却データは下記記参照(参照元ファイル：MyMU_データ構造の定義.xlsx(svn-r11700))。
- データ取得失敗時：exception(ApplicationException)  
| データ名 | jsonプロパティ | 型 | 説明 |
| :--- | :--- | :--- | :--- |
| アプリ番号 | `appId` | number | アプリ番号 |
| アプリ名の略称 | `appName` | string | アプリ名の略称 |
| アプリ名称 | `appDisplayName` | string | アプリの公式名称 |
| Googleストア URL（任意） | `appGoogleStoreUrl` | string | GoogleストアにあるアプリのURL |
| Appleストア URL（任意） | `appAppleStoreUrl` | string | AppleストアにあるアプリのURL |
| 機器の基本情報 | `deviceInfo` | object | ＜デバイス情報＞ |
| 機器名 | `name` | string | 文字列 |
| 機器アイコン | `icon` | string | MyMUにあるデバイスアイコンの相対パスを設定する |
| 機器イメージ | `image` | string | MyMUにあるディスプレイイメージの相対パスを設定する |
| 機器種別名称 | `deviceType` | string | 機器種別の文字列 |
| 機器登録の上限台数 | `maxDeviceNumber` | number | ホーム画面に表示するの上限台数 |
| 機器登録後ホームに戻るフラグ | `isEnableGoMyMUHome` | boolean | 機器登録完了画面後の遷移先 |
| アダプター⇔クラウド通信異常の閾値 | `devConTimeOutThresh` | number | 通信異常の閾値（単位は秒） |
| CME製品登録（#13517） | `cmeDevice` | boolean | CME製品登録ダイアログの表示要否 |
| 機器操作対象 | `deviceAction` | string | シーン／スケジュールの操作対象情報 |
| 法顧保守対象（#13668） | `maintenanceDevice` | boolean | 法顧保守サービス登録の対象機器 |
| アダプターの機器情報 | `adapterInfo` | object | アダプタ情報 |
| アダプターの種別名称 | `name` | string | アダプタの機器名称 |
| アダプターの機器アイコン | `icon` | string | MyMUにあるアダプターアイコンの相対パスを設定する |
| アダプターのUDP応答機器種別 | `type` | string | アダプター種別番号（16進数、4桁） |
| IoTアダプターのFW更新 | `isEnableFWUpdate` | boolean | IoTアダプターのFW更新仕様の有無を設定する |
| アダプターの再起動 | `isEnableResetAdapter` | boolean | アダプターの再起動仕様の有無を設定する |
| RACアダプタFW更新 | `isEnableFWUpdateRAC` | boolean | RACアダプタのFW更新仕様の有無を設定する |
| APモード登録（#12803） | `isEnableAPMode` | boolean | APモードでの機器登録の対象機器 |
| 登録機器一覧 | `registerMenuUrl` | object | 機器個別情報 |
| 取扱説明書 | `isEnableManualUrl` | string | 機器の取扱説明書 URL |
| よくある質問 | `isEnableFAQUrl` | string | 機器のよくある質問 URL |
| RAC室外機設定 | `isEnableInsideRemote` | boolean | RAC用の室内機の表示／非表示フラグ |
| 修理のご相談 | `repairUrl` | string | 修理のご相談WEBサイトのURL |          

## COM_PF24

### 戻り値

Observable&lt;unknown&gt;  
- サービス利用禁止指定成功時: 成功
- サービス利用禁止指定失敗時: exception APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照

## COM_PF25

### 戻り値

Observable&lt;unknown&gt;  
- サービス利用禁止指定解除成功時: 成功
- サービス利用禁止指定解除失敗時: exception APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照

## COM_PF26

### 戻り値

Observable&lt;ServiceUsageAuthorityConfirmation&gt; 
- サービス利用権限確認成功時：サービス利用権限確認のレスポンスボディ
- サービス利用権限確認失敗時：exception   APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照

## COM_MY01

### 戻り値

Observable&lt;unknown&gt;  
- ソリューション権限一覧取得成功時：ソリューション権限一覧取得のレスポンスボディ
- ソリューション権限一覧取得失敗時：exception APIエラー処理仕様書_standApp.xlsx シート「 2. エラー処理(MyMU)」参照

## COM_PF90

### 戻り値

- GET TEXTメソッド実行成功時：  
  - 結果(OK) ※バージョン更新有の場合は遷移元MyMU画面へ遷移するため、バージョン更新無しの場合のみ戻り値が返る  
- GET TEXTメソッド実行失敗時：  
  - exception (ApplicationException)

## COM_PF91

### 戻り値

Observable&lt;never&gt;  
- exception 
  - APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照														

## COM_PF92

### 戻り値

Observable&lt;never&gt;  
- exception 
  - APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照

## COM_PF93

### 戻り値

Observable&lt;never&gt;  
- exception 
  - APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照

## COM_PF94

### 戻り値

Observable&lt;never&gt;  
- exception 
  - APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照

## COM_PF95

### 戻り値

Observable&lt;never&gt;  
- exception 
  - APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照

## COM_PF96

### 戻り値

なし

## COM_PF97

### 戻り値

Observable&lt;never&gt;  
- exception 
  - APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照														

## COM_PF98

### 戻り値

Observable&lt;never&gt;  
- exception 
  - APIエラー処理仕様書_standApp.xlsx シート「 1. エラー処理(共通PF)」参照														

## COM_APP01

### 戻り値

Observable&lt;GetDeviceInformationReturnValue&gt;
- データ取得成功時：アプリ管理情報(アプリIDが指定された場合は、対象のアプリ管理情報のみ抽出した結果)  
返却データは MyMU_データ構造の定義.xlsx 参照
- データ取得失敗時：exception(ApplicationException)														

## COM_CO00

### 戻り値

成功時： (キャッシュファイル生成=trueの場合)ファイルパス(左記以外の場合)レスポンスボディ、失敗時： 応答データ、例外発生時： エラー情報  
※ キャッシュファイルの生成に失敗した場合(過年度MyMU使用時のネイティブ関数実行エラーも含む)、エラー情報としてcode=0, message=File Create Failed.を返却する。

## COM_CO01

### 戻り値

成功時： bodyデータ、失敗時： 応答データ、例外発生時： エラー情報														

## COM_CO02

### 戻り値

成功時： bodyデータ、失敗時： 応答データ、例外発生時： エラー情報

## COM_CO03

### 戻り値

成功時： bodyデータ、失敗時： 応答データ、例外発生時： エラー情報

## COM_CO04

### 戻り値

成功時： bodyデータ、失敗時： 応答データ、例外発生時： エラー情報

## COM_CO06

### 戻り値

リクエストURL、エンコードエラー

## COM_AU00

### 戻り値

成功時： `ok`、失敗時： エラー情報(code=401)

## COM_AU01

### 戻り値

成功時： `ok`、失敗時： エラー情報(code=401)

## COM_AU10

### 戻り値

成功時： `ok`、失敗時： エラー情報(code=401)

## COM_AU12

### 戻り値

成功時： `ok`、失敗時： エラー情報(code=500またはCognito RevokeTokenAPIの応答)

## COM_MES00

### 戻り値

リクエスト種別＝ネイティブ処理要求の場合のみ  
- 成功時： ネイティブ応答データ、失敗時/例外発生時： エラー情報

## COM_MES01

### 戻り値

なし

## COM_UT00

### 戻り値

インターバルナンバー(number)

## COM_UT01

### 戻り値

なし

## COM_UT02

### 戻り値

なし

## COM_UT03

### 戻り値

なし

## COM_UT04

### 戻り値

なし

## COM_UT05

### 戻り値

なし

## COM_UT06

### 戻り値

なし

## COM_UT07

### 戻り値

なし

## COM_UT08

### 戻り値

なし

## COM_UT09

### 戻り値

なし

## COM_UT10

### 戻り値

なし

## COM_UT20

### 戻り値

変換成功時： 変換後データ(string型)、変換失敗時： エラー情報
