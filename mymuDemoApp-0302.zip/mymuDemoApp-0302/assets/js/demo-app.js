/******************************************
 * マッピングオブジェクト
 ******************************************/
// 機器名、アイコンマスター
const DEVICE_MASTER = {
  "rac-1": {
    label: "リビングのエアコン",
    icon: "../assets/img/icon_AC_40pt.svg",
    settings: "../device-settings-rac/",
    on: "運転開始",
    off: "運転停止",
  },
  "rac-2": {
    label: "寝室のエアコン",
    icon: "../assets/img/icon_AC_40pt.svg",
    settings: "../device-settings-rac/",
    on: "運転開始",
    off: "運転停止",
  },
  "eq": {
    label: "給湯機",
    icon: "../assets/img/product_Icon_EQ_40pt.svg",
    settings: "../device-settings-eq/",
    on: "ふろ自動開始",
    off: "ふろ自動停止",
  },
};

// 製品カテゴリマスター
const CATEGORY_MASTER = {
  "rac-1": "rac",
  "rac-2": "rac",
  "eq": "eq",
};

// アクション マスター
const ACTION_MASTER = {
  devices: {
    "rac-1": {
      icon: "../assets/img/icon_AC_40pt.svg",
      url: "../device-settings-rac/",
    },
    "rac-2": {
      icon: "../assets/img/icon_AC_40pt.svg",
      url: "../device-settings-rac/",
    },
    "eq": {
      icon: "../assets/img/product_Icon_EQ_40pt.svg",
      url: "../device-settings-eq/",
    },
  },
  notify: {
    icon: "../assets/img/icon_Notifications_40.svg",
    url: "../select-notice/",
  },
};

// シーンマスター
const SCENE_MASTER = {
  allOff: {
    label: "外出一括オフ",
    icon: "../assets/img/scene_off_40_40.svg",
    url: "../setup-scene/"
  },
  sleep: {
    label: "就寝",
    icon: "../assets/img/scene_sleep.svg",
    url: "../setup-scene/"
  },
  returnWinter: {
    label: "冬の帰宅",
    icon: "../assets/img/scene-icon-returning-home-winter.svg",
    url: "../setup-scene/"
  }
};

// トリガーイベント条件マスター
const TRIGGER_EVENT_DESCRIPTION_MASTER = {
  "schedule": "設定した時刻に指定されたアクションを実行します。繰り返し設定を行わない場合、１度だけ指定されたアクションを実行します。",
  "location": "選択された家電シェアユーザーのうちの1名以上が位置条件を満たした場合に、指定されたアクションを実行します。",
  "devices": "機器の運転状態を元に、指定されたアクションを実行します。トリガーイベントとして指定できる機器の運転状態は1つです。",
};

// トリガーイベントセクション表示／非表示マスター
const TRIGGER_EVENT_SECTION_MASTER = {
  "schedule": "schedule-section",
  "location": "location-section",
  "devices": "devices-section",
}

/******************************************
 * グローバル変数
 ******************************************/
const AppState = {
  deletingCard: null,
  deletingType: null,
  deleteContext: null,
  editActionId: null,
  selectedScene: null,
  isEdited: false
};

// アクションセレクトURLマスター
const ACTION_SELECT_URL = {
  scene: "../select-scene/",
  devices: "../select-device/",
  notify: "../select-notice/",
};

/******************************************
 * ユーティリティ
 ******************************************/
// JSON更新（ブラケット版）
const setJsonValue = (propertyPath, value) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : {};
  } catch (e) {
    data = {};
  }

  // ブラケット記法をドット記法に変換
  // "buttons[0].label" → "buttons.0.label"
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let i = 0; i < props.length - 1; i++) {
    const prop = props[i];

    // 数字 → 配列アクセス
    const index = Number(prop);
    const isIndex = !isNaN(index);

    if (isIndex) {
      if (!Array.isArray(current)) {
        current = [];
      }
      if (current[index] === undefined) {
        current[index] = {};
      }
      current = current[index];
    } else {
      if (!current[prop] || typeof current[prop] !== "object") {
        current[prop] = {};
      }
      current = current[prop];
    }
  }

  // 最終プロパティ
  const lastProp = props[props.length - 1];
  const lastIndex = Number(lastProp);

  if (!isNaN(lastIndex)) {
    if (!Array.isArray(current)) current = [];
    current[lastIndex] = value;
  } else {
    current[lastProp] = value;
  }

  // 確認用ログ
  sessionStorage.setItem("appData", JSON.stringify(data));
  // console.log(data.automation.items["auto-1"].actions[0]);
};

// JJSON取得（ブラケット版）
const getJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }

  if (!data) return undefined;

  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }

  return current;
};

// JSON取得（ブラケット版）ヘッダー用
const getHeaderJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("headerSet");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }

  if (!data) return undefined;

  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }

  return current;
};

/******************************************
 * ユーティリティ：ヘッダーのアイテムを設定する
 * 対象：各画面のヘッダー
 * アクション：ヘッダー要素の初期化
 ******************************************/
function initHeader() {
  // ==============================
  // DOM取得
  // ==============================
  const headerDom = {
    leftBtn: document.getElementById("headerLeftBtn"),
    title: document.getElementById("headerTitle"),
    rightBtn: document.getElementById("headerRightBtn"),
  };

  if (!headerDom.leftBtn || !headerDom.title || !headerDom.rightBtn) {
    console.warn("header DOM がまだ準備できていません");
    return;
  }

  // ==============================
  // headerSetBodyKeyキー取得
  // ==============================
  const currentHeaderSetKey = document.body.dataset.appHeaderSet;
  if (!currentHeaderSetKey) {
    console.warn("data-app-header-set が指定されていません");
    return;
  }

  // ==============================
  // headerSetJson 取得
  // ==============================
  const headerSetJson = getHeaderJsonValue(`${currentHeaderSetKey}`);
  if (!headerSetJson) {
    console.warn(`headerSet.${currentHeaderSetKey} が見つかりません`);
    return;
  }

  // ==============================
  // タイトル
  // ==============================
  headerDom.title.innerHTML = headerSetJson.title;

  // ==============================
  // 左ボタン
  // ==============================
  renderLeftButton(headerSetJson.left?.type, headerDom.leftBtn);
  headerDom.leftBtn.onclick = () =>
    handleHeaderLeftAction(headerSetJson.left?.type);

  // ==============================
  // 右ボタン
  // ==============================
  renderRightButton(headerSetJson.right, headerDom.rightBtn);
  headerDom.rightBtn.onclick = () =>
    handleHeaderRightAction(headerSetJson.right?.action);
}

// ==============================
// 左ボタン描画
// ==============================
// リセット
function renderLeftButton(type, btn) {
  btn.innerHTML = "";
  btn.classList.remove("d-none");
  // アイコン設定
  switch (type) {
    case "back":
      btn.innerHTML = '<i class="bi bi-chevron-left"></i>';
      break;
    case "drawer":
      btn.innerHTML = '<i class="bi bi-list"></i>';
      break;
    default:
      btn.classList.add("d-none");
  }
}

// ==============================
// 左アクション処理
// ==============================
function handleHeaderLeftAction(type) {
  switch (type) {
    case "back":
      // document.addEventListener("DOMContentLoaded", syncToggleFromStorage);
      // window.addEventListener("pageshow", syncToggleFromStorage);
      window.history.back();
      break;

    case "drawer":
      const bsOffcanvas = new bootstrap.Offcanvas("#appOffcanvas");
      bsOffcanvas.show();
      break;
  }
}

// ==============================
// 右ボタン描画
// ==============================
function renderRightButton(headerSetJsonRight, headerDomRight) {
  // 右ボタンのプロパティチェック
  if (!headerSetJsonRight || !headerSetJsonRight.visible) {
    headerDomRight.classList.add("d-none");
    headerDomRight.onclick = null;
    return;
  }

  // 表示
  headerDomRight.classList.remove("d-none");

  // text / icon / svg すべて対応
  headerDomRight.innerHTML = headerSetJsonRight.text || "";

  // クリック処理（あれば）
  headerDomRight.onclick = () => {
    handleHeaderRightAction(headerSetJsonRight.action, headerSetJsonRight);
  };
}

// ==============================
// 右アクション処理（完了/done | 設定/set | リンク/link | 編集/edit | 決定/ok）
// ==============================
function handleHeaderRightAction(action) {
  switch (action) {
    // JSON更新後、前の画面へ戻る
    case "done":
      window.history.back();
      break;

    // 電気代チェック画面へ遷移
    case "set":
      window.history.back();
      break;

    // 指定リンクへ遷移
    case "link":
      const rightBtn = document.getElementById("headerRightBtn");
      const target = getJsonValue(
        "headerSet.electricityBillCheck.right.target",
      );
      if (rightBtn) {
        rightBtn.href = target;
      }
      break;

    // 現在の画面が編集可能になるtouch-airflow-back
    case "edit":
      window.history.back();
      break;

    // RACデモアプリ用
    case "ok":
      window.history.back();
      break;

    // アラート表示schedule-done
    case "alert":
      alert(
        "デモアプリではこのボタンは操作できません。＜ ボタンで戻ってください",
      );
      break;

    // スケジュール画面で完了
    case "schedule-done":
      setJsonValue("isAutoMationSetDone", true);
      window.location.href = "../schedule/";
      break;

    // アラート表示
    case "touch-airflow-back":
      alert(
        "風向を設定しました。やり直す場合は画像をダブルタップしてください。",
      );
      break;
  }
}

/******************************************
 * イニシャライズ：フッター
 * 対象：フッターのアイコン
 * アクション：JSON更新(currentPage)
 ******************************************/
const initFooterButtons = () => {
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      setJsonValue("currentPage", btn.dataset.appPage);
    });
  });
};

/******************************************
 * レンダリング：フッターアイコン表示更新
 * 対象：フッターのアイコン
 * アクション：アクティブページのフッターアイコンの表示更新
 ******************************************/
const initFooterButtonsState = () => {
  // フッターが存在しない画面
  const footerElement = document.getElementsByClassName("content-footer")[0];
  if (footerElement.className.includes("d-none")) {
    return;
  }
  // スタイルリセット
  const currentPage = getJsonValue("currentPage");
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.classList.remove("active");
  });
  // レンダリング
  footerButtons.forEach((btn) => {
    const page = btn.dataset.appPage;
    if (page === currentPage) {
      btn.classList.add("active");
    }
  });
};

/******************************************
 * ユーティリティ：全画面
 * 対象：トグルスイッチ（button要素内にあるスイッチ）
 * アクション：クリック時の伝播を防ぐ
 ******************************************/
document.querySelectorAll(".form-check-input").forEach((toggle) => {
  toggle.addEventListener("click", (e) => {
    e.stopPropagation();
  });
});

/******************************************
 * ユーティリティ：全画面
 * 対象：button要素、スイッチ要素
 * アクション：「デモアプリではこのボタンは操作できません。」を表示する
 ******************************************/
document.addEventListener("click", (e) => {
  const target = e.target.closest(".demo-toggle-alert");
  if (!target) return;

  // 現在の状態を保持（クリック後の状態）
  const currentChecked = target.checked;
  e.stopPropagation();

  alert("デモアプリではこのボタンは操作できません。");

  // 元の状態に戻す
  target.checked = !currentChecked;
});

/******************************************
 * ユーティリティ：モーダルフォーカス解除
 * 対象：modal.html のモーダル
 * アクション：モーダルをクローズ後のフォーカス解除
 ******************************************/
window.addEventListener("hide.bs.modal", () => {
  document.activeElement.blur();
});

/******************************************
 * ユーティリティ：モーダル表示
 * 対象：modal.txt のモーダル
 * アクション：モーダルを表示する
 ******************************************/
function showModal(modalId) {
  const modalEl = document.getElementById(modalId);
  if (!modalEl) return;

  const modal = new bootstrap.Modal(modalEl);
  modal.show();
}

/******************************************
 * テンプレートファイル読み込み
 ******************************************/
document.addEventListener("DOMContentLoaded", async () => {
  try {
    const [alert, header, footer, modal, drawer] = await Promise.all([
      fetch("../../partials/alert.txt").then((r) => r.text()),
      fetch("../../partials/header.txt").then((r) => r.text()),
      fetch("../../partials/footer.txt").then((r) => r.text()),
      fetch("../../partials/modal.txt").then((r) => r.text()),
      fetch("../../partials/drawer-menu.txt").then((r) => r.text()),
    ]);

    document.querySelector(".content-alert").innerHTML = alert;
    document.querySelector(".content-header").innerHTML = header;
    document.querySelector(".content-footer").innerHTML = footer;
    document.querySelector(".content-modal").innerHTML = modal;
    document.querySelector(".content-drawer").innerHTML = drawer;
    initUI();
  } catch (err) {
    console.error("Failed to load partials:", err);
  }
});

function initUI() {
  // モーダル
  // initModalDriveModeSelectButtons();
  initFooterButtons();
  initFooterButtonsState();
  initHeader();
  // 基本機能 画面
  // renderDriveModeSwitchBtnAndSettingPanelOperation();
}

/******************************************
 * レンダリング関数
 * オートメーション編集画面
 ******************************************/
// オートメーション名を読み込む
const renderAutomationName = (entryAutoId) => {
  const el = document.getElementById("autoName");
  const automationName = getJsonValue(`${entryAutoId}.name`);
  if (!el) return;
  const name = automationName?.trim();
  if (name) {
    el.textContent = name;
  } else {
    el.textContent = "オートメーション名（未設定）";
  }
};

// トリガーイベントボタンの状態を読み込む
const renderTriggerButtons = (entryTrigger) => {
  const targetElements = document.querySelectorAll(".js-trigger-event-btn");
  targetElements.forEach((el) => {
    const key = el.dataset.appKey;
    if (key === entryTrigger) {
      el.classList.add("active");
      el.setAttribute("aria-pressed", "true");
    } else {
      el.classList.remove("active");
      el.setAttribute("aria-pressed", "false");
    }
  });
};

// トリガーイベント条件（文章）の表示制御
const renderTriggerDescription = (entryTrigger) => {
  const targetElement = document.querySelector(".trigger-section");
  targetElement.innerText = TRIGGER_EVENT_DESCRIPTION_MASTER[entryTrigger];
};

// 時間を代入
const renderScheduleStartTime = (entryAutoId) => {
  const el = document.getElementById("autoStartTime");
  const automationTime = getJsonValue(`${entryAutoId}.triggers.schedule.time`);

  if (!el) return;
  const time = automationTime?.trim();
  if (time) {
    el.textContent = time;
  } else {
    el.textContent = "開始時間（未設定）";
  }
};

// トリガーイベントセクションの表示／非表示
const renderTriggerEventSection = (entryAutoId, entryTrigger) => {
  document
    .querySelectorAll(".schedule-section, .location-section, .devices-section")
    .forEach(el => el.style.display = "none");

  const threshold = getJsonValue(`${entryAutoId}.triggers.devices.threshold`);
  const addBtn = document.getElementById("addDeviceButton");
  const cardBtn = document.querySelector(".trigger-card-button");

  if (!(entryTrigger === "devices")) {
    const key = TRIGGER_EVENT_SECTION_MASTER[entryTrigger];
    const target = document.querySelector(`.${key}`);
    if (target) target.style.display = "";
  }

  if (entryTrigger === "devices") {
    if (!threshold) {
      addBtn.style.display = "block";
      cardBtn ? cardBtn.style.display = "none" : null;
    } else {
      addBtn.style.display = "none";
      cardBtn.style.display = "block";
    }
  }
};

// 曜日を代入
const renderScheduleDays = (entryAutoId) => {
  const targetElements = document.querySelectorAll(".day-of-the-week");
  if (!targetElements.length) return;

  // schedule.days を安全に取得
  const days = getJsonValue(`${entryAutoId}.triggers.schedule.days`) ?? [];

  targetElements.forEach((el) => {
    const day = el.dataset.appScheduleDay;
    const isActive = days.includes(day);

    el.classList.toggle("active", isActive);
    el.setAttribute("aria-pressed", String(isActive));
  });
};

// 曜日説明文を代入
function renderScheduleDescription(entryAutoId) {
  const scheduleTrigger = getJsonValue(`${entryAutoId}.triggers.schedule`);
  if (!scheduleTrigger) return;

  const days = scheduleTrigger.days ?? [];
  const description = createScheduleDescription(days);

  const descriptionElement = document.getElementById("scheduleText");
  if (!descriptionElement) return;

  descriptionElement.textContent = description;
}

// 通知するユーザー（家電シェアユーザー）のチェックボックスを選択する
const renderLocationUsers = (entryAutoId) => {
  // location-section 内の checkbox を取得
  const checkboxes = document.querySelectorAll('.location-section input[type="checkbox"]');
  if (!checkboxes.length) return;

  // location trigger を取得
  const locationTrigger = getJsonValue(`${entryAutoId}.triggers.location`);
  if (!locationTrigger) return;

  const selectedUsers = locationTrigger.users || [];
  checkboxes.forEach((checkbox) => {
    const userName = checkbox.value;
    // JSON に含まれていればチェックON
    checkbox.checked = selectedUsers.includes(userName);
  });
};

// 位置条件のイベントを代入（自宅に近づいたとき／自宅から離れたとき）
const renderLocationCondition = (entryAutoId) => {
  const selectedCondition = getJsonValue(`${entryAutoId}.triggers.location.event`);
  // UI更新用の関数
  function updateLocationConditionUI(conditionValue) {
    const targetElements = document.querySelectorAll(".js-location-condition");
    targetElements.forEach((el) => {
      const condition = el.dataset.appLocationCondition;
      if (condition === conditionValue) {
        el.setAttribute("aria-pressed", "true");
        el.classList.add("active");
      } else {
        el.setAttribute("aria-pressed", "false");
        el.classList.remove("active");
      }
    });
  }
  updateLocationConditionUI(selectedCondition);
}

// アクションカードを読み込む
const renderActionCards = (entryAutoId) => {
}

// オートメーション画面でアクションを読み込む
function renderNewAutomationCard() {

  const list = document.getElementById("automationList");
  if (!list) return;

  /* すでに生成済みなら終了 */
  if (list.querySelector('[data-app-key="new"]')) return;

  const newAuto = getJsonValue("new");
  if (!newAuto) return;

  const template = document.querySelector(".js-automation-template");
  if (!template) return;

  const clone = template.cloneNode(true);

  clone.style.display = "block";
  clone.classList.remove("js-automation-template");
  clone.classList.add("js-edit-automation-btn");

  clone.dataset.appKey = "new";

  /* ---------- オートメーション名 ---------- */

  const nameEl = clone.querySelector(".automationName");
  if (nameEl) {
    nameEl.textContent = newAuto.name ?? "新しいオートメーション";
  }

  /* ---------- トリガー ---------- */

  const triggerIcon = clone.querySelector(".triggerIcon");
  const triggerCondition = clone.querySelector(".triggerCondition");

  const trigger = newAuto.entryTrigger;

  if (trigger === "schedule") {

    if (triggerIcon) {
      triggerIcon.src = "../assets/img/icon-clock.svg";
    }

    const time = newAuto.triggers?.schedule?.time ?? "";
    const days = newAuto.triggers?.schedule?.days ?? [];

    const text = createScheduleDescription(days);

    if (triggerCondition) {
      triggerCondition.textContent = `${time} ${text}`;
    }

  }

  if (trigger === "devices") {

    if (triggerIcon) {
      triggerIcon.src = "../assets/img/icon_apps_40.svg";
    }

    const device = newAuto.triggers?.devices;

    if (triggerCondition && device) {
      triggerCondition.textContent =
        `${device.condition} 温度${device.threshold}℃`;
    }

  }

  if (trigger === "location") {

    if (triggerIcon) {
      triggerIcon.src = "../assets/img/icon_GPS_40.svg";
    }

    const event = newAuto.triggers?.location?.event;

    if (triggerCondition) {
      triggerCondition.textContent =
        event === "close"
          ? "自宅に近づいたとき"
          : "自宅から離れたとき";
    }

  }

  /* ---------- アクション ---------- */

  const actionIcon = clone.querySelector(".actionIcon");

  const action = newAuto.actions?.[0];

  if (action && actionIcon) {

    if (action.type === "devices") {
      actionIcon.src = DEVICE_MASTER[action.id]?.icon ?? "";
    }

    if (action.type === "notify") {
      actionIcon.src = ACTION_MASTER.notify.icon;
    }

    if (action.type === "scene") {
      actionIcon.src = SCENE_MASTER[action.id]?.icon ?? "";
    }

  }

  /* ---------- 挿入 ---------- */

  list.style.display = "block";
  list.appendChild(clone);

}

/******************************************
 * レンダリング：オートメーション編集 画面
 * 対象：オートメーション編集 画面
 * アクション：各要素を読み込む
 ******************************************/
// オートメーション編集画面
const renderAutomationEditing = () => {
  const entryAutoId = getJsonValue("entryId");
  const entryTrigger = getJsonValue(`${entryAutoId}.entryTrigger`);
  renderAutomationName(entryAutoId);                // オートメーション名
  createTriggerButton(entryAutoId, entryTrigger);
  renderTriggerSection(entryAutoId, entryTrigger);  // トリガーイベントセクション
  renderActionCards(entryAutoId);                      // アクションカード
  createActionButton(entryAutoId);
}

// トリガーイベントセクションを読み込む（親関数）
const renderTriggerSection = () => {
  const entryAutoId = getJsonValue("entryId");
  const entryTrigger = getJsonValue(`${entryAutoId}.entryTrigger`);
  renderTriggerButtons(entryTrigger); // トリガーイベントボタン
  renderTriggerDescription(entryTrigger); // トリガーイベント条件（文章）
  renderScheduleDays(entryAutoId);         // 曜日（繰り返し）
  renderScheduleDescription(entryAutoId);  // 曜日説明文
  renderScheduleStartTime(entryAutoId);    // 時間
  renderLocationUsers(entryAutoId);        // 通知するユーザー（家電シェアユーザー）
  renderLocationCondition(entryAutoId);    // 位置条件（近づいたとき／離れたとき）
  renderTriggerEventSection(entryAutoId, entryTrigger); // トリガーイベントセクション
};

// EVENT LISTENER（クリックイベント統合）
document.addEventListener("click", (e) => {
  let btn;
  btn = e.target.closest(".js-trigger-event-btn");
  if (btn)  handleTriggerEventClick(btn);

  btn = e.target.closest(".day-of-the-week");
  if (btn)  handleDayOfWeekClick(btn);

  btn = e.target.closest(".js-location-condition");
  if (btn)  handleLocationConditionClick(btn);

  btn = e.target.closest(".js-add-automation");
  if (btn)  handleAddAutomationClick(btn);

  btn = e.target.closest(".js-edit-automation-btn");
  if (btn)  handleCreateCustomAutomationClick(btn);

  btn = e.target.closest(".js-add-action-btn");
  if (btn)  handleAddActionButtonClick(btn);

  btn = e.target.closest(".change-automation-name-btn");
  if (btn)  handleChangeAutomationNameClick(btn);

  btn = e.target.closest(".js-editable");
  if (btn)  markEdited();

  btn = e.target.closest(".js-drive");
  if (btn) handleDriveClick(btn);

  btn = e.target.closest(".js-mode");
  if (btn) handleModeClick(btn);  

});

// トリガーイベントボタンのクリックイベント（スケジュール／位置情報／機器）
function handleTriggerEventClick(btn){
  const key = btn.dataset.appKey;
  const entryAutoId = getJsonValue("entryId");
  setJsonValue(`${entryAutoId}.entryTrigger`, key);
  renderTriggerSection();
}

//　クリックした曜日を渡す
function handleDayOfWeekClick(btn) {
  const entryAutoId = getJsonValue("entryId");
  const day = btn.dataset.appScheduleDay;
  toggleScheduleDay(entryAutoId, day);
}

// 位置条件（自宅に近づいたとき／自宅から離れたとき）のクリックイベント
function handleLocationConditionClick(btn) {
  const entryId = getJsonValue("entryId");
  const condition = btn.dataset.appLocationCondition;
  if (!condition) return;

  // triggers.location が無ければ作る
  let locationTrigger = getJsonValue(`${entryId}.triggers.location`) ?? {};
  locationTrigger.event = condition;
  setJsonValue(`${entryId}.triggers.location`, locationTrigger);
  renderLocationCondition(entryId);

};

// 新規オートメーション画面へ遷移する
function handleAddAutomationClick(btn) {
  window.location.href = "../proposal-automation/";
}

// エントリー用のオートメーションIDをJSONに保存、編集画面へ遷移する
function handleCreateCustomAutomationClick(btn) {
  const key = btn.dataset.appKey;
  setJsonValue("entryId", key);
  window.location.href = "../edit-automation/";
}

// アクション追加のカードボタンをクリック（シーン／機器／通知）
function handleAddActionButtonClick(btn) {
  const section = btn.dataset.appAction;
  const url = ACTION_SELECT_URL[section];
  if (url) {
    window.location.href = url;
  }
}

// オートメーション名変更のテキストボタンをクリック
function handleChangeAutomationNameClick() {
  const entryAutoId = getJsonValue("entryId");
  const automationName = getJsonValue(`${entryAutoId}.name`);
  const modalEl = document.getElementById("automationNameModal");  // モーダル要素
  const modal = bootstrap.Modal.getOrCreateInstance(modalEl);  // モーダル生成
  const inputEl = document.getElementById("scheduleName"); // input要素
  inputEl.value = automationName;// 現在のオートメーション名を表示
  modal.show(); // モーダル表示
}

// 完了ボタンの処理（編集された後、完了ボタンが活性化）
function markEdited() {
  if (AppState.isEdited) return;

  console.log("markEdited called");

  AppState.isEdited = true;

  const headerBtn = document.getElementById("headerRightBtn");
  if (!headerBtn) return;

  headerBtn.disabled = false;
  headerBtn.classList.remove("disabled");
  headerBtn.classList.add("active");
};

// エアコン・給湯機設定画面のクリックイベント（運転）
function handleDriveClick(btn){
  const drive = btn.dataset.appDrive;
  const entryId = getJsonValue("entryId");
  const actionId = getJsonValue("editActionId");
  const actions = getJsonValue(`${entryId}.actions`) ?? [];
  const action = actions.find(a => a.actionId === actionId);
  if(!action) return;

  /* JSON保存 */
  action.drive = drive;
  setJsonValue(`${entryId}.actions`, actions);

  /* UI排他 */
  document.querySelectorAll(".js-drive").forEach(el=>{
    const isActive = el.dataset.appDrive === drive;
    el.classList.toggle("active",isActive);
    el.setAttribute("aria-pressed",String(isActive));
  });
}

// エアコン設定画面のクリックイベント（モード）
function handleModeClick(btn){
  const mode = btn.dataset.appMode;
  const entryId = getJsonValue("entryId");
  const actionId = getJsonValue("editActionId");
  const actions = getJsonValue(`${entryId}.actions`) ?? [];

  const action = actions.find(a => a.actionId === actionId);
  if(!action) return;

  /* JSON保存 */
  action.mode = mode;
  setJsonValue(`${entryId}.actions`, actions);

  /* UI排他 */
  document.querySelectorAll(".js-mode").forEach(el=>{
    const isActive = el.dataset.appMode === mode;
    el.classList.toggle("active",isActive);
    el.setAttribute("aria-pressed",String(isActive));
  });
}





// 「機器の状態を追加」のあとで生成されるカードボタンを作成
function createTriggerButton(entryAutoId) {
  const device = getJsonValue(`${entryAutoId}.triggers.devices`);
  if (!device?.threshold) return;

  const section = document.getElementById("devicesSection");
  const template = document.getElementById("deviceTemplate");
  const addBtn = document.getElementById("addDeviceButton");

  if (!section || !template || !addBtn) return;

  // 既存カード削除（再render対策）
  section.querySelectorAll(".trigger-card-button").forEach(el => el.remove());

  const clone = template.cloneNode(true);
  clone.removeAttribute("id");
  clone.style.display = "block";
  clone.classList.add("trigger-card-button");
  clone.classList.add("devices-section");
  addBtn.classList.remove("devices-section");

  /* ============================
    データセット追加
  ============================ */
  clone.dataset.deviceId = device.id;
  clone.dataset.entryId = entryAutoId;
  clone.dataset.triggerType = "devices";

  /* ============================
    表示内容
  ============================ */
  clone.querySelector(".name").textContent = device.name ?? "（未設定）";
  clone.querySelector(".description").textContent = `${device.condition} 温度${device.threshold}℃`;
  // 追加
  section.insertBefore(clone, addBtn);
  // ＋非表示
  addBtn.style.display = "none";
}

/******************************************
 * オートメーション編集 画面
 * イニシャライズ
 ******************************************/
function createScheduleDescription(days) {
  const allDays = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
  const dayNames = {
    sun: "日",
    mon: "月",
    tue: "火",
    wed: "水",
    thu: "木",
    fri: "金",
    sat: "土",
  };

  if (!days || days.length === 0) {
    return "一度だけ実行します";
  }

  if (days.length === 7) {
    return "毎日実行します";
  }

  const selectedDayNames = days
    .sort((a, b) => allDays.indexOf(a) - allDays.indexOf(b))
    .map((day) => dayNames[day])
    .join("");

  return `毎週${selectedDayNames}曜日に実行します`;
}

// 受け取った曜日を配列⇒JSONに保存
function toggleScheduleDay(entryAutoId, day) {
  const path = `${entryAutoId}.triggers.schedule.days`;

  let days = getJsonValue(path) ?? [];

  if (days.includes(day)) {
    days = days.filter(d => d !== day);
  } else {
    days.push(day);
  }

  setJsonValue(path, days);
  renderSchedule(entryAutoId);
}

// レンダリングする
function renderSchedule(entryAutoId) {
  renderScheduleDays(entryAutoId);
  renderScheduleDescription(entryAutoId);
}

// アクションカードボタンの処理
function createActionButton(entryAutoId) {
  const actions = getJsonValue(`${entryAutoId}.actions`) ?? [];
  if (actions.length >= 5) {
  alert("アクションは最大5つまでです");
  return;
}
  const area = document.getElementById("actionCardArea");
  const template = document.getElementById("actionTemplate");

  if (!area || !template) return;

  /* 既存カード削除 */
  area.querySelectorAll(".action-card").forEach(el => el.remove());

  actions.slice(0,5).forEach((action, index) => {
    const clone = template.cloneNode(true);
    clone.removeAttribute("id");
    clone.style.display = "block";
    clone.classList.add("action-card");

    /* 読み込まれたカードに属性を設定する dataset */
    clone.dataset.actionId = action.actionId;
    clone.dataset.actionType = action.type;
    clone.dataset.actionIndex = index;

    // カードをクリックしたときに遷移するURLを設定する
    let url = "";

    /* devices */
    if (action.type === "devices") {
      const device = ACTION_MASTER.devices[action.id];
      const master = DEVICE_MASTER[action.id];
      if (!device || !master) return;

      clone.querySelector(".source").src = device.icon;
      clone.querySelector(".name").textContent = master.label;

      let desc = master[action.drive] ?? "";
      if (action.mode) desc += ` ${action.mode}`;
      if (action.temp) desc += ` ${action.temp}℃`;
      clone.querySelector(".description").textContent = desc;
      url = device.url;
    }

    /* notify */
    if (action.type === "notify") {
      clone.querySelector(".source").src = ACTION_MASTER.notify.icon;
      clone.querySelector(".name").textContent = "通知";
      clone.querySelector(".description").textContent = action.message ?? "";
      url = ACTION_MASTER.notify.url;
    }

    /* scene */
    if (action.type === "scene") {
      const scene = SCENE_MASTER[action.id];
      if (!scene) return;
      clone.querySelector(".source").src = scene.icon;
      clone.querySelector(".name").textContent = scene.label;
      clone.querySelector(".description").textContent = "シーンを実行";
      url = scene.url;
    }

    clone.dataset.actionUrl = url;
    area.appendChild(clone);
  });
}

// アクションカードのクリックイベント
document.addEventListener("click", e => {
  const card = e.target.closest(".action-card");
  if (!card) return;

  const url = card.dataset.actionUrl;
  const actionId = card.dataset.actionId;
  if (!url) return;

  // 編集対象保存
  setJsonValue("editActionId", actionId);
  // 遷移
  window.location.href = url;
});

// アクションカードの内容を編集画面に反映させる
function initDeviceEditor() {

  const entryId = getJsonValue("entryId");
  const actionId = getJsonValue("editActionId");
  const actions = getJsonValue(`${entryId}.actions`) ?? [];
  const action = actions.find(a => a.actionId === actionId);
  if (!action) return;

  // 機器名を反映
  setDeviceName(action.id);

  // ON / OFF
  setDriveButton(action.drive);

  // モード
  setModeSelect(action.mode);

  // 温度
  setTempInput(action.temp);
}

function setDeviceName(deviceId) {
  const el = document.getElementById("deviceName");
  if (!el) return;
  const name = DEVICE_MASTER[deviceId]?.label ?? "（未設定）";
  el.textContent = name;
}

function setDriveButton(drive) {
  document.querySelectorAll(".js-drive").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.appDrive === drive);
  });
}

function setModeSelect(mode) {
  document.querySelectorAll(".js-mode").forEach((btn) => {
    const isActive = btn.dataset.appMode === mode;
    btn.classList.toggle("active", isActive);
    btn.setAttribute("aria-pressed", String(isActive));
  });
}

function setTempInput(temp) {
  const input = document.getElementById("racSettingTemperature");
  if (!input) return;
  input.textContent = `${temp ?? ""}℃`;
}

function initNotifyEditor() {
  const entryId = getJsonValue("entryId");
  const actionId = getJsonValue("editActionId");
  const actions = getJsonValue(`${entryId}.actions`) ?? [];
  const action = actions.find(a => a.actionId === actionId);
  if (!action || action.type !== "notify") return;

  /* ===== 機器名 ===== */
  const deviceNameEl =
    document.getElementById("notifyDeviceName");

  if (deviceNameEl) {
    deviceNameEl.textContent =
      DEVICE_MASTER[action.id]?.label ?? "（未設定）";
  }


  /* ===== メッセージ ===== */
  const input =
    document.getElementById("notifyMessageInput");

  if (input) {

    input.value = action.message ?? "";
  }
}

document.addEventListener("DOMContentLoaded", () => {
  initDeviceEditor();   // 機器画面の場合
  initNotifyEditor(); // 通知画面の場合
});

// しきい値が所定値を…機器選択後、機器の名前を表示する
const renderRoomTempTriggerButtons = () => {
  // 機器名を表示
  const entryId = getJsonValue("entryId");
  const deviceNameEl = document.getElementById("deviceName");
  const deviceName = getJsonValue(`${entryId}.triggers.devices.name`);
  deviceNameEl.textContent = deviceName ?? "選択された機器の名前"; // ここは実際には選択された機器の名前を入れる
  const underBtn = document.querySelector(".js-threshold-btn[data-app-key='under']");
  const overBtn = document.querySelector(".js-threshold-btn[data-app-key='over']");

  // JSONから condition 取得
  const condition = getJsonValue(`${entryId}.triggers.devices.condition`);
  if (!condition) return;

  // condition → over / under に変換
  let current = "";
  if (condition.includes("超え")) {
    current = "over";
    overBtn.classList.add("active");
    overBtn.setAttribute("aria-pressed", "true");
  }
  if (condition.includes("下回")) {
    current = "under";
    underBtn.classList.add("active");
    underBtn.setAttribute("aria-pressed", "true");
  }

  // ボタン取得
  const buttons = document.querySelectorAll(".js-threshold-btn");

  buttons.forEach((btn) => {
    const onclick = btn.getAttribute("onclick") ?? "";

    // onclick から over / under 判定
    const isOver = onclick.includes("'over'");
    const isUnder = onclick.includes("'under'");

    let type = "";

    if (isOver) type = "over";
    if (isUnder) type = "under";

    // active 切替
    if (type === current) {
      btn.classList.add("active");
      btn.setAttribute("aria-pressed", "true");
    } else {
      btn.classList.remove("active");
      btn.setAttribute("aria-pressed", "false");
    }
  });
};

function goRoomTempStatus() {
  // 遷移先のURLを設定
  const url = "../select-room-temperature-status/";
  window.location.href = url;
};

// 室温が所定値を超えたとき／下回ったとき 画面
const selectRoomTemperatureStatus = () => {
  const entryId = getJsonValue("entryId");

  // JSONから condition 取得
  const condition = getJsonValue(`${entryId}.triggers.devices.condition`);
  if (!condition) return;

  // condition → over / under に変換
  let current = "";
  if (condition.includes("超え")) {
    document.body.setAttribute("data-app-header-set", "selectRoomTemperatureStatusOver");
    document.getElementById("section-over").classList.remove("d-none");
  }
  if (condition.includes("下回")) {
    document.body.setAttribute("data-app-header-set", "selectRoomTemperatureStatusUnder");
    document.getElementById("section-under").classList.remove("d-none");
  }
};

// 完了ボタン処理
const initCompleteButton = () => {
  const btn = document.getElementById("headerRightBtn");
  if (!btn) return;
  AppState.isEdited = false;
  btn.disabled = true;
  btn.classList.add("disabled");
};

// トリガーカードボタンの処理（ゴミ箱アイコン／ボタン本体）
document.addEventListener("DOMContentLoaded", () => {
  const section = document.getElementById("devicesSection");
  if (!section) return;
  // ゴミ箱アイコン
  section.addEventListener("click", (e) => {
    const deleteBtn = e.target.closest(".delete-trigger-card-btn");
    if (deleteBtn) {
      e.preventDefault();
      e.stopPropagation();
      showModal("deleteTriggerCardButton");
      return; // ここで終了
    }
    // カード本体
    const cardBtn = e.target.closest(".trigger-card-button");
    if (cardBtn) {
      window.location.href = "../select-device-operation/";
    }
  });
});

// トリガーカードボタンのモーダル表示関数（削除確認用）
document.addEventListener("click", (e) => {
  const btn = e.target.closest("#confirmActionCardDeleteBtn");
  if (!btn) return;

  const modalEl = document.getElementById("deleteTriggerCardButton");
  const modal = bootstrap.Modal.getInstance(modalEl);
  // トリガーカードボタンを削除する関数
  deleteTriggerCard();
  if (modal) modal.hide();
});

// トリガーカードボタンを削除する（JSON書き換え⇒再読み込み）
const deleteTriggerCard = () => {
  const entryId = getJsonValue("entryId");
  const triggers = getJsonValue(`${entryId}.triggers`);
  if (triggers && triggers.devices) {
    delete triggers.devices;
    setJsonValue(`${entryId}.triggers`, triggers);
  }
  // 再描画
  renderAutomationEditing();
}

// アクションカードボタンの処理（ゴミ箱アイコン／ボタン本体）
document.addEventListener("DOMContentLoaded", () => {
  const section = document.getElementById("actionCardArea");
  if (!section) return;
  section.addEventListener("click", (e) => {
    const deleteBtn = e.target.closest(".delete-action-card-btn");
    if (!deleteBtn) return;

    e.preventDefault();
    e.stopPropagation();

    const card = deleteBtn.closest(".action-card");
    if (!card) return;

    AppState.deleteActionId = card.dataset.actionId;
    showModal("deleteActionCardButton");
  });
});
// アクションカードボタンを削除する（JSON書き換え⇒再読み込み）
function deleteActionCard() {
  const entryId = getJsonValue("entryId");
  const actionId = AppState.deleteActionId;
  if (!actionId) return;

  let actions = getJsonValue(`${entryId}.actions`) ?? [];
  actions = actions.filter(action => action.actionId !== actionId);
  setJsonValue(`${entryId}.actions`, actions);
  AppState.deleteActionId = null;
  renderAutomationEditing();
}

// アクションカード削除用モーダルの削除ボタンをクリックしたとき関数を呼び出す
document.addEventListener("click", (e) => {
  const btn = e.target.closest("#confirmDeleteActionCardButton");
  if (!btn) return;

  const modalEl = document.getElementById("deleteActionCardButton");
  const modal = bootstrap.Modal.getInstance(modalEl);
  // アクションカードを削除する関数
  deleteActionCard();
  if (modal) modal.hide();
});

// シーン設定画面のレンダリング
const renderSetupScene = () => {

  const entryId = getJsonValue("entryId");
  const actionId = getJsonValue("editActionId");

  const actions = getJsonValue(`${entryId}.actions`) ?? [];
  const action = actions.find(a => a.actionId === actionId);

  if (!action || action.type !== "scene") return;

  const sceneId = action.id;

  /* シーン名 */
  const sceneNameEl = document.getElementById("sceneName");
  if (sceneNameEl) {
    sceneNameEl.textContent = SCENE_MASTER[sceneId]?.label ?? "";
  }

  /* 全非表示 */
  document
    .querySelectorAll(".allOff,.sleep,.returnWinter")
    .forEach(el => el.classList.add("d-none"));

  /* 対象表示 */
  document
    .querySelectorAll(`.${sceneId}`)
    .forEach(el => el.classList.remove("d-none"));

};

// 「シーンを選択」 画面からの遷移
document.addEventListener("DOMContentLoaded", () => {

  const section = document.querySelector(".js-select-scene-section");
  if (!section) return;

  section.addEventListener("click", (e) => {

    const sceneBtn = e.target.closest(".js-select-scene-btn");
    if (!sceneBtn) return;

    const sceneId = sceneBtn.dataset.appKey;
    const entryId = getJsonValue("entryId");

    let actions = getJsonValue(`${entryId}.actions`) ?? [];

    if (actions.length >= 5) return;

    // 追加
    actions.push({
      actionId: createId(),
      type: "scene",
      id: sceneId
    });

    const actionId = actions[actions.length - 1].actionId;
    setJsonValue(`${entryId}.actions`, actions);
    setJsonValue("editActionId", actionId);

    window.location.href = "../setup-scene/";
  });

});

// 「機器の操作を選択」 画面からの遷移
document.addEventListener("DOMContentLoaded", () => {

  const section = document.querySelector(".js-select-device-section");
  if (!section) return;

  section.addEventListener("click", (e) => {

    const deviceBtn = e.target.closest(".js-select-device-btn");
    if (!deviceBtn) return;

    const deviceId = deviceBtn.dataset.appDevice;
    const entryId = getJsonValue("entryId");

    let actions = getJsonValue(`${entryId}.actions`) ?? [];

    if (actions.length >= 5) return;

    // 追加
    actions.push({
      actionId: createId(),
      type: "devices",
      id: deviceId
    });

    const actionId = actions[actions.length - 1].actionId;
    setJsonValue(`${entryId}.actions`, actions)
    setJsonValue("editActionId", actionId);

    // 遷移
    const url = ACTION_MASTER.devices[deviceId]?.url;
    if (url) window.location.href = url;

  });

});

// オートメーション編集画面に戻ったとき、
// セッションストレージを一旦リセットする（ただし、newは保持する）
// エントリーIDが書き換わってしまうため、一旦保留
function resetAutomationExceptNew() {

  const current =
    JSON.parse(sessionStorage.getItem("appData")) ?? {};

  const original =
    JSON.parse(sessionStorage.getItem("cloneData")) ?? {};

  const currentNew = current.new ?? null;

  // cloneDataをベースに戻す
  const resetData = JSON.parse(JSON.stringify(original));

  // newだけ保持
  if (currentNew) {
    resetData.new = currentNew;
  }

  sessionStorage.setItem(
    "appData",
    JSON.stringify(resetData)
  );
}

// ID作成（カードボタン用）
function createId(){
  return crypto.randomUUID().replace(/-/g,"").slice(0,10);
}
// console.log("ログ", crypto.randomUUID().replace(/-/g,"").slice(0,10));