  document.querySelectorAll(".js-toggle-switch").forEach((toggle) => {
    //...
  });

  const syncThermalImageManagement = (value) => {
  document.querySelectorAll(".js-toggle-switch").forEach(toggle => {
    toggle.checked = value;
    if (toggle.nextElementSibling) {
      // ↓この記述は便利！！
      toggle.nextElementSibling.innerText = value ? "ON" : "OFF";
    }
  });
};

text.style.color = "red";

84608182