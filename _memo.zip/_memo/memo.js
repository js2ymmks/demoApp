const initialAppData = {


// 運転モード選択ボタン状態
driveModeSelectBtn: [
  {
    mode: "cooling",
    label: "冷房",
    icon: "../assets/img/home-icon-btn-cooling.svg",
    style: "btn-cooling",
  },
  {
    mode: "dehumidifying",
    label: "除湿",
    icon: "../assets/img/home-icon-btn-dehumidification.svg",
    style: "btn-dehumidifying",
  },
  {
    mode: "heating",
    label: "暖房",
    icon: "../assets/img/home-icon-btn-heating.svg",
    style: "btn-heating",
  },
  {
    mode: "perflation",
    label: "送風",
    icon: "../assets/img/home-icon-btn-perflation.svg",
    style: "btn-perflation",
  },
  {
    mode: "ai-auto-cooling",
    label: "A.I.自動(冷房)",
    icon: "../assets/img/home-icon-btn-ai-auto.svg",
    style: "btn-ai-auto",
  },
  {
    mode: "ai-auto-heating",
    label: "A.I.自動(暖房)",
    icon: "../assets/img/home-icon-btn-ai-auto.svg",
    style: "btn-ai-auto",
  },
],
    






  // 表示画面
  currentPage: "basic",
  // 運転モード切替ボタン状態
  currentMode: "冷房",
  currentModeId: "dehumidifying", // cooling, dehumidifying, heating, perflation, ai-auto-cooling, ai-auto-heating
  currentModeColor: "#0872ED",
  currentModeIcon: "../assets/img/home-icon-btn-cooling.svg",
  currentModeStyle: "btn-cooling",
  setTemptureStyle: "text-cooling",
  // フッターアイコン状態
  footerIconStatus: {
    mymu: "../assets/img/icon-footer-mymu.svg",
    basic: "../assets/img/icon-footer-basic-active.svg",
    schedule: "../assets/img/icon-footer-schedule.svg",
    other: "../assets/img/icon-footer-other.svg",
  },
  // スケジュール設定
  schedule: [
    {
      id: 1,
      name: "朝の運転",
      startTime: "07:00",
      dayOfTheWeek: {
        mon: true,
        tue: true,
        wed: true,
        thu: true,
        fri: true,
        sat: false,
        sun: false,
      },
      drive: true,
      mode: "cooling",
      setValue: 24,
    },
  ],
  footerTextStatus: {
    mymu: "footer-text",
    basic: "footer-text",
    schedule: "footer-text",
    other: "footer-text",
  },


  // 運転／停止ボタン
  modalDrive: {
    // true ⇔ false
    isRunning: true,
    label: "停止",
  },
  // 運転モードボタン
  buttons: [
    {
      id: "cooling",
      label: "冷房",
      icon: "../assets/img/home-icon-btn-cooling.svg",
      color: "#0872ED",
      style: "btn-cooling",
    },
    {
      id: "dehumidify",
      label: "除湿",
      icon: "../assets/img/home-icon-btn-dehumidification.svg",
      color: "#008738",
      style: "btn-dehumidifying",
    },
    {
      id: "heating",
      label: "暖房",
      icon: "../assets/img/home-icon-btn-heating.svg",
      color: "#D64100",
      style: "btn-heating",
    },
    {
      id: "fan",
      label: "送風",
      icon: "../assets/img/home-icon-btn-perflation.svg",
      color: "#757575",
      style: "btn-perflation",
    },
    {
      id: "ai-auto-cooling",
      label: "A.I.自動(冷房)",
      icon: "../assets/img/home-icon-btn-ai-auto.svg",
      color: "#D63771",
      style: "btn-ai-auto",
    },
    {
      id: "ai-auto-heating",
      label: "A.I.自動(暖房)",
      icon: "../assets/img/home-icon-btn-ai-auto.svg",
      color: "#D63771",
      style: "btn-ai-auto",
    },
  ],
};


  console.log("headerSetJson.right", headerSetJson.right);