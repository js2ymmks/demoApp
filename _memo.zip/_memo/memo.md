ファイル名は、温度・湿度・除湿 改修
## A.I.自動モードの処理方法
### 初期状態を取得


### JSONを更新
### 表示を更新

### 画面
基本画面
スケジュール画面
その他機能
タッチ気流
熱画像管理
settings
schedule-edite
schedule
other
option
maintenance
home
electricity-cost-setting
electricity-bill-per-year
electricity-bill-per-month
electricity-bill-check

「くらし ID」マイポータル
家電シェア
自宅位置設定
購入情報一覧
通知設定
ログアウト

https://koichi-yamada-mee.github.io/RacDemoApp/racDemoApp-1226.zip
https://koichi-yamada-mee.github.io/RacDemoApp/racDemoApp.zip

https://koichi-yamada-mee.github.io/RacDemoApp/GoodShareSettingApp-1226.zip
https://koichi-yamada-mee.github.io/RacDemoApp/GoodShareSetingApp-1226.zip
https://koichi-yamada-mee.github.io/RacDemoApp/GoodShareSettingsApp-1226.zip


## トグルスイッチの考え方
最終形は以下
toggle.selected? OFF : ON

### 現在の状態
toggle.checked; // true = ON / false = OFF

### トグル切り替え時
toggle.addEventListener("change", () => {
  updateStatus(toggle.checked);
});

### ラベル（OFF / ON）を切り替える
toggle.addEventListener("change", () => {
  label.textContent = toggle.checked ? "ON" : "OFF";
});

### 進め方
#### STEP 1：HTML（ラベルに識別用クラスを付ける）
  * .js-toggle-switch (JSで制御する`js-*`)
  * data-app-key="thermalImageManagement" (`thermalImageManagement` 特定の属性を持たせる)
#### STEP 2：ラベル更新専用の関数を作る
  function updateToggleLabel(toggle) {
    getJsonValue();
    ...
  }
  * 要素を取得する
#### STEP 3：初期表示時にラベルも同期する
  function renderFromState() {
      updateToggleLabel(toggle);
  }
#### STEP 4：切り替えた瞬間にもラベルを更新
* JSONの値を参照するのか
* HTML内の値を参照するのか
  document.querySelectorAll(".js-toggle-switch").forEach((toggle) => {
    toggle.addEventListener("change", () => {
      setJsonValue();
      updateToggleLabel(toggle);
    });
  });

トグルスイッチをOFF⇔ON（全て）
ラベルの表記をOFF⇔ON（全て）
カードのリンクをOFF⇔ON（1箇所）
熱画像の表示をOFF⇔ON（1箇所）

JSONから読み取る（これ大事）
読み取るタイミング
* 初期
* JSON更新⇒ DOM更新

## ヘッダー部のチェック方法
1. body要素にデータ属性が設定されていること
2. 設定された値がJSONに設定されていること
3. 処理がJSで定義されていること
4. ボタン装飾が解除されていること

## ボタン装飾を解除する考え方

setJsonValue
getJsonValue

updateContents
│ 
├── renderDomParts
│   └── getJsonValue
│
├── handleDomParts
│   └── setJsonValue
│ 
├── renderDomParts
    └── getJsonValue




.
├── assets
│   ├── css
│   │   ├── demo_app.css
│   │   └── wheel-picker-modal.css
│   ├── favicon
│   │   └── favicon.ico
│   ├── img
│   │   ├── back-ground-screen.png
│   │   └── WindSpeedMediumeTop.svg
│   └── js
│       ├── demo-app-json.js
│       ├── demo-app.js
│       ├── session-check.js
│       └── wheelPickerModal.js
├── cw800
│   └── index.html
├── electricity-bill-check-settings
│   └── index.html
│   └── index.html
├── schedule
│   └── index.html
│   └── index.html
│   └── index.html
└── touch-airflow
    └── index.html


