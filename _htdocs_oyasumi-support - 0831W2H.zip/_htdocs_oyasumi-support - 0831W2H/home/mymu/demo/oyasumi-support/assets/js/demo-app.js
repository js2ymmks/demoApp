﻿/******************************************
 * テンプレートファイル読み込み
 ******************************************/
document.addEventListener("DOMContentLoaded", async () => {
  try { 
    const [alert, header, footer, modal, drawer] = await Promise.all([
      fetch("../partials/alert.txt").then((r) => r.text()),
      fetch("../partials/header.txt").then((r) => r.text()),
      fetch("../partials/footer.txt").then((r) => r.text()),
      fetch("../partials/modal.txt").then((r) => r.text()),
      fetch("../partials/drawer-menu.txt").then((r) => r.text()),

      // 本番環境では下記を使用する 
      // fetch("/home/mymu/demo/mymu/partials/alert.txt").then((r) => r.text()),
      // fetch("/home/mymu/demo/mymu/partials/header.txt").then((r) => r.text()),
      // fetch("/home/mymu/demo/mymu/partials/footer.txt").then((r) => r.text()),
      // fetch("/home/mymu/demo/mymu/partials/modal.txt").then((r) => r.text()),
      // fetch("/home/mymu/demo/mymu/partials/drawer-menu.txt").then((r) => r.text()),
    ]);

    document.querySelector(".content-alert").innerHTML = alert;
    document.querySelector(".content-header").innerHTML = header;
    document.querySelector(".content-footer").innerHTML = footer;
    document.querySelector(".content-modal").innerHTML = modal;
    document.querySelector(".content-drawer").innerHTML = drawer;
    initUI();
  } catch (err) {
    console.error("Failed to load partials:", err);
  }
});

/******************************************
 * ユーティリティ：JSON取得（ブラケット版）
 ******************************************/
const getJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("appDataEdit");
  let data;
  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }
  if (!data) return undefined;
  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");
  const props = normalizedPath.split(".");
  let current = data;
  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }
  return current;
};

/******************************************
 * ユーティリティ：JSON更新（ブラケット版）
 ******************************************/
const setJsonValue = (propertyPath, value) => {
  const storedJson = sessionStorage.getItem("appDataEdit");
  let data;
  try {
    data = storedJson ? JSON.parse(storedJson) : {};
  } catch (e) {
    data = {};
  }
  // ブラケット記法をドット記法に変換
  // "buttons[0].label" → "buttons.0.label"
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");
  const props = normalizedPath.split(".");
  let current = data;
  for (let i = 0; i < props.length - 1; i++) {
    const prop = props[i];
    // 数字 → 配列アクセス
    const index = Number(prop);
    const isIndex = !isNaN(index);
    if (isIndex) {
      if (!Array.isArray(current)) {
        current = [];
      }
      if (current[index] === undefined) {
        current[index] = {};
      }
      current = current[index];
    } else {
      if (!current[prop] || typeof current[prop] !== "object") {
        current[prop] = {};
      }
      current = current[prop];
    }
  }
  // 最終プロパティ
  const lastProp = props[props.length - 1];
  const lastIndex = Number(lastProp);
  if (!isNaN(lastIndex)) {
    if (!Array.isArray(current)) current = [];
    current[lastIndex] = value;
  } else {
    current[lastProp] = value;
  }
  sessionStorage.setItem("appDataEdit", JSON.stringify(data));
};

/******************************************
 * ユーティリティ：JSON取得（ブラケット版）ヘッダー用
 ******************************************/
const getHeaderJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("headerSet");
  let data;
  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }
  if (!data) return undefined;
  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");
  const props = normalizedPath.split(".");
  let current = data;
  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }
  return current;
};

/******************************************
 * ユーティリティ
 ******************************************/
// モーダルを閉じたときにフォーカスを外す
window.addEventListener("hide.bs.modal", () => {
  document.activeElement.blur();
});

/******************************************
 * ユーティリティ：JSONの変更検知
 ******************************************/
function isJsonChanged() {
  const entryId = getJsonValue("entryId");
  const originalStr = sessionStorage.getItem("appData");
  const editingStr = sessionStorage.getItem("appDataEdit");
  if (!originalStr || !editingStr) return false;
  const original = JSON.parse(originalStr);
  const editing = JSON.parse(editingStr);
  const originalData = original[entryId];
  const editingData = editing[entryId];
  const isChanged =
    JSON.stringify(originalData) !== JSON.stringify(editingData);
  return isChanged;
}

/******************************************
 * ユーティリティ：ヘッダーのアイテムを設定する
 ******************************************/
function initHeader() {
  // ==============================
  // DOM取得
  // ==============================
  const headerDom = {
    leftBtn: document.getElementById("headerLeftBtn"),
    title: document.getElementById("headerTitle"),
    rightBtn: document.getElementById("headerRightBtn"),
  };

  if (!headerDom.leftBtn || !headerDom.title || !headerDom.rightBtn) {
    console.warn("header DOM がまだ準備できていません");
    return;
  }

  // ==============================
  // headerSetBodyKeyキー取得
  // ==============================
  const currentHeaderSetKey = document.body.dataset.appHeaderSet;
  if (!currentHeaderSetKey) {
    console.warn("data-app-header-set が指定されていません");
    return;
  }

  // ==============================
  // headerSetJson 取得
  // ==============================
  const headerSetJson = getHeaderJsonValue(`${currentHeaderSetKey}`);
  if (!headerSetJson) {
    console.warn(`headerSet.${currentHeaderSetKey} が見つかりません`);
    return;
  }

  // ==============================
  // タイトル
  // ==============================
  headerDom.title.innerHTML = headerSetJson.title;

  // ==============================
  // 左ボタン
  // ==============================
  renderLeftButton(headerSetJson.left?.type, headerDom.leftBtn);
  headerDom.leftBtn.onclick = () =>
    handleHeaderLeftAction(headerSetJson.left?.type);

  // ==============================
  // 右ボタン
  // ==============================
  renderRightButton(headerSetJson.right, headerDom.rightBtn);
  headerDom.rightBtn.onclick = () =>
    handleHeaderRightAction(headerSetJson.right?.action);
}

function initUI() {
  initFooterButtons();
  initFooterButtonsState();
  initHeader();
  bindScheduleTimeModal();
}

function bindScheduleTimeModal() {
  const modalEl = document.getElementById("scheduleTimeModal");
  if (!modalEl) return;
  if (modalEl.dataset.boundScheduleTimeModal === "1") return;
  modalEl.dataset.boundScheduleTimeModal = "1";

  modalEl.addEventListener("show.bs.modal", () => {
    const entryId = getJsonValue("entryId");
    renderScheduleTimeModal(entryId);
  });
}

// ==============================
// 左ボタン描画
// ==============================
// リセット
function renderLeftButton(type, btn) {
  btn.innerHTML = "";
  btn.classList.remove("d-none");
  // アイコン設定
  switch (type) {
    case "back":
      btn.innerHTML =
        '<i class="bi bi-chevron-left" style="color: white; font-size: 24px"></i>';
      break;
    case "backToMyMUPlusScreen":
      btn.innerHTML =
        '<div class="d-flex align-items-center gap-2"><img src="../assets/img/chevron-back.svg"><img src="../assets/img/icon_MyMUHeader.svg"></div>';
      break;
    case "backToTopSleepSettingsScreen":
      btn.innerHTML =
        '<img src="../assets/img/chevron-back.svg">';
      break;
    case "drawer":
      btn.innerHTML =
        '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"><rect x="1" y="2" width="18" height="2.5" rx="1.25" fill="black"/><rect x="1" y="9" width="18" height="2.5" rx="1.25" fill="black"/><rect x="1" y="16" width="18" height="2.5" rx="1.25" fill="black"/></svg>';
      break;
    case "backToSelectDeviceScreen":
      btn.innerHTML = '<i class="bi bi-chevron-left"></i>';
      break;
    case "easySetup":
      document.querySelector(".content-header").classList.add("d-none");
      break;
    default:
      btn.classList.add("d-none");
  }
}

// ==============================
// 左アクション処理
// ==============================
function handleHeaderLeftAction(type) {
  switch (type) {
    case "backToMyMUPlusScreen":
      window.location.href = "../mymu-plus/";
      break;
    case "backToSelectDeviceScreen":
      window.location.href = "../select-device/";
      break;
    case "drawer":
      const bsOffcanvas = new bootstrap.Offcanvas("#appOffcanvas");
      bsOffcanvas.show();
      break;
  }
}

// ==============================
// 右ボタン描画　headerTitle
// ==============================
function renderRightButton(headerSetJsonRight, headerDomRight) {
  // 右ボタンのプロパティチェック
  if (!headerSetJsonRight || !headerSetJsonRight.visible) {
    headerDomRight.classList.add("d-none");
    headerDomRight.onclick = null;
    return;
  }
  // 表示
  headerDomRight.classList.remove("d-none");
  // text / icon / svg すべて対応
  headerDomRight.innerHTML = headerSetJsonRight.text || "";
  if (headerSetJsonRight.action === "drawer") {
    headerDomRight.disabled = false;
    headerDomRight.classList.remove("disabled");
    headerDomRight.classList.remove("js-complete-btn");
    headerDomRight.setAttribute("aria-disabled", "false");
  }

  // クリック処理（あれば）
  headerDomRight.onclick = () => {
    handleHeaderRightAction(headerSetJsonRight.action, headerSetJsonRight);
  };
}

// ==============================
// 右アクション処理（）
// ==============================
function handleHeaderRightAction(action) {
  switch (action) {
    // メニュー表示
    case "drawer":
      const bsOffcanvas = new bootstrap.Offcanvas("#appOffcanvas");
      bsOffcanvas.show();
      break;

    // アラート表示
    case "alert":
      alert(
        "デモアプリではこのボタンは操作できません。＜ ボタンで戻ってください",
      );
      break;

    // MyMUボタン
    case "mymu":
      const headerEl = document.querySelector(".app-header");
      headerEl.addEventListener("click", (e) => {
        const btn = e.target.closest("#headerRightBtn");
        if (!btn) return;
        alert("デモアプリではこのボタンは操作できません。");
      });
      break;
    // シーン
    case "":
      break;
  }
}

/******************************************
 * ユーティリティ：モーダル表示
 ******************************************/
function showModal(modalId) {
  const modalEl = document.getElementById(modalId);
  if (!modalEl) return;

  const modal = new bootstrap.Modal(modalEl);
  modal.show();
}

/******************************************
 * イニシャライズ：フッター
 ******************************************/
const initFooterButtons = () => {
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const currentHeaderSetKey = document.body.dataset.appHeaderSet;
      // MyMU＋アイコンのみ処理する
      if (btn.dataset.appPage !== "mymuPlus") {
        return;
      }
      if (
        currentHeaderSetKey === "editAutomation" &&
        btn.dataset.appPage === "automation"
      ) {
        setJsonValue("navigationMode", "back");
      }
      setJsonValue("currentPage", btn.dataset.appPage);
    });
  });
};

/******************************************
 * レンダリング：フッターアイコン表示更新
 ******************************************/
const initFooterButtonsState = () => {
  // フッターが存在しない画面
  const footerElement = document.getElementsByClassName("content-footer")[0];
  if (footerElement.className.includes("d-none")) {
    return;
  }
  // スタイルリセット
  const currentPage = getJsonValue("currentPage");
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.classList.remove("active");
  });
  // レンダリング
  footerButtons.forEach((btn) => {
    const page = btn.dataset.appPage;
    if (page === currentPage) {
      btn.classList.add("active");
    }
  });
};

/******************************************
 * マスターデータ
 ******************************************/
// xxxx
const MASTER_xxxxx = {};


const stateModalDialogTest = {
  state: 'sleepTimeSetting1'
};

// ダイアログ
const MASTER_DIALOG = {
  // こだわり設定_ダイアログ_1
  acCustomSettings: {
    description: '設定内容が保存されていません<br />設定内容を破棄してもよろしいですか？',
    btnLeft: '破棄する',
    btnRight: '編集を続ける',
  },
  // おやすみ時間設定_ダイアログ_1
  sleepTimeSetting1: {
    description: 'おやすみ自動運転の開始時刻を過ぎているため、おやすみ自動運転は翌日以降に動作します。設定を変更しますか？',
    btnLeft: '変更しない',
    btnRight: '変更する',
  },
  // おやすみ時間設定_ダイアログ_2
  sleepTimeSetting2: {
    description: 'おやすみサポートをOFFにすると「おやすみ自動運転」は行われません。設定を変更しますか？',
    btnLeft: '変更しない',
    btnRight: '変更する',
  },
  // おやすみ音楽設定_ダイアログ_1
  sleepMusicSettings1: {
    description: '音楽を削除しますか？<br />※削除後も再ダウンロードが可能です。',
    btnLeft: 'いいえ',
    btnRight: 'はい',
  },
  // おやすみ音楽設定_ダイアログ_2
  sleepMusicSettings2: {
    description: 'ダウンロードを開始しますか？<br />(50MB)',
    btnLeft: 'いいえ',
    btnRight: 'はい',
  },
  // 運転時間
  operatingTime: {
    title: '起動室温',
    options: ['30分', '40分', '50分', '1時間', '1時間10分'],
    btnLeft: 'キャンセル',
    btnRight: '決定',
  },
  // 運転継続時間
  continuousOperatingTime: {
    title: '運転継続時間',
    options: ['0分 (就寝時刻で停止)', '30分', '1時間', '2時間', '起床時刻まで'],
    btnLeft: 'キャンセル',
    btnRight: '決定',
  },
  // 起動室温
  startUpRoomTemperature: {
    title: '起動室温',
    options: ['16℃', '16.5℃', '17℃', '17.5℃', '18℃'],
    btnLeft: 'キャンセル',
    btnRight: '決定',
  },
  // 設定温度
  setTemperature: {
    title: '設定温度',
    options: ['16℃', '16.5℃', '17℃', '17.5℃', '18℃'],
    btnLeft: 'キャンセル',
    btnRight: '決定',
  },
};



/******************************************
 * クリックイベント
 ******************************************/
document.addEventListener("click", (e) => {
  const el = e.target;

  // 全画面｜アラート表示
  const showAlertBtn = el.closest(".js-show-alert");
  if (showAlertBtn) {
    alert("デモアプリではこのボタンは操作できません。");
  }

  // MyMU＋画面｜ソリューションカード
  const appCardBtn = el.closest(".js-app-card");
  if (appCardBtn) {
    const mode = getJsonValue("screenMode");
    if (mode === "settings") {
      window.location.href = "../top-sleep-settings/";
    } else {
      window.location.href = "../top-report/";
    }
  }

  // トップ画面（睡眠設定）｜エアコン設定画面へ遷移js-ac-setting-type
  const acSettingsBtn = el.closest(".js-ac-settings-btn");
  if (acSettingsBtn) {
    window.location.href = "../ac-settings/";
  }

  // エアコン設定画面｜エアコン設定変更モーダルへ遷移
  const selectSettingTypeBtn = el.closest(".js-select-setting-type-btn");
  if (selectSettingTypeBtn) {
    showModal("selectAcSetupMethod");
  }

  // トップ画面（睡眠設定） |
  const showSleepSettingsScreenBtn = el.closest(".js-show-sleep-settings");
  if (showSleepSettingsScreenBtn) {
    setJsonValue("topPageMode", "settings");
  }

  // トップ画面（レポート） |
  const showReportScreenBtn = el.closest(".js-show-report");
  if (showReportScreenBtn) {
    setJsonValue("topPageMode", "report");
  }

  // モーダルテンプレート |
  const showModalDialogTemplateBtn = el.closest(".js-show-modal");
  if (showModalDialogTemplateBtn) {
    renderModalDialogTemplate();
    showModal("modalDialogTemplate");
  }

  // おやすみ音楽設定画面へ遷移
  const gotoSleepMusicSettingsScreenBtn = el.closest(".js-goto-sleep-music-settings");
  if (gotoSleepMusicSettingsScreenBtn) {
    window.location.href = "../sleep-music-settings/";
  }

// おやすみ音楽設定画面｜おやすみ音楽削除ボタン
  const musicDeleteBtn = el.closest("#musicDeleteBtn");
  if (musicDeleteBtn) {
    showModal("modalDialogTemplate");
  }

// おやすみ音楽設定画面｜おやすみ音楽ダウンロードボタン
  const musicDownloadBtn = el.closest("#musicDownloadBtn");
  if (musicDownloadBtn) {
    showModal("modalDialogTemplate");
  }

// おやすみ音楽設定画面｜おやすみ音楽選択ボタン
  const musicSelectBtn = el.closest("#musicSelectBtn");
  if (musicSelectBtn) {
    showModal("modalDialogTemplate");
  }




  // ↑ クリックイベントの処理はここまで
});

/******************************************
 * レンダリング｜レポート画面
 * 各画面ごとのレンダリング処理
 ******************************************/
// MyMU＋画面｜ヘッダー部の注記の色をMyMUと同じカラーにする
function renderMymuPlusScreen() {
  const elm = document.querySelector(".content-alert .bg-black");
  elm.classList.add("alert");
  elm.classList.replace("bg-black", "alert-primary");
}

/******************************************
 * 状態管理
 ******************************************/
// かんたん設定
const easySetupState = {
  currentPage: "easySetup2",
};

// エアコンのこだわり設定
const acCustomSettingsState = {
  autoTemperatureSetting: {
    state: true,
  },
  sleepModeCooling: {
    stateTxt: "1時間",
  },
  preCoolingBeforeSleeping: {
    state: true,
    stateTxt: "30分",
  },
  preHeatingBeforeSleeping: {
    state: true,
    stateTxt: "30分",
  },
  options: {
    state: true,
  },
};

/******************************************
 * レンダリング｜各画面
 ******************************************/
// トップ画面（睡眠設定）
function renderTopSleepSettingsScreen() {
const toggle = document.querySelector(
  '[data-state-key="oyasumiSupport"]'
);

renderToggle(toggle);  getSwitchTabInnerHTML();
  whichScreenToDisplay();
}

// トップ画面（レポート）
function renderTopReportScreen() {
  getSwitchTabInnerHTML();
  whichScreenToDisplay();
}

// エアコン設定画面
function renderAcSettingsScreen() {}

// エアコンのこだわり画面
function renderAcCustomSettingsScreen() {
  renderAccordionsElement('autoTemperatureSetting');
  renderAccordionsElement('sleepModeCooling');
  renderAccordionsElement('preCoolingBeforeSleeping');
  renderAccordionsElement('preHeatingBeforeSleeping');
  renderAccordionsElement('options');
}

// エアコンのこだわり画面｜おまかせ温度設定
function renderAccordionsElement(accordionId) {
  const targetElems = document.getElementById(accordionId);
  const accordionDes = targetElems.querySelector('.description');
  const switchText = targetElems.querySelector('.switch-text span');
  const switchState = acCustomSettingsState[accordionId].state;
  const txtSub = targetElems.querySelector('.txt-sub')?? null;

  accordionDes.toggleAttribute('hidden', true);
  switch (accordionId) {
    case 'autoTemperatureSetting':
      switchState ? switchText.textContent = '有効' : switchText.textContent = '無効';
      break;
    case 'sleepModeCooling':
      switchText.textContent = "運転時間：" + acCustomSettingsState[accordionId].stateTxt;
      txtSub.textContent = acCustomSettingsState[accordionId].stateTxt;
      break;
    case 'preCoolingBeforeSleeping':
      switchState 
      ? switchText.textContent = "運転継続時間：" + acCustomSettingsState[accordionId].stateTxt 
      : switchText.textContent = '無効';
      txtSub.textContent = acCustomSettingsState[accordionId].stateTxt;
      break;
    case 'preHeatingBeforeSleeping':
      switchState 
      ? switchText.textContent = "運転継続時間：" + acCustomSettingsState[accordionId].stateTxt 
      : switchText.textContent = '無効';
      txtSub.textContent = acCustomSettingsState[accordionId].stateTxt;
      break;
    case 'options':
      break;
  }

}

// おやすみ音楽設定画面
function renderSleepMusicSettingsScreen() {}

// かんたん設定画面
function renderEasySetupScreen() {
  renderSvgImage();
}

// トップページ｜SVGアイコン｜
function whichScreenToDisplay() {
  const topPageMode = getJsonValue("topPageMode");
  const settingsElm = document.querySelector(
    '.tab-switch[data-key="settings"]',
  );
  const reportElm = document.querySelector('.tab-switch[data-key="report"]');
  // 画面表示をスイッチ
  if (topPageMode === "settings") {
    setComponentState(settingsElm, "active");
    setComponentState(reportElm, "inactive");
  } else if (topPageMode === "report") {
    setComponentState(settingsElm, "inactive");
    setComponentState(reportElm, "active");
  }
}

// かんたん設定画面｜リンダリング
function renderSvgImage() {
  const hideSvgImages = document.querySelectorAll(".js-svg-image");
  const displaySvgImage = document.getElementById(
    `${easySetupState.currentPage}`,
  );
  // リセット（全て非表示）
  hideSvgImages.forEach((image) => {
    image.style.display = "none";
  });
  // 表示
  displaySvgImage.style.display = "block";
}

// ユーティリティ｜状態変更
function setComponentState(element, state) {
  element.dataset.state = state;
}

// モード選択スイッチタブのinnerHTML
function getSwitchTabInnerHTML() {
  document.getElementById("switchTab").innerHTML = `
          <div class="container px-4 py-2">
            <div class="row align-items-center">
              <!-- 睡眠設定 -->
              <div class="col tab-switch" data-key="settings" data-state="">
                <a role="button"
                  class="d-flex flex-column align-items-center text-decoration-none footer-button js-show-sleep-settings"
                  href="../top-sleep-settings/" data-app-page="mymu">
                  <div class="">
                    <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path id="iconSleepSettings"
                        d="M12.2041 0C17.472 0.831521 21.5008 5.39097 21.501 10.8926C21.501 16.984 16.5622 21.9229 10.4707 21.9229C6.06656 21.9227 2.26786 19.3397 0.5 15.6074C1.97938 16.5031 3.71371 17.0204 5.56934 17.0205C10.984 17.0205 15.374 12.6305 15.374 7.21582C15.3739 4.36063 14.1519 1.79173 12.2041 0Z"
                        fill="currentColor" />
                    </svg>
                  </div>
                  <div id="labelSleepSettings" class="fs-14 pt-2 label">睡眠設定</div>
                </a>
              </div>
              <!-- レポート -->
              <div class="col tab-switch" data-key="report" data-state="">
                <a role="button"
                  class="d-flex flex-column align-items-center text-decoration-none footer-button js-show-report"
                  href="../top-report/" data-app-page="">
                  <div class="">
                    <svg id="iconReport" width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <rect class="icon" x="6" width="4" height="22" rx="1" fill="currentColor" />
                      <rect class="icon" x="12" y="6" width="4" height="16" rx="1" fill="currentColor" />
                      <rect class="icon" x="18" y="10" width="4" height="12" rx="1" fill="currentColor" />
                      <rect class="icon" y="10" width="4" height="12" rx="1" fill="currentColor" />
                    </svg>
                  </div>
                  <div id="labelReport" class="fs-14 pt-2 label">レポート</div>
                </a>
              </div>
            </div>
          </div>
  `;
}

// かんたん設定画面｜次のページへ
function nextPage() {
  if (easySetupState.currentPage === "easySetup5") {
    easySetupState.currentPage = "easySetup1";
    window.location.href = "../ac-settings/";
    return;
  }
  const pageNumber = Number(
    easySetupState.currentPage.replace("easySetup", ""),
  );
  easySetupState.currentPage = `easySetup${pageNumber + 1}`;
  renderSvgImage();
}

function renderModalDialogTemplate() {
  const modalState = stateModalDialogTest.state;
  document.querySelector(".description").textContent = MASTER_DIALOG[modalState].description;
  document.querySelector(".btnLeft").textContent = MASTER_DIALOG[modalState].btnLeft;
  document.querySelector(".btnRight").textContent = MASTER_DIALOG[modalState].btnRight;

}

// エアコンのこだわり設定画面｜アコーディオンの開閉
document.querySelectorAll('.accordion-button-custom').forEach(button => {
  button.addEventListener('click', () => {
    const accordionItem = button.closest('.accordion-item');
    const accordionDes = accordionItem.querySelector('.description');
    const accordionTxt= accordionItem.querySelector('.switch-text');
    const isOpen = accordionItem.classList.toggle('is-open');
    button.setAttribute('aria-expanded', isOpen);
    accordionTxt.toggleAttribute('hidden', isOpen);
    accordionDes.toggleAttribute('hidden', !isOpen);

// アコーディオンを開いたとき、画面からはみ出さないようにスクロールする処理
    if (isOpen) {
      setTimeout(() => {
        accordionItem.scrollIntoView({ 
          behavior: 'smooth', 
          // block: 'nearest' // 画面の端に最小限のスクロールで収める
        });
      }, 100); // 100ミリ秒の遅延
    }
    
  });
});


/******************************************
 * トグルスイッチ（コンポーネント）
 ******************************************/
const state = {
  oyasumiSupport: true,
  automaticOperation: true,
  autoTemperatureSettings: true,
  preCoolingBeforeSleep: true,
  preHeatingBeforeSleep: true,
  fadeOut: true,
  playbackTime: true,
};

function renderToggle(toggleElement) {
  const stateKey = toggleElement.dataset.stateKey;
  const isOn = state[stateKey];
  const track = toggleElement.querySelector('.toggle-track');
  const knob = toggleElement.querySelector('.toggle-knob');
  track.setAttribute(
    'fill',
    isOn ? '#967AEB' : '#F0F0F0'
  );
  knob.setAttribute(
    'cx',
    isOn ? '35' : '15.5'
  );
}

function setupToggle() {
  const toggle = document.querySelector('.toggle-switch');
  if (!toggle) {
    return;
  }

  toggle.addEventListener('click', () => {
    // stateを変更
    state.toggle = !state.toggle;
    // stateを元に描画
    renderToggle(toggle);
  });

  // 初期描画
  renderToggle(toggle);
}


document.addEventListener('click', (event) => {
  const toggle = event.target.closest('.toggle-component');
  if (!toggle) {
    return;
  }
  const stateKey = toggle.dataset.stateKey;
  state[stateKey] = !state[stateKey];
  renderToggle(toggle);
});


// 共通画面｜モーダル｜要素の値をセットする
  // const setTempBtn = el.closest(".js-set-temp-btn");
  // if (setTempBtn) {
  //   const deviceId = getJsonValue("entryDevice");
  //   const deviceStatus = appTemporaryScene.devices?.[deviceId];
  //   const setTempElms = document.querySelectorAll(".temp");
  //   const tempCooling = ["29.0", "28.5", "28.0", "27.5", "27.0"];
  //   const tempHeating = ["21.0", "20.5", "20.0", "19.5", "19.0"];
  //   let i = 0;
  //   // 運転モードを取得してモーダルの温度ピッカーを調整する
  //   switch (deviceStatus.mode) {
  //     case "冷房":
  //       setTempElms.forEach((elm) => {
  //         elm.textContent = tempCooling[i];
  //         i++;
  //       });
  //       break;
  //     case "暖房":
  //       setTempElms.forEach((elm) => {
  //         elm.textContent = tempHeating[i];
  //         i++;
  //       });
  //       break;
  //   }
  //   showModal("setTemperatureSceneModal");
  // }


// かんたん設定｜＋ボタン／－ボタンクリック時の温度表示
const roomCoolingTemperature = {
  value: 26.5,
  min: 16,
  max: 35,
  step: 0.5
};

const roomHeatingTemperature = {
  value: 21.0,
  min: 15,
  max: 30,
  step: 0.5
};

// const temperatureState = {
//   value: 26.5,
//   min: 16,
//   max: 35,
//   step: 0.5
// };

const temperatureInteger = document.querySelector('#temperatureInteger tspan');
const temperatureDecimal = document.querySelector('#temperatureDecimal tspan');
const minusButton = document.querySelector('#coolingMinusBtn');
const plusButton = document.querySelector('#coolingPlusBtn');

function changeTemperature(offset) {
  const newValue = roomCoolingTemperature.value + offset;
  if (newValue < roomCoolingTemperature.min) return;
  if (newValue > roomCoolingTemperature.max) return;
  roomCoolingTemperature.value = newValue;
  updateTemperatureUI();
}

function updateTemperatureUI() {
  const [integer, decimal] = roomCoolingTemperature.value.toFixed(1).split('.');
  temperatureInteger.textContent = `${integer}.`;
  temperatureDecimal.textContent = decimal + '℃';
  // −ボタン
  minusButton.classList.toggle(
    'cooling-btn-disabled',
    roomCoolingTemperature.value <= roomCoolingTemperature.min
  );

  // ＋ボタン
  plusButton.classList.toggle(
    'cooling-btn-disabled',
    roomCoolingTemperature.value >= roomCoolingTemperature.max
  );
}

minusButton.addEventListener('click', () => {
  changeTemperature(-roomCoolingTemperature.step);
});

plusButton.addEventListener('click', () => {
  changeTemperature(roomCoolingTemperature.step);
});

updateTemperatureUI();