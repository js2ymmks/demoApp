(() => {
  const itemHeight = 36;
  const viewport = document.getElementById("wheelViewport");
  const pickerOk = document.getElementById("pickerOk");
  const modalEl = document.getElementById("wheelPickerModal");

  const tempInt = document.getElementById("tempInt");
  const tempDec = document.getElementById("tempDec");

  const options = Array.from({ length: 31 }, (_, i) => 16 + i);

  function buildWheel() {
    viewport.innerHTML = "";
    const padCount = Math.floor(viewport.clientHeight / itemHeight / 2);

    for (let i = 0; i < padCount; i++) {
      viewport.appendChild(document.createElement("div")).className =
        "wheel-item";
    }

    options.forEach((val) => {
      const el = document.createElement("div");
      el.className = "wheel-item";
      el.dataset.value = val;
      el.textContent = val;
      viewport.appendChild(el);
    });

    for (let i = 0; i < padCount; i++) {
      viewport.appendChild(document.createElement("div")).className =
        "wheel-item";
    }
  }

  function highlightNearest() {
    const rect = viewport.getBoundingClientRect();
    const centerY = rect.top + rect.height / 2;

    let nearest = null;
    let min = Infinity;

    viewport.querySelectorAll(".wheel-item").forEach((el) => {
      const r = el.getBoundingClientRect();
      const d = Math.abs(r.top + r.height / 2 - centerY);
      if (d < min) {
        min = d;
        nearest = el;
      }
    });

    viewport
      .querySelectorAll(".wheel-item")
      .forEach((el) => el.classList.remove("selected"));

    if (nearest && nearest.dataset.value) {
      nearest.classList.add("selected");
    }
  }

  let timer;
  viewport.addEventListener("scroll", () => {
    clearTimeout(timer);
    timer = setTimeout(highlightNearest, 120);
  });

  modalEl.addEventListener("shown.bs.modal", () => {
    buildWheel();

    const current = Number(tempInt.textContent);
    const index = options.indexOf(current);
    const pad = Math.floor(viewport.clientHeight / itemHeight / 2);
    const scrollTop =
      (pad + Math.max(index, 0)) * itemHeight -
      viewport.clientHeight / 2 +
      itemHeight / 2;

    setTimeout(() => {
      viewport.scrollTop = scrollTop;
      highlightNearest();
    }, 50);
  });

  pickerOk.addEventListener("click", () => {
    const selected = viewport.querySelector(".wheel-item.selected");
    if (!selected) return;

    tempInt.textContent = selected.dataset.value;
    tempDec.textContent = ".0";

    bootstrap.Modal.getInstance(modalEl).hide();
  });
})();
