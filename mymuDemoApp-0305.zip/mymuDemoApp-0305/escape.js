/******************************************
 * グローバル変数
 ******************************************/
const AppState = {
  deletingCard: null,
  deletingType: null,
  deleteContext: null,
  editActionId: null,
  selectedScene: null,
  isEdited: false
};

/******************************************
 * ユーティリティ：全画面
 * 対象：トグルスイッチ（button要素内にあるスイッチ）
 * アクション：クリック時の伝播を防ぐ
 ******************************************/
document.querySelectorAll(".form-check-input").forEach((toggle) => {
  toggle.addEventListener("click", (e) => {
    e.stopPropagation();
  });
});


/******************************************
 * ユーティリティ：モーダルフォーカス解除
 * 対象：modal.html のモーダル
 * アクション：モーダルをクローズ後のフォーカス解除
 ******************************************/
window.addEventListener("hide.bs.modal", () => {
  document.activeElement.blur();
});




// EVENT LISTENER（クリックイベント統合）
document.addEventListener("click", (e) => {
  let btn;



  // btn = e.target.closest(".js-add-automation");
  // if (btn)  handleAddAutomationClick(btn);


  btn = e.target.closest(".js-add-action-btn");
  if (btn)  handleAddActionButtonClick(btn);


  btn = e.target.closest(".js-editable");
  if (btn)  markEdited();

  btn = e.target.closest(".js-drive");
  if (btn) handleDriveClick(btn);

  btn = e.target.closest(".js-mode");
  if (btn) handleModeClick(btn);  

  btn = e.target.closest(".js-delete-automation");
  if (btn) return handleDeleteAutomationClick();

  entryBtn = e.target.closest(".entry-device-card");
  if (entryBtn) return handleSetEntryDeviceCard(entryBtn);

});

// 機器の状態を追加（trigger）／機器の操作を追加（action）のどちらが入口が判定
function handleSetEntryDeviceCard(entryBtn) {
  const key = entryBtn.dataset.appKey;
  setJsonValue("entryDeviceCard", key);
  window.location.href = "../select-device/";
}

// トリガーイベントセクションのカードの編集・削除ボタンのクリックイベント
function handleDeleteAutomationClick() {
  showModal("deleteAutomationModal");
}



// アクション追加のカードボタンをクリック（シーン／機器／通知）
function handleAddActionButtonClick(btn) {
  const section = btn.dataset.appAction;

  // devices のときだけ入口状態を保存
  if (section === "devices") {
    setJsonValue("entryDeviceCard", "action");
  }

  const url = ACTION_SELECT_URL[section];
  if (url) {
    window.location.href = url;
  }
}


// 完了ボタンの処理（編集された後、完了ボタンが活性化）
function markEdited() {
  if (AppState.isEdited) return;
  AppState.isEdited = true;
  const headerBtn = document.getElementById("headerRightBtn");
  if (!headerBtn) return;

  headerBtn.disabled = false;
  headerBtn.classList.remove("disabled");
  headerBtn.classList.add("active");
};

// エアコン・給湯機設定画面のクリックイベント（運転）
function handleDriveClick(btn){
  const drive = btn.dataset.appDrive;
  const entryId = getJsonValue("entryId");
  const actionId = getJsonValue("editActionId");
  const actions = getJsonValue(`${entryId}.actions`) ?? [];
  const action = actions.find(a => a.actionId === actionId);
  if(!action) return;

  /* JSON保存 */
  action.drive = drive;
  
  setJsonValue(`${entryId}.actions`, actions);

  /* UI排他 */
  document.querySelectorAll(".js-drive").forEach(el=>{
    const isActive = el.dataset.appDrive === drive;
    el.classList.toggle("active",isActive);
    el.setAttribute("aria-pressed",String(isActive));
  });
}

// エアコン設定画面のクリックイベント（モード）
function handleModeClick(btn){
  const mode = btn.dataset.appMode;
  const entryId = getJsonValue("entryId");
  const actionId = getJsonValue("editActionId");
  const actions = getJsonValue(`${entryId}.actions`) ?? [];

  const action = actions.find(a => a.actionId === actionId);
  if(!action) return;

  /* JSON保存 */
  action.mode = mode;
  setJsonValue(`${entryId}.actions`, actions);

  /* UI排他 */
  document.querySelectorAll(".js-mode").forEach(el=>{
    const isActive = el.dataset.appMode === mode;
    el.classList.toggle("active",isActive);
    el.setAttribute("aria-pressed",String(isActive));
  });
}

// オートメーション削除の確認モーダルの「削除する」ボタンをクリック
document.addEventListener("click", (e) => {
  const btn = e.target.closest("#confirmDeleteAutomationBtn");
  if (!btn) return;
  deleteAutomation();
});

// オートメーション削除関数
function deleteAutomation() {
  setJsonValue("new.status", false);
  window.location.href = "../automation/";
}












// アクションカードのクリックイベント
document.addEventListener("click", e => {
  const card = e.target.closest(".action-card");
  if (!card) return;

  const url = card.dataset.actionUrl;
  const actionId = card.dataset.actionId;
  if (!url) return;

  // 編集対象保存
  setJsonValue("editActionId", actionId);
  // 遷移
  window.location.href = url;
});

// アクションカードの内容を編集画面に反映させる
function initDeviceEditor() {

  const entryId = getJsonValue("entryId");
  const actionId = getJsonValue("editActionId");
  const actions = getJsonValue(`${entryId}.actions`) ?? [];
  const action = actions.find(a => a.actionId === actionId);
  if (!action) return;

  // デフォルト値（必要に応じて変更してください）
  const defaults = { drive: "on", mode: "冷房", temp: 28 };

  // UI に渡す値を nullish coalescing で決定
  const drive = action.drive ?? defaults.drive;
  const mode = action.mode ?? defaults.mode;
  const temp = action.temp ?? defaults.temp;

  setDeviceName(action.id);
  setDriveButton(drive);
  setModeSelect(mode);
  setTempInput(temp);
}

function setDeviceName(deviceId) {
  const el = document.getElementById("deviceName");
  if (!el) return;
  const name = DEVICE_MASTER[deviceId]?.label ?? "（未設定）";
  el.textContent = name;
}

function setDriveButton(drive) {
  document.querySelectorAll(".js-drive").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.appDrive === drive);
  });
}

function setModeSelect(mode) {
  document.querySelectorAll(".js-mode").forEach((btn) => {
    const isActive = btn.dataset.appMode === mode;
    btn.classList.toggle("active", isActive);
    btn.setAttribute("aria-pressed", String(isActive));
  });
}

function setTempInput(temp) {
  const input = document.getElementById("racSettingTemperature");
  if (!input) return;
  input.textContent = `${temp ?? ""}℃`;
}

function initNotifyEditor() {
  const entryId = getJsonValue("entryId");
  const actionId = getJsonValue("editActionId");
  const actions = getJsonValue(`${entryId}.actions`) ?? [];
  const action = actions.find(a => a.actionId === actionId);
  if (!action || action.type !== "notify") return;

  /* ===== 機器名 ===== */
  const deviceNameEl =
    document.getElementById("notifyDeviceName");

  if (deviceNameEl) {
    deviceNameEl.textContent =
      DEVICE_MASTER[action.id]?.label ?? "（未設定）";
  }


  /* ===== メッセージ ===== */
  const input =
    document.getElementById("notifyMessageInput");

  if (input) {

    input.value = action.message ?? "";
  }
}

document.addEventListener("DOMContentLoaded", () => {
  initDeviceEditor();   // 機器画面の場合
  initNotifyEditor(); // 通知画面の場合
});


function goRoomTempStatus() {
  // 遷移先のURLを設定
  const url = "../select-room-temperature-status/";
  window.location.href = url;
};


// 完了ボタン処理
const initCompleteButton = () => {
  const btn = document.getElementById("headerRightBtn");
  if (!btn) return;
  AppState.isEdited = false;
  btn.disabled = true;
  btn.classList.add("disabled");
};

// トリガーカードボタンの処理（ゴミ箱アイコン／ボタン本体）
document.addEventListener("DOMContentLoaded", () => {
  const section = document.getElementById("devicesSection");
  if (!section) return;
  // ゴミ箱アイコン
  section.addEventListener("click", (e) => {
    const deleteBtn = e.target.closest(".delete-trigger-card-btn");
    if (deleteBtn) {
      e.preventDefault();
      e.stopPropagation();
      showModal("deleteTriggerCardButton");
      return; // ここで終了
    }
    // カード本体
    const cardBtn = e.target.closest(".trigger-card-button");
    if (cardBtn) {
      window.location.href = "../select-device-operation/";
    }
  });
});

// トリガーカードボタンのモーダル表示関数（削除確認用）
document.addEventListener("click", (e) => {
  const btn = e.target.closest("#confirmActionCardDeleteBtn");
  if (!btn) return;

  const modalEl = document.getElementById("deleteTriggerCardButton");
  const modal = bootstrap.Modal.getInstance(modalEl);
  // トリガーカードボタンを削除する関数
  deleteTriggerCard();
  if (modal) modal.hide();
});

// トリガーカードボタンを削除する（JSON書き換え⇒再読み込み）
const deleteTriggerCard = () => {
  const entryId = getJsonValue("entryId");
  const triggers = getJsonValue(`${entryId}.triggers`);
  if (triggers && triggers.devices) {
    delete triggers.devices;
    setJsonValue(`${entryId}.triggers`, triggers);
  }
  // 再描画
  renderAutomationEditing();
}

// アクションカードボタンの処理（ゴミ箱アイコン／ボタン本体）
document.addEventListener("DOMContentLoaded", () => {
  const section = document.getElementById("actionCardArea");
  if (!section) return;
  section.addEventListener("click", (e) => {
    const deleteBtn = e.target.closest(".delete-action-card-btn");
    if (!deleteBtn) return;

    e.preventDefault();
    e.stopPropagation();

    const card = deleteBtn.closest(".action-card");
    if (!card) return;

    AppState.deleteActionId = card.dataset.actionId;
    showModal("deleteActionCardButton");
  });
});
// アクションカードボタンを削除する（JSON書き換え⇒再読み込み）
function deleteActionCard() {
  const entryId = getJsonValue("entryId");
  const actionId = AppState.deleteActionId;
  if (!actionId) return;

  let actions = getJsonValue(`${entryId}.actions`) ?? [];
  actions = actions.filter(action => action.actionId !== actionId);
  setJsonValue(`${entryId}.actions`, actions);
  AppState.deleteActionId = null;
  renderAutomationEditing();
  updateCompleteButtonState();
}

// アクションカード削除用モーダルの削除ボタンをクリックしたとき関数を呼び出す
document.addEventListener("click", (e) => {
  const btn = e.target.closest("#confirmDeleteActionCardButton");
  if (!btn) return;

  const modalEl = document.getElementById("deleteActionCardButton");
  const modal = bootstrap.Modal.getInstance(modalEl);
  // アクションカードを削除する関数
  deleteActionCard();
  if (modal) modal.hide();
});

// シーン設定画面のレンダリング
const renderSetupScene = () => {

  const entryId = getJsonValue("entryId");
  const actionId = getJsonValue("editActionId");

  const actions = getJsonValue(`${entryId}.actions`) ?? [];
  const action = actions.find(a => a.actionId === actionId);

  if (!action || action.type !== "scene") return;

  const sceneId = action.id;

  /* シーン名 */
  const sceneNameEl = document.getElementById("sceneName");
  if (sceneNameEl) {
    sceneNameEl.textContent = SCENE_MASTER[sceneId]?.label ?? "";
  }

  /* 全非表示 */
  document
    .querySelectorAll(".allOff,.sleep,.returnWinter")
    .forEach(el => el.classList.add("d-none"));

  /* 対象表示 */
  document
    .querySelectorAll(`.${sceneId}`)
    .forEach(el => el.classList.remove("d-none"));

};

// 「シーンを選択」 画面からの遷移
document.addEventListener("DOMContentLoaded", () => {

  const section = document.querySelector(".js-select-scene-section");
  if (!section) return;

  section.addEventListener("click", (e) => {

    const sceneBtn = e.target.closest(".js-select-scene-btn");
    if (!sceneBtn) return;

    const sceneId = sceneBtn.dataset.appKey;
    const entryId = getJsonValue("entryId");

    let actions = getJsonValue(`${entryId}.actions`) ?? [];

    if (actions.length >= 5) return;

    // 追加
    actions.push({
      actionId: createId(),
      type: "scene",
      id: sceneId
    });

    const actionId = actions[actions.length - 1].actionId;
    setJsonValue(`${entryId}.actions`, actions);
    setJsonValue("editActionId", actionId);

    window.location.href = "../setup-scene/";
  });

});

// 「機器の操作を選択」「機器の状態を追加」 ボタンからの遷移
document.addEventListener("DOMContentLoaded", () => {

  const section = document.querySelector(".js-select-device-section");
  if (!section) return;

  section.addEventListener("click", (e) => {

    const deviceBtn = e.target.closest(".js-select-device-btn");
    if (!deviceBtn) return;

    const deviceId = deviceBtn.dataset.appDevice;
    const entryDeviceCard = getJsonValue("entryDeviceCard");   // trigger / action
    const entryId = getJsonValue("entryId");
    

    if (!entryId) return;

    const device = getJsonValue(`${entryId}.triggers.devices`);
        console.log(device);
    

    /* -----------------------------
       トリガー（機器状態）
    ----------------------------- */

    if (entryDeviceCard === "trigger") {

      setJsonValue(`${entryId}.triggers.devices`, {
        id: deviceId
      });

      // const url = ACTION_MASTER.devices[deviceId]?.url;
      // const url = "../select-device-operation/";

      // if (url) window.location.href = url;

      return;
    }

    /* -----------------------------
       アクション（機器操作）
    ----------------------------- */

    let actions = getJsonValue(`${entryId}.actions`) ?? [];

    if (actions.length >= 5) return;

    actions.push({
      actionId: createId(),
      type: "devices",
      id: deviceId
    });

    const actionId = actions[actions.length - 1].actionId;

    setJsonValue(`${entryId}.actions`, actions);
    setJsonValue("editActionId", actionId);

    const url = ACTION_MASTER.devices[deviceId]?.url;
    // if (url) window.location.href = url;

  });

});




function deleteBtnState(entryId) {
  // const entryId = getJsonValue("entryId");
  const btn = document.querySelector(".js-delete-automation");
  if (!btn) return;

  if (entryId !== "new") {
    btn.style.display = "none";
    return;
  }
  const status = getJsonValue("new.status");
  btn.style.display = status ? "block" : "none";
} 

// 完了ボタンの制御関数（entryIdがnewのとき、actionsの数に応じて活性化）
function updateCompleteButtonState(entryId) {
  if (entryId !== "new") return false;
  const actions = getJsonValue("new.actions");
  return Array.isArray(actions) && actions.length > 0;
};

function updateDriveState(isDriveOn) {
  const modeSection = document.getElementById("modeSection");
  const tempSection = document.getElementById("temperatureSection");
  if (!modeSection || !tempSection) return;

const modeButtons = modeSection.querySelectorAll(".js-mode");
const changeBtn = tempSection.querySelector("#changeBtn");
  if (isDriveOn) {
    modeSection.classList.remove("section-disabled");
    modeSection.classList.add("bg-body");
    tempSection.classList.remove("section-disabled");
    tempSection.classList.add("bg-body");
    changeBtn.classList.add("fc-active");
    initDeviceEditor(); // 運転がONのとき、モードと温度の初期値をセットする
  } else {
    modeSection.classList.add("section-disabled");
    modeSection.classList.remove("bg-body");
    tempSection.classList.add("section-disabled");
    tempSection.classList.remove("bg-body");
    changeBtn.classList.remove("fc-active");
    // モードのactiveを全解除
    modeButtons.forEach(btn => {
      btn.classList.remove("active");
    });

  }
}

document.addEventListener("click", function (e) {
  const btn = e.target.closest(".js-drive");
  if (!btn) return;
  const isDriveOn = btn.dataset.appIsDrive === "true";
  updateDriveState(isDriveOn);
});


// function renderTriggerDeviceCard() {

//   // const entryId = getJsonValue("entryId");
//   // if (entryId !== "new") return;

//   const trigger = getJsonValue("new.triggers.devices");
//   if (!trigger) return;

//   const container = document.querySelector(".js-trigger-section");
//   if (!container) return;


//   const template = document.querySelector(".js-trigger-device-template");
//   if (!template) return;

//   const clone = template.cloneNode(true);

//   clone.classList.remove("d-none", "js-trigger-device-template");

//   const deviceName = DEVICE_MASTER[trigger.id]?.name ?? "";
//   clone.querySelector(".device-name").textContent = deviceName;

//   container.appendChild(clone);
// }


// function renderActionCards() {

//   // const entryId = getJsonValue("entryId");
//   // if (entryId !== "new") return;

//   const actions = getJsonValue("new.actions") ?? [];

//   const container = document.querySelector(".js-action-section");
//   if (!container) return;

//   const template = document.querySelector(".js-action-template");
//   if (!template) return;


//   container.innerHTML = "";

//   actions.forEach(action => {

//     const clone = template.cloneNode(true);

//     clone.classList.remove("d-none", "js-action-template");

//     const deviceName = DEVICE_MASTER[action.id]?.name ?? "";

//     clone.querySelector(".device-name").textContent = deviceName;

//     container.appendChild(clone);

//   });
// }