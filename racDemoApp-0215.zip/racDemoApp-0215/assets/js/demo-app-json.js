const initialAppData = {
  currentPage: "basic", // 表示画面
  currentMode: "ai-auto-cooling", // 運転モード（cooling, dehumidifying, heating, perflation, ai-auto-cooling, ai-auto-heating）
  automationMode: "",
  // currentHeaderSet: "headerSet01", //
  lastUpdated: "20xx/07/01 11:15", // 最終更新日時
  isThermalImageManagement: true, // 熱画像管理ON/OFF　(true　|　false)
  isTouchAirflow: true, // タッチ気流ON/OFF　(true　|　false)
  isAutoMationSetDone: false, // オートメーション機能　有効/無効　(true　|　false)
  modalDrive: {
    isRunning: true, // true ⇔ false
    label: "停止",
  },
  driveModeSelectBtn: {
    // 運転モード選択ボタン状態, 温度・湿度・除湿表示
    cooling: {
      label: "冷房",
      icon: "../assets/img/home-icon-btn-cooling.svg",
      style: "btn-cooling",
      settingDisplay: "text-cooling",
    },
    dehumidifying: {
      label: "除湿",
      icon: "../assets/img/home-icon-btn-dehumidification.svg",
      style: "btn-dehumidifying",
      settingDisplay: "text-dehumidifying",
    },
    heating: {
      label: "暖房",
      icon: "../assets/img/home-icon-btn-heating.svg",
      style: "btn-heating",
      settingDisplay: "text-heating",
    },
    perflation: {
      label: "送風",
      icon: "../assets/img/home-icon-btn-perflation.svg",
      style: "btn-perflation",
      settingDisplay: "text-perflation",
    },
    "ai-auto-cooling": {
      label: "A.I.自動(冷房)",
      icon: "../assets/img/home-icon-btn-ai-auto.svg",
      style: "btn-ai-auto",
      settingDisplay: "text-ai-auto",
    },
    "ai-auto-heating": {
      label: "A.I.自動(暖房)",
      icon: "../assets/img/home-icon-btn-ai-auto.svg",
      style: "btn-ai-auto",
      settingDisplay: "text-ai-auto",
    },
  },
  headerSet: {
    // ヘッダーセット
    basic: {
      left: {
        type: "drawer",
      },
      title: "リビング",
      right: {
        visible: false,
      },
    },
    headerSet02: {
      left: {
        type: "back",
      },
      title: "スケジュール",
      right: {
        text: "完了",
        action: "schedule-done",
        visible: true,
      },
    },
    touchAirflow: {
      left: {
        type: "back",
      },
      title:
        'タッチ気流<i class="bi bi-question-circle-fill ms-1 text-secondary"></i>',
      right: {
        text: "決定",
        action: "touch-airflow-back",
        bordered: true,
        visible: true,
      },
    },
    thermalImage: {
      left: {
        type: "back",
      },
      title:
        '熱画像<i class="bi bi-question-circle-fill ms-1 text-secondary"></i>',
      right: {
        visible: false,
      },
    },
    headerSet04: {
      left: {
        type: "back",
      },
      title:
        '換気アシスト設定<i class="bi bi-question-circle-fill ms-1 text-secondary"></i>',
      right: {
        text: "完了",
        action: "done",
        target: "",
        visible: true,
      },
    },
    setTheWindowPositions: {
      left: {
        type: "back",
      },
      title: "窓位置設定",
      right: {
        text: "決定",
        action: "back",
        visible: true,
      },
    },
    thermalImageManagement: {
      left: {
        type: "back",
      },
      title: "熱画像管理",
      right: {
        visible: false,
      },
    },
    electricityBillCheck: {
      left: {
        type: "back",
      },
      title: "電気代チェック",
      right: {
        text: "設定",
        action: "link",
        target: "../electricity-bill-check-settings/",
        visible: true,
      },
    },
    electricityRateSettings: {
      left: {
        type: "back",
      },
      title: "電気代単価設定",
      right: {
        text: "編集",
        action: "alert",
        visible: true,
      },
    },
    electricityBillCheckSettings: {
      left: {
        type: "back",
      },
      title: "電気代チェック",
      right: {
        visible: false,
      },
    },
    targetElectricityCostSettings: {
      left: {
        type: "back",
      },
      title: "目標電気代設定",
      right: {
        action: "link",
        target: "../electricity-bill-check-settings/",
        visible: false,
      },
    },
    operatingHistory: {
      left: {
        type: "back",
      },
      title: "運転履歴",
      right: {
        text: "設定",
        action: "alert",
        target: "",
        visible: true,
      },
    },
    maintenance: {
      left: {
        type: "back",
      },
      title: "メンテナンス",
      right: {
        text: "",
        action: "",
        target: "",
        visible: false,
      },
    },
    headerSet14: {
      left: {
        type: "back",
      },
      title: "エアコン製品情報",
      right: {
        text: "",
        action: "",
        target: "",
        visible: false,
      },
    },
    headerSet15: {
      left: {
        type: "back",
      },
      title: "製品情報の登録",
      right: {
        text: "",
        action: "",
        target: "",
        visible: false,
      },
    },
    optionalFeatureSettings: {
      left: {
        type: "back",
      },
      title: 'オプション機能設定 <svg width="18" height="18" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.083 1C15.1223 1 19.1668 5.04378 19.167 10.083C19.167 15.1224 15.1224 19.167 10.083 19.167C5.04378 19.1668 1 15.1223 1 10.083C1.00017 5.04389 5.04389 1.00017 10.083 1Z" stroke="black" stroke-width="2"/><circle cx="10.083" cy="6.08203" r="1" fill="black"/><rect x="9.08301" y="8.08203" width="2" height="7" rx="1" fill="#646464"/></svg>',
      right: {
        text: "",
        action: "",
        target: "",
        visible: false,
      },
    },
    headerSet17: {
      left: {
        type: "back",
      },
      title: "機器情報",
      right: {
        text: "",
        action: "",
        target: "",
        visible: false,
      },
    },
    headerSet18: {
      left: {
        type: "back",
      },
      title: "お知らせ",
      right: {
        text: "",
        action: "",
        target: "",
        visible: false,
      },
    },
    headerSet19: {
      left: {
        type: "back",
      },
      title: "チュートリアル",
      right: {
        text: "",
        action: "",
        target: "",
        visible: false,
      },
    },
    headerSet20: {
      left: {
        type: "back",
      },
      title: "アプリ情報",
      right: {
        text: "",
        action: "",
        target: "",
        visible: false,
      },
    },
  },
  electricityBill: { // 電気代
    isSelected: true,
    period: {
      yearly: {
        isSelected: true,
      },
      monthly: {
        isSelected: false,
      },
    },
  },
  electricityConsumption: { // 電気量
    isSelected: false,
    period: {
      yearly: {
        isSelected: true,
      },
      monthly: {
        isSelected: false,
      },
    },
  },
  // スケジュール設定
  schedule: [
    {
      id: 3,
      name: "スケジュール",
      startTime: "08:00",
      dayOfTheWeek: {
        sun: false,
        mon: false,
        tue: false,
        wed: false,
        thu: false,
        fri: false,
        sat: false,
      },
      dayOfTheWeekLabel: "",
      isDrive: true,
      mode: "冷房",
      setValue: "27.0",
    },
  ],
};

function storeJsonData() {
  try {
    sessionStorage.setItem("appData", JSON.stringify(initialAppData));
    // リダイレクト先に移動
    window.location.href = "./home/";
  } catch (error) {
    showAlert("JSONデータの保存に失敗しました。", "error");
  }
}

storeJsonData();
