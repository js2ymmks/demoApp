redoc-cli_インストール手順&html出力方法

◆redoc-cliインストール方法
> npm install -g redoc-cli


◆html出力方法
> redoc-cli bundle api.yaml -o output/MyMUクラウドアプリ_APIリファレンス.html


