# 概要

## 設計書一覧

本書はMyMUアプリの以下に関するソフトウェア設計をまとめたものである。

- MyMUホーム

|画面設計||機能設計|
|---|---|---|
|[c6400 MyMUホーム](./ui_design/c6400_mymu_home.md)|![](./ui_design/img/mymuHome.png) { width="200" }|画面生成|
|[c6a00 ソリューションカード一覧](./ui_design/c6a00_solution_card.md)|![](./ui_design/img/solutionCard.png) { width="200" }|ソリューションカード一覧画面表示|

## 関連文書

- IoT共通プラットフォーム（B2C）システム設計書
- IoT共通プラットフォーム（B2C）ソフトウェア設計書
- MyMUアプリ　システム設計書
- MyMUクラウド　ソフトウェア設計書
- MyMUクラウド　DB設計書
- MyMUクラウド　APIリファレンス
- MyMUスマホアプリ　ソフトウェア設計書※本書