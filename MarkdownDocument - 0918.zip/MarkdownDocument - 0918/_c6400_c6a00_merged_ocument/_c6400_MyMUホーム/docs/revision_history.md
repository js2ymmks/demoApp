# 改訂履歴
本誌はD1版より画面仕様書_c6400_MyMUホーム　と　画面仕様書_c6401_MyMUホーム_個別機器にて分冊。それ以前は画面仕様書_c6400_MyMEホーム参照のこと。

## 改訂履歴

<!-- {{ read_excel('./ui_design/table/table.xlsx', sheet_name='revisionHistory') }} -->