# 画面設計

## c6a00 ソリューションカード一覧

### 画面仕様
以下に画面仕様を記す。規定のないUI仕様(色、部品、サイズ(部品・フォント)、配置等)についてはレイアウトデータに従う。

#### 構成部品
##### 部品詳細
![構成部品](./img/partDetails.png){ width="300" }
/// caption
部品詳細
///

##### 部品詳細（ソリューションカード）
![構成部品](./img/partDetailsSolutionCard.png){ width="300" }
/// caption
部品詳細（ソリューションカード）
///

##### 部品詳細（固定領域）
![構成部品](./img/partDetailsFixedArea.png){ width="300" }
/// caption
部品詳細（固定領域）
///

##### 簡易表示モード
![簡易表示モード](./img/simplifiedDisplayMode.png){ width="300" }
/// caption
簡易表示モード
///

| No. | 大項目(エリア) | 中項目 | 部品タイプ | 表示値 | 表示・非表示 | ボタン活性・非活性 | 備考 |
|---|---|---|---|---|---|---|---|
| 40 | メインエリア | ソリューションカード | カード | AngularMaterialのCardを使用する。 | 4.1.1 表示・非表示条件に従う | 4.2.1 非活性条件に従う | ・部品[40]は[グローバル変数]ソリューションカード登録数表示する。<br >・[内部変数]ソリューションカードリストの先頭からリストの並び順で表示する。<br >・カードの横幅は端末の横幅に併せて可変とする。 |
| 　 | 　 | 　 | 　 | 3.3 ソリューションカード仕様に従う | 　 | 　 | 　 |
| 50 | 　 | ソリューションカード(固定領域) | - | - | - | - | 　 |
| 51 | 　 | ソリューションアイコン | イメージ | [内部変数]ソリューションカードリスト.ビュー情報.ビュー種別IDと一致する[内部変数]ビュー情報リスト.ビューアイコンの値 | - | - | 　 |
| 52 | 　 | ソリューションカード名 | ラベル | [内部変数]ソリューションカードリスト.ソリューションカード名の値 | - | - | ・部品[53]非表示時、部品[52]は部品[51]の高さに対してセンタリング配置する。<br >・端末の横幅に合わせて横幅を可変とする。<br >パーツ内に文字列が収まらない場合は、最後の文字を「…」で表示すること。 |
| 53 | 　 | 権限状態 | ラベル | MES-B19 | 4.1.1 表示・非表示条件に従う | - | 　 |
| 60 | 　 | ソリューションカード(個別アプリ自由領域) | インラインフレーム | iframeに指定する要素は以下。      ①src：埋め込みページURL      ②width：フレーム幅      ③height：フレーム高 | 4.1.1 表示・非表示条件に従う | - | 　 |
| 　 | 　 | 　 | 　埋め込みページURL | [内部変数]インラインフレーム要素リスト.ソリューションアプリURL | 　 | 　 | 　 |
| 　 | 　 | 　 | 　フレーム幅 | 部品[40]の横幅 | 　 | 　 | 　 |
| 　 | 　 | 　 | 　フレーム高 | [内部変数]インラインフレーム要素リスト.フレーム高 | 　 | 　 | 　 |
| 　 | 　 | 　 | 前景色 | 4.1.3 表示色条件に従う | 　 | 　 | 　 |
/// caption
部品詳細
///

### ソリューションカード仕様
![ソリューションカード仕様](./img/solutionCardSpecifications.png){ width="600" }
/// caption
ソリューションカード仕様
///

### ソリューションカード処理(フロー)
#### 画面遷移
![ソリューションカード処理(フロー)](./img/solutionCardProcessingFlow.png){ width="600" }
/// caption
ソリューションカード処理(フロー)
///

#### 簡易メニュー
![簡易メニュー](img/simpleMenu.png){ width="600" }
/// caption
簡易メニュー
///

### ソリューションカード処理(シーケンス)
#### ソリューションアプリ起動処理
![ソリューションアプリ起動処理](img/solutionAppLaunchProcess.png){ width="600" }
/// caption
ソリューションアプリ起動処理
///

### インラインフレーム
ソリューションカードには、各ソリューションアプリ(個別アプリ)をインラインフレーム(iframe)で表示する。
MyMUは、個別アプリからのpostMessage(iframe通知)によって、iframeの表示を切り替える。
MyMUアプリの責務を以下に示す。

1. 各個別アプリの指定画面表示  
以下イベントを検知し、MyMUはiframeで個別アプリの指定画面を呼び出す。  
      - c6a00画面への遷移
      - c6a00画面で下スワイプ操作
      - 定周期タイマー満了  
            個別アプリからのonload()イベントを受信し、通知内容が成功を示す場合、iframe内の表示を更新する。
            なお、個別アプリはキャッシュしないこととする。

1. 個別アプリから通知されたエラーのハンドリング  
      個別アプリからのiframe通知が失敗を示す場合、対象のiframe上に共通的なエラー表示をする(3.1 図3.1(d3))。  
      ※個別アプリの表示内容についてMyMUはハンドリングしない。

1. ifame上のローディング表示・非表示  
- ソリューションタブタップ時または下スワイプ操作時に、MyMUはifame上にローディングを表示する。  
- 個別アプリからifame通知が到達すると、ローディングを非表示にする。  
- 指定画面の呼び出し時に個別アプリからの応答が一定時間(30秒)ない場合はエラーとし、②と同じエラー表示を行う。

![iframe](img/inlineFrame.png){ width="600" }
/// caption
iframe
///

#### iframe通知の種類
iframe通知のmessageはJSON形式とし、以下keyの種類を持つ。

| No. | key名称 | 値 | 内容 |
|---:|---|---|---|
| 1 | iframe状態(iframeStatus) | ~~succeeded~~ | ~~Webアプリ側の処理が成功したことを示す。~~<br />~~インラインフレーム上のWebアプリの表示を更新する。~~ |
| 2 |  | failed | Webアプリ側の処理に何らかのエラーが発生し、失敗したことを示す。<br />インラインフレーム上にエラーを表示する。 |

#### 表示シーケンス
![表示シーケンス](img/displaySequence.png){ width="600" }
/// caption
表示シーケンス
///

### 別紙
iFrameElementList.solutionAppUrl の生成処理について本シートで処理仕様を明記する。

#### Ver4.2までの処理
- `apps.json`の`path`の前半部分と、`viewDetailsData_qa.json`の`iframeComponent`を組合せる。  
- 部品[60]に指定する埋め込みページURL(src)には、iframe表示画面(undefinedでない場合)を連接し、さらに以下をクエリとして連接したURLエンコード済みのURLとする。

``` json title="apps.json"
{
  "id": "meamor",  "name": "MeAMORアプリ",
  "type": "cloud",
  "viewTypeId": ["meamorObserver", "meamorObserved"],
  "path": "https://melco-myme-webcontents-dev2.com/home/mymu/mea/index.html#/meamor"

},
```

``` json title="viewDetailsData_qa.json"
{	
  "viewTypeId": "meamorObserver",	
  "iframeComponent": "/cg800-card-status-screen-view",	
　　　・・・・	
}
```

``` text title="solutionAppUrl"
solutionAppUrl = "https://melco-myme-webcontents-dev2.com/home/mymu/mea/index.html#/cg800-card-status-screen-view"
```

例２）kuraToku（他のURLページ）

``` json title="apps.json"
{
  "id": "kuraToku",  "name": "くらトク",
  "type": "other",
  "viewTypeId": ["kuraToku"],
  "path": "https://kuratoku-202308-stg.empowerment-jp.com/"
},
```

``` json title="viewDetailsData_qa.json"
{	
  "viewTypeId": "kuraToku",	
  "iframeComponent": "/assets/html/mymu/kuratoku.html",	
　・・・・	
}
```

``` text title="solutionAppUrl"
solutionAppUrl = "https://kuratoku-202308-stg.empowerment-jp.com/assets/html/mymu/kuratoku.html"
```

#### Ver4.3 での追加仕様
`apps.json`のURLに、新たなキー`path_iframe`が存在する場合は、`solutionAppUrl`の作成する際に、`path_iframe`を用いること。`path_iframe`のキーが存在しない場合は、これまで通り、例１）、例２）で処理すること。	
  
経緯）  
`apps.json`の`path`は、カードタップ時に、ブラウザ表示するURLが記載されているが、タップ時のURLと、`iframe` のURLが根本的に違うケースに対応するために、`iframe` 用のパスを追加した。6A00のソリューションカードタップ時の動作は、これまで通りであるので、影響しないこと。	

例３）kuraTokuHC（タップは他のURL、iframe はWebアプリ））


``` json title="apps.json"
{	
  "id": "kuraToku",  "name": "くらトク",	
  "type": "other",	
  "viewTypeId": ["kuraToku"],	
  "path": "https://kuratoku-202308-stg.empowerment-jp.com/"	// 6A00 のカードタップ時に用いる
  "path_iframe": "home/mymu/order/index.html#"              // 6A00 のiframe 用のURL
},	
```

``` text title="solutionAppUrl"
solutionAppUrl = 「apps.json の path_iframe」
```

### 改訂履歴

| 副版  | 改定箇所 | 改定内容                                      | 改訂日   | 改訂者      |
|-------|----------|-----------------------------------------------|----------|-------------|
| X.X版 | －       | 新規作成                                      | YY/MM/DD  | リソ推 ○○○ |
