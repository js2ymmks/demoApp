# API仕様作成用 CSV 運用ルール

## 目的

CSVファイルを原稿として、既存の `api.yaml` の形式を参考に OpenAPI/Swagger 形式のAPI仕様を1件ずつ作成する。

対象は、関数・外部IF定義をAPI仕様として整理する作業である。

## 基本方針

- CSVはチェック用の原稿として使用する。
- APIは1件ずつCSVで渡す。
- 見出しは日本語のまま使用する。
- 値が空のCSVでも、キー構造が正しければテンプレートとして認識する。
- セル内改行は使用してよい。
- 運用中に読み取りづらい箇所が出た場合は、都度ルールを調整する。

## CSVの基本構造

CSVは以下のキーを持つ。

```csv
path,
定義,
名称,
機能,
引数,パラメータ型
引数,パラメータ名
引数,[I/O]
引数,意味・範囲
戻り値,
制約/注意事項,
詳細仕様,
```

## 階層構造

通常項目は1階層で扱う。

- path
- 定義
- 名称
- 機能
- 戻り値
- 制約/注意事項
- 詳細仕様

引数のみ2階層で扱う。

```csv
引数,パラメータ型
引数,パラメータ名
引数,[I/O]
引数,意味・範囲
```

## 引数の繰り返しルール

1引数は4行1セットとする。

```csv
引数,パラメータ型
引数,パラメータ名
引数,[I/O]
引数,意味・範囲
```

引数が複数ある場合は、この4行セットを繰り返す。

例: 引数2件

```csv
引数,パラメータ型
引数,パラメータ名
引数,[I/O]
引数,意味・範囲
引数,パラメータ型
引数,パラメータ名
引数,[I/O]
引数,意味・範囲
```

引数が4件以上ある場合も、同じ形式で4行セットを追加する。

## CSV項目とOpenAPI項目の対応

| CSV項目 | OpenAPIでの主な対応先 | 備考 |
|---|---|---|
| path | `paths` 配下のキー | `/v1/view/loading` のようなAPI path候補を記載する |
| 定義 | `operationId` 相当 | メソッド名として扱う。括弧なしで記載する |
| 名称 | `summary` | APIの短い説明 |
| 機能 | `description` | APIの機能説明 |
| 引数 / パラメータ型 | `parameters[].type` または `parameters[].schema.type` | `string`, `number`, `object`, `array` などに変換する |
| 引数 / パラメータ名 | `parameters[].name` または `schema.properties` のキー | body内項目の場合は `properties` に入れる |
| 引数 / [I/O] | `parameters[].in` または入出力区分の補足 | `I` は入力、`O` は出力として読む。OpenAPI上の `in` は別途 `body`, `query`, `path`, `header` へ整理する |
| 引数 / 意味・範囲 | `parameters[].description` | パラメータ説明 |
| 戻り値 | `responses.200.schema` または `responses.200.description` | 戻り値型や返却内容として扱う。CSV上ではHTTPステータスコードを独立項目として持たず、成功/失敗は戻り値または説明文で表す |
| 制約/注意事項 | `description` の補足 | 注意事項として説明文に追記する |
| 詳細仕様 | `description` の補足 | 参照資料や詳細条件として追記する |

CSVでは、HTTPステータスコードを別項目として持たない。成功/失敗は `戻り値` または `制約/注意事項` に `OK / NG` などの表現で記載し、OpenAPIへ変換する際に `200`, `400`, `500` などのHTTPステータスコードへ整理する。

## 既存api.yamlで参考にする構造

既存の `api.yaml` では、各APIは主に以下の構造で記述されている。

```yaml
paths:
  /v1/sample:
    post:
      tags:
        - サンプル管理
      summary: サンプル追加
      description: サンプルを追加する。
      produces:
        - application/json
      parameters:
        - in: body
          name: body
          description: リクエストボディ
          schema:
            type: object
            properties:
              sampleId:
                type: string
                description: サンプルID
      responses:
        200:
          description: OK/リクエストが成功した。
        400:
          description: Bad Request/リクエストのパラメータが不正。
        500:
          description: Internal Server Error/サーバー内部でエラーが発生した。
```

## `###` の扱い

`api.yaml` 内の以下のような行は、仕様上の本体ではなく、見出しコメント相当として扱う。

```yaml
###
### /users ユーザー管理
###
```

実際のpathは次のような行である。

```yaml
/v1/users:
```

実際のタグ名は次のような行である。

```yaml
tags:
  - ユーザー管理
```

CSVの API通し番号を見出しとして使う場合も同じく、YAML上ではコメント行として扱う。

```yaml
###
### COM_LS02
###
```

これは API 本体ではなく、CSV 原稿の`API通し番号`を識別するための見出しコメントである。実際の API 定義はその後に続く `paths` 配下の `/{path}` や `tags` などで表す。

## セル内改行の扱い

CSVでセル内改行を使う場合は、対象セルをダブルクォートで囲む。

```csv
戻り値,"Observable<string | undefined>
ダイアログ非表示タイミング時に値を返す"
```

セル内にダブルクォートを含む場合は、CSV上では `""` としてエスケープする。

```csv
制約/注意事項,"package.jsonに""anypicker""を定義する必要がある。"
```

## チェック時の確認項目

1件のCSVを受け取ったら、以下を確認する。

- 定義が読めるか
- pathが読めるか
- 名称が読めるか
- 機能が読めるか
- 引数が何件あるか
- 各引数について以下が揃っているか
  - パラメータ型
  - パラメータ名
  - [I/O]
  - 意味・範囲
- 戻り値が読めるか
- 戻り値に `OK / NG` のような成功/失敗の表現が入っているか
- 制約/注意事項が読めるか
- 詳細仕様が読めるか
- 既存の `api.yaml` 形式に落とし込めるか
- CSV上でHTTPステータスコードを独立項目にしていないか

## 注意点

- `[I/O]` の `I` は入力、`O` は出力として読む。
- `定義` はメソッド名として扱い、`showMessageDialog` のように括弧なしで記載する。
- `showMessageDialog()` のような括弧付き表記は、呼び出し例や説明文の中だけで使用する。
- CSVではHTTPステータスコードを独立項目として持たず、`OK / NG` は `戻り値` または `制約/注意事項` で表現する。
- OpenAPIの `in` は `header`, `query`, `path`, `body` のいずれかに整理する必要がある。
- CSVの `[I/O]` とOpenAPIの `in` は完全には同義ではないため、変換時に補正する。
- 関数仕様をHTTP API仕様に変換する場合、pathとHTTP methodは別途判断が必要になる。
- 不明確な場合は、既存の `api.yaml` の近いエンドポイントを参考にする。
