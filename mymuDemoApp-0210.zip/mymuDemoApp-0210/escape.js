/******************************************
 * デフォルト／テンプレート Automation オブジェクト
 ******************************************/
const DEFAULT_AUTOMATION = {
  status: true,
  name: "",
  triggers: [
    {
      type: "schedule",
      startTime: "18:00",
      days: ["mon", "tue", "wed", "thu", "fri"],
    },
  ],
  actions: [],
};

const TEMPLATE_AUTOMATION_1 = {
  status: true,
  name: "高温のおしらせ",
  triggers: [
    {
      type: "product",
    },
  ],
  actions: [],
};

const TEMPLATE_AUTOMATION_2 = {
  status: true,
  name: "低温のおしらせ",
  triggers: [
    {
      type: "product",
    },
  ],
  actions: [],
};

const TEMPLATE_AUTOMATION_3 = {
  status: true,
  name: "おかえりON",
  triggers: [
    {
      type: "location",
      condition: "arrive" // "arrive" | "leave"
    },
  ],
  actions: [],
};

const TEMPLATE_AUTOMATION_4 = {
  status: true,
  name: "おでかけOFF",
  triggers: [
    {
      type: "location",
      condition: "leave" // "leave" | "leave"
    },
  ],
  actions: [],
};

const TEMPLATE_AUTOMATION_5 = {
  status: true,
  name: "エアコン入タイマー",
  triggers: [
    {
      type: "schedule",
      startTime: "17:00",
      days: ["mon", "tue", "wed", "thu", "fri"],
    },
  ],
  actions: [],
};

const TEMPLATE_AUTOMATION_6 = {
  status: true,
  name: "エアコン切タイマー",
  triggers: [
    {
      type: "schedule",
      startTime: "09:00",
      days: ["mon", "tue", "wed", "thu", "fri"],
    },
  ],
  actions: [],
};

/******************************************
 * イニシャライズ：新規オートメーション 画面
 * 対象：カスタムオートメーション作成 ボタン
 * アクション：ボタンをクリックすると、カスタムオートメーション画面へ遷移する
 ******************************************/
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".js-automation-id");
  if (!btn) return;

  const key = btn.dataset.appKey;
  let draftMode;

  if (key === "new") {
    draftMode = {
      mode: "create",
      automationId: null,
    };
  } else if (key.startsWith("temp-")) {
    draftMode = {
      mode: "template",
      automationId: key, // temp-1, temp-2
    };
  } else {
    draftMode = {
      mode: "edit",
      automationId: key, // auto-1, auto-2, auto-3
    };
  }

  sessionStorage.setItem("automationDraftMode",JSON.stringify(draftMode));
  window.location.href = "../edit-automation/";
});

// 作業領域を定義
// グローバル（描画は常にこれを見る）
/******************************************
* 初期データの決定
* automationDraftMode を取得
* モードに応じて draft の元データを決定
* 登録済み / カスタムの場合
  → automation.items[selectedId] をコピー
* 新規の場合
  → DEFAULT オブジェクトを生成
******************************************/
let draftAutomation = null;

const initAutomationDraft = () => {
  const draftInfo = JSON.parse(
    sessionStorage.getItem("automationDraftMode")
  );
  if (!draftInfo) return;

  const { mode, automationId } = draftInfo;

  // appData を取得（edit 用）
  const appData = JSON.parse(sessionStorage.getItem("appData"));

  if (mode === "edit") {
    // 既存オートメーションをクローン
    draftAutomation = structuredClone(
      appData.automation.items[automationId]
    );
  }

  if (mode === "create") {
    // デフォルトから新規作成
    draftAutomation = structuredClone(DEFAULT_AUTOMATION);
  }

  if (mode === "template") {
    // テンプレートを選択
    draftAutomation = structuredClone(
      getTemplateAutomation(automationId)
    );
  }
};

const getTemplateAutomation = (templateId) => {
  const templates = {
    "temp-1": TEMPLATE_AUTOMATION_1,
    "temp-2": TEMPLATE_AUTOMATION_2,
    "temp-3": TEMPLATE_AUTOMATION_3,
    "temp-4": TEMPLATE_AUTOMATION_4,
    "temp-5": TEMPLATE_AUTOMATION_5,
    "temp-6": TEMPLATE_AUTOMATION_6,
  };

  return templates[templateId];
};

// ↓ エントリーポイント ↓
function renderEditAutomationScreen(mode, automationId = null) {
  initAutomationDraft();
  renderAutomationName();
  renderTriggerEventSection();
  renderScheduleStartTime();
  renderScheduleDays();
  renderScheduleDescription();
  renderLocationCondition();
  renderActions();
}
// ↑ エントリーポイント ↑

// オートメーション名
/******************************************
* draftAutomation.name
* input / text に反映
* 
******************************************/
const renderAutomationName = () => {
  const el = document.getElementById("autoName");
  if (!el) return;

  const name = draftAutomation?.name?.trim();

  if (name) {
    el.textContent = name;
  } else {
    el.textContent = "オートメーション名（未設定）";
  }
};

/******************************************
 * レンダリング：カスタムオートメーション 画面
 * 対象：トリガーイベント 家電シェアユーザー／位置条件の表示⇔非表示
 * アクション：draftAutomation.triggers[0].type を取得して表示を切り替える
 ******************************************/
const renderTriggerEventSection = () => {
  const triggerButtons = document.querySelectorAll(".js-trigger-event");
  if (!triggerButtons.length) return;

  // 現在のトリガー type 一覧を取得
  const triggerTypes = (draftAutomation?.triggers || []).map(
    (trigger) => trigger.type
  );

  triggerButtons.forEach((btn) => {
    const type = btn.dataset.appTriggerEvent;
    const isActive = triggerTypes.includes(type); // 現在のトリガーtype一覧に含まれるか

    // ボタンの状態制御
    btn.classList.toggle("active", isActive);
    btn.setAttribute("aria-pressed", String(isActive));
  });

  // 表示するトリガーセクションを決定
  // ※ 今は「最初の1つ」を表示対象にする
  const primaryTriggerType = triggerTypes[0];
  if (primaryTriggerType) {
    renderCustomAutomationTriggerEventBlockDisplay(primaryTriggerType);
  }
};

// 時間
const renderScheduleStartTime = () => {
  const startTimeEl = document.getElementById("autoStartTime");
  if (!startTimeEl) return;

  const scheduleTrigger = draftAutomation?.triggers.find(
    (trigger) => trigger.type === "schedule"
  );

  if (!scheduleTrigger?.startTime) {
    startTimeEl.textContent = "";
    startTimeEl.classList.add("fc-gray");
    return;
  }

  startTimeEl.textContent = scheduleTrigger.startTime;
  startTimeEl.classList.remove("fc-gray");
};

const renderCustomAutomationTriggerEventBlockDisplay = (triggerType) => {
  if (!triggerType) return;

  // triggerType → 表示するセクション（複数可）
  const sectionMap = {
    schedule: [
      "trigger-event-schedule",
      "trigger-event-common", // ← 共通表示
    ],
    product: [
      "trigger-event-product",
      "trigger-event-common", // ← 共通表示
    ],
    location: [
      "trigger-event-location",
    ],
  };

  const targetKeys = sectionMap[triggerType];
  if (!targetKeys) return;

  // 全セクション非表示
  document
    .querySelectorAll(".trigger-event-section")
    .forEach((el) => el.classList.add("d-none"));

  // 対象だけ表示
  targetKeys.forEach((key) => {
    document
      .querySelectorAll(`.trigger-event-section[data-app-key="${key}"]`)
      .forEach((el) => el.classList.remove("d-none"));
  });
};
// 曜日
const renderScheduleDays = () => {
  const dayButtons = document.querySelectorAll(".day-of-the-week");
  if (!dayButtons.length) return;

  const scheduleTrigger = draftAutomation?.triggers.find(
    (trigger) => trigger.type === "schedule"
  );

  const days = scheduleTrigger?.days ?? [];

  dayButtons.forEach((button) => {
    const day = button.dataset.appScheduleDay;
    const isActive = days.includes(day);

    button.classList.toggle("active", isActive);
    button.setAttribute("aria-pressed", String(isActive));
  });
};

// イニシャライズ（トリガーボタン）
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".js-trigger-event");
  if (!btn) return;

  const selectedType = btn.dataset.appTriggerEvent;
  if (!selectedType) return;

  // triggers を排他的に更新
  draftAutomation.triggers = [
    createTriggerByType(selectedType),
  ];

  // UI反映
  renderTriggerEvent();
  renderTriggerEventSection(); // schedule / location / product の表示切替
  renderScheduleDescription();
});

const createTriggerByType = (type) => {
  switch (type) {
    case "schedule":
      return {
        type: "schedule",
        days: [],
        time: null,
      };

    case "location":
      return {
        type: "location",
        area: null,
      };

    case "product":
      return {
        type: "product",
        deviceId: null,
        status: null,
      };

    default:
      return { type };
  }
};

const renderLocationCondition = () => {
  const buttons = document.querySelectorAll(".js-location-condition");
  if (!buttons.length) return;

  const locationTrigger = draftAutomation?.triggers.find(
    (t) => t.type === "location"
  );
  if (!locationTrigger) return;

  buttons.forEach((btn) => {
    const condition = btn.dataset.appLocationCondition;
    const isActive = locationTrigger.condition === condition;

    btn.classList.toggle("active", isActive);
    btn.setAttribute("aria-pressed", String(isActive));
  });
};

// トリガーイベントボタン イニシャライズ
const renderTriggerEvent = () => {
  const triggerButtons = document.querySelectorAll(".js-trigger-event");
  if (!triggerButtons.length) return;

  const triggerTypes = (draftAutomation?.triggers || []).map(
    (trigger) => trigger.type
  );

  triggerButtons.forEach((btn) => {
    const type = btn.dataset.appTriggerEvent;
    const isActive = triggerTypes.includes(type);

    btn.classList.toggle("active", isActive);
    btn.setAttribute("aria-pressed", String(isActive));
  });
};

// アクションボタン描画のエントリーポイント
const renderActions = () => {
  const actionList = document.getElementById("actionList");
  if (!actionList) return;

  actionList.innerHTML = ""; // 再描画前にクリア

  const actions = draftAutomation?.actions || [];
  if (!actions.length) return;

  actions.forEach((action, index) => {
    switch (action.type) {
      case "product":
        // ★ index を渡す
        actionList.appendChild(renderProductAction(action, index));
        break;

      case "notification":
        actionList.appendChild(renderNotificationAction(action, index));
        break;

      // case "scene":
      //   actionList.appendChild(renderSceneAction(action, index));
      //   break;

      default:
        console.warn("未対応のアクションタイプ:", action.type);
    }
  });
};

// productアイコン対応表
const ACTION_PRODUCT_ICONS = {
  rac: "../assets/img/icon_AC_40pt.svg",
  eq: "../assets/img/product_Icon_EQ_40pt.svg",
  bath: "../assets/img/icon-bath.svg",
};

// product アクション描画（1ボタン＝1アクション）
const renderProductAction = (action, actionIndex) => {
  const button = document.createElement("button");

  button.type = "button";
  button.className =
    "d-flex justify-content-between align-items-center gap-3 border rounded-3 px-3 py-1 w-100 bg-body";

  button.dataset.actionType = action.type;
  button.dataset.actionIndex = actionIndex;

  const iconSrc =
    ACTION_PRODUCT_ICONS[action.productId] ??
    "../assets/img/icon-default.svg"; // 保険

  const driveLabel = action.drive === "on" ? "運転開始" : "運転停止";

  const modeLabelMap = {
    heating: "暖房",
    cooling: "冷房",
    dehumidifying: "除湿",
    perflation: "送風",
  };

  const modeLabel = modeLabelMap[action.mode] ?? "";
  const tempLabel = action.temperature ? `${action.temperature}℃` : "";

  button.innerHTML = `
    <div class="d-flex align-items-center gap-3">
      <div>
        <img src="${iconSrc}" alt="">
      </div>
      <div class="text-start">
        <div class="lh-1 fs-15">${action.name}</div>
        <div class="fs-13 fc-gray">
          ${driveLabel}　${modeLabel}　${tempLabel}
        </div>
      </div>
    </div>
    <div>
      <img src="../assets/img/dust.svg" alt="">
    </div>
  `;

  return button;
};

// notification アクション描画（1ボタン＝1アクション）
const renderNotificationAction = (action, actionIndex) => {
  const button = document.createElement("button");

  button.type = "button";
  button.className =
    "d-flex justify-content-between align-items-center gap-3 border rounded-3 px-3 py-1 w-100 bg-body";

  button.dataset.actionType = action.type;
  button.dataset.actionIndex = actionIndex;

  const iconSrc =
    ACTION_PRODUCT_ICONS[action.productId] ??
    "../assets/img/icon_Notifications_40.svg"; // 保険

  // const driveLabel = action.drive === "on" ? "運転開始" : "運転停止";

  // const modeLabelMap = {
  //   heating: "暖房",
  //   cooling: "冷房",
  //   dehumidifying: "除湿",
  //   perflation: "送風",
  // };

  const name = action.name ? `${action.name}` : "";
  const message = action.message ? `${action.message}` : "";

  button.innerHTML = `
    <div class="d-flex align-items-center gap-3">
      <div>
        <img src="${iconSrc}" alt="">
      </div>
      <div class="text-start">
        <div class="lh-1 fs-15">${action.name}</div>
        <div class="fs-13 fc-gray">
          ${name}　${message}
        </div>
      </div>
    </div>
    <div>
      <img src="../assets/img/dust.svg" alt="">
    </div>
  `;

  return button;
};



// アクションボタンをクリック → product設定画面へ遷移
document.addEventListener("click", (e) => {
  const actionBtn = e.target.closest("[data-action-type]");
  if (!actionBtn) return;

  const actionType = actionBtn.dataset.actionType;   // "product" | "notification"
  const actionIndex = Number(actionBtn.dataset.actionIndex);
  const productId = actionBtn.dataset.product;      // "rac" | "eq" | "bath" など

  // 編集対象情報を保存（productだけでなく通知も保存する場合）
  sessionStorage.setItem(
    "automationActionDraft",
    JSON.stringify({
      type: actionType,
      index: actionIndex,
    })
  );

  let nextPage;

  if (actionType === "product") {
    // productごとの遷移先
    const PRODUCT_SETTINGS_PAGE = {
      rac: "../device-settings-rac/",
      eq: "../device-settings-eq/",
      // bath: "../device-settings-bath/", // 将来追加
    };
    nextPage = PRODUCT_SETTINGS_PAGE[productId];

    if (!nextPage) {
      console.warn("未対応の productId:", productId);
      return;
    }
  } else if (actionType === "notification") {
    // notificationは固定の遷移先
    nextPage = "../notice-settings/";
  } else {
    // それ以外のタイプは無視
    return;
  }

  // 遷移
  window.location.href = nextPage;
});


/******************************************
 * イニシャライズ：カスタムオートメーション 画面
 * 対象：シーンを追加／機器の操作を追加／通知を追加 ボタン
 * アクション：画面を遷移する
 ******************************************/
document.addEventListener("click", (e) => {
  const action = e.target.closest(".js-trigger-event")?.dataset?.appAction;
  const routes = {
    scene: "../select-scene/",
    operation: "../select-device/",
    notification: "../notice-settings/",
  };
  if (action && routes[action]) location.href = routes[action];
});



/******************************************
 * レンダリング：操作設定 画面
 * 対象：運転／停止、モード ボタン
 * アクション：JSONの値からボタンの初期状態を復元する
 ******************************************/
const renderDeviceSettingsButtons = (deviceId) => {
  if (!deviceId) return;

  const targetPath = `automation.items.${deviceId}.actions[0]`;

  // deviceId と 機器名表示先の対応
  const productMap = {
    "auto-1": "product-1",
    "auto-2": "product-2",
    "auto-3": "product-3",
  };

  const productElId = productMap[deviceId];
  if (!productElId) return;

  // 機器名
  document.getElementById(productElId).innerText = getJsonValue(
    `${targetPath}.name`,
  );

  // 運転 ON / OFF
  const drive = getJsonValue(`${targetPath}.drive`);
  document.getElementById("racDriveOnBtn").classList.toggle("active", !!drive);
  document.getElementById("racDriveOffBtn").classList.toggle("active", !drive);

  // モードボタン
  const mode = getJsonValue(`${targetPath}.mode`);
  if (mode) {
    document.querySelectorAll(".js-drive-mode").forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.appMode === mode);
    });
  }

  // 設定温度（auto-1 / auto-2 のみ存在）
  const temperature = getJsonValue(`${targetPath}.temperature`);
  if (temperature !== undefined) {
    document.getElementById("racSettingTemperature").innerText = temperature;
  }
};

const renderScheduleDescription = () => {
  const scheduleTrigger = draftAutomation?.triggers.find(
    (trigger) => trigger.type === "schedule"
  );
  if (!scheduleTrigger) return;

  const days = scheduleTrigger.days ?? [];
  updateScheduleDescription(days);
};

/******************************************
 * イニシャライズ：オートメーション編集／カスタムオートメーション 画面
 * 対象：曜日ボタン（繰り返し）
 * アクション：クリックするとJSONの値を更新する／説明文を表示する
 ******************************************/
document.addEventListener("click", (e) => {
  const targetButton = e.target.closest(".day-of-the-week");
  if (!targetButton) return;

  const selectedDay = targetButton.dataset.appScheduleDay;
  if (!selectedDay) return;

  const scheduleTrigger = draftAutomation?.triggers.find(
    (trigger) => trigger.type === "schedule"
  );
  if (!scheduleTrigger) return;

  // days が未定義なら初期化
  scheduleTrigger.days ??= [];

  const isSelected = scheduleTrigger.days.includes(selectedDay);

  if (isSelected) {
    // OFF
    scheduleTrigger.days = scheduleTrigger.days.filter(
      (day) => day !== selectedDay
    );
  } else {
    // ON
    scheduleTrigger.days.push(selectedDay);
  }

  // UI反映
  targetButton.classList.toggle("active", !isSelected);
  targetButton.setAttribute("aria-pressed", String(!isSelected));

  // 説明文更新
  updateScheduleDescription(scheduleTrigger.days);
});

/******************************************
 * ユーティリティ：スケジュール説明文の更新
 * 対象：曜日選択に応じた説明文
 * アクション：選択状態に応じて説明文を表示
 ******************************************/
const updateScheduleDescription = (days) => {
  const allDays = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
  const dayNames = {
    sun: "日",
    mon: "月",
    tue: "火",
    wed: "水",
    thu: "木",
    fri: "金",
    sat: "土",
  };

  let description = "";

  if (days.length === 0) {
    // 何も選択されていない：一度だけ実行
    description = "一度だけ実行します";
  } else if (days.length === 7) {
    // 全て選択：毎日実行
    description = "毎日実行します";
  } else {
    // 一部選択：選択された曜日に実行
    const selectedDayNames = days
      .sort((a, b) => allDays.indexOf(a) - allDays.indexOf(b))
      .map((day) => dayNames[day])
      .join("");
    description = `毎週${selectedDayNames}曜日に実行します`;
  }

  // 説明文を表示する要素を探して更新
  const descriptionElement = document.querySelector(
    '[data-app-key="trigger-event-schedule"] p.fs-14.fc-gray',
  );
  if (descriptionElement) {
    descriptionElement.textContent = description;
  }

  document.getElementById("scheduleText").innerText = description;
};


/******************************************
 * イニシャライズ：
 * 対象：操作設定画面
 * アクション：
 ******************************************/
// エントリーポイント
const initProductActionScreen = () => {
  // 編集対象アクション情報
  const actionDraft = JSON.parse(
    sessionStorage.getItem("automationActionDraft")
  );
  
  if (!actionDraft) return;

  const action = draftAutomation?.actions?.[actionDraft.index];
  if (!action || action.type !== "product") return;

  renderProductName(action);
  renderDriveState(action);
  renderDriveMode(action);
  renderTemperature(action);

};

const renderProductName = (action) => {
  const nameEl = document.getElementById("product-1");
  if (!nameEl) return;

  nameEl.textContent = action.name || "";
};

const renderDriveState = (action) => {
  const onBtn = document.getElementById("racDriveOnBtn");
  const offBtn = document.getElementById("racDriveOffBtn");
  if (!onBtn || !offBtn) return;

  const isOn = action.drive === "on";

  onBtn.classList.toggle("active", isOn);
  offBtn.classList.toggle("active", !isOn);

  onBtn.setAttribute("aria-pressed", String(isOn));
  offBtn.setAttribute("aria-pressed", String(!isOn));
};

const renderDriveMode = (action) => {
  const modeButtons = document.querySelectorAll(".js-drive-mode");
  if (!modeButtons.length) return;

  modeButtons.forEach((btn) => {
    const mode = btn.dataset.appMode;
    const isActive = action.mode === mode;

    btn.classList.toggle("active", isActive);
    btn.setAttribute("aria-pressed", String(isActive));
  });
};

const renderTemperature = (action) => {
  const tempEl = document.getElementById("racSettingTemperature");
  if (!tempEl) return;

  if (action.temperature) {
    tempEl.textContent = `${action.temperature}℃`;
    tempEl.classList.remove("fc-gray");
  } else {
    tempEl.textContent = "未設定";
    tempEl.classList.add("fc-gray");
  }
};

document.addEventListener("click", (e) => {
  const btn = e.target.closest("[data-app-is-drive]");
  if (!btn) return;

  const isDrive = btn.dataset.appIsDrive === "true";

  const actionDraft = JSON.parse(
    sessionStorage.getItem("automationActionDraft")
  );
  if (!actionDraft) return;

  const action = draftAutomation.actions[actionDraft.index];
  action.drive = isDrive ? "on" : "off";

  renderDriveState(action);
});

document.addEventListener("click", (e) => {
  const btn = e.target.closest(".js-drive-mode");
  if (!btn) return;

  const mode = btn.dataset.appMode;

  const actionDraft = JSON.parse(
    sessionStorage.getItem("automationActionDraft")
  );
  if (!actionDraft) return;

  const action = draftAutomation.actions[actionDraft.index];
  action.mode = mode;

  renderDriveMode(action);
});

/******************************************
 * イニシャライズ：
 * 対象：
 * アクション：
 ******************************************/
document.addEventListener("click", (e) => {});

/******************************************
 * イニシャライズ：
 * 対象：
 * アクション：
 ******************************************/
