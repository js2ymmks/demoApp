﻿/******************************************
 * テンプレートファイル読み込み
 ******************************************/
document.addEventListener("DOMContentLoaded", async () => {
  try {
    const [alert, header, footer, modal, drawer] = await Promise.all([
      fetch("../partials/alert.txt").then((r) => r.text()),
      fetch("../partials/header.txt").then((r) => r.text()),
      fetch("../partials/footer.txt").then((r) => r.text()),
      fetch("../partials/modal.txt").then((r) => r.text()),
      fetch("../partials/drawer-menu.txt").then((r) => r.text()),

      // 本番環境では下記を使用する
      // fetch("/home/mymu/demo/mymu/partials/alert.txt").then((r) => r.text()),
      // fetch("/home/mymu/demo/mymu/partials/header.txt").then((r) => r.text()),
      // fetch("/home/mymu/demo/mymu/partials/footer.txt").then((r) => r.text()),
      // fetch("/home/mymu/demo/mymu/partials/modal.txt").then((r) => r.text()),
      // fetch("/home/mymu/demo/mymu/partials/drawer-menu.txt").then((r) => r.text()),
    ]);

    document.querySelector(".content-alert").innerHTML = alert;
    document.querySelector(".content-header").innerHTML = header;
    document.querySelector(".content-footer").innerHTML = footer;
    document.querySelector(".content-modal").innerHTML = modal;
    document.querySelector(".content-drawer").innerHTML = drawer;
    initUI();
  } catch (err) {
    console.error("Failed to load partials:", err);
  }
});

/******************************************
 * ユーティリティ：JSON取得（ブラケット版）
 ******************************************/
const getJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("appDataEdit");
  let data;
  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }
  if (!data) return undefined;
  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");
  const props = normalizedPath.split(".");
  let current = data;
  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }
  return current;
};

/******************************************
 * ユーティリティ：JSON更新（ブラケット版）
 ******************************************/
const setJsonValue = (propertyPath, value) => {
  const storedJson = sessionStorage.getItem("appDataEdit");
  let data;
  try {
    data = storedJson ? JSON.parse(storedJson) : {};
  } catch (e) {
    data = {};
  }
  // ブラケット記法をドット記法に変換
  // "buttons[0].label" → "buttons.0.label"
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");
  const props = normalizedPath.split(".");
  let current = data;
  for (let i = 0; i < props.length - 1; i++) {
    const prop = props[i];
    // 数字 → 配列アクセス
    const index = Number(prop);
    const isIndex = !isNaN(index);
    if (isIndex) {
      if (!Array.isArray(current)) {
        current = [];
      }
      if (current[index] === undefined) {
        current[index] = {};
      }
      current = current[index];
    } else {
      if (!current[prop] || typeof current[prop] !== "object") {
        current[prop] = {};
      }
      current = current[prop];
    }
  }
  // 最終プロパティ
  const lastProp = props[props.length - 1];
  const lastIndex = Number(lastProp);
  if (!isNaN(lastIndex)) {
    if (!Array.isArray(current)) current = [];
    current[lastIndex] = value;
  } else {
    current[lastProp] = value;
  }
  sessionStorage.setItem("appDataEdit", JSON.stringify(data));
};

/******************************************
 * ユーティリティ：JSON取得（ブラケット版）ヘッダー用
 ******************************************/
const getHeaderJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("headerSet");
  let data;
  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }
  if (!data) return undefined;
  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");
  const props = normalizedPath.split(".");
  let current = data;
  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }
  return current;
};

/******************************************
 * ユーティリティ：JSONの変更検知
 ******************************************/
function isJsonChanged() {
  const entryId = getJsonValue("entryId");
  const originalStr = sessionStorage.getItem("appData");
  const editingStr = sessionStorage.getItem("appDataEdit");
  if (!originalStr || !editingStr) return false;
  const original = JSON.parse(originalStr);
  const editing = JSON.parse(editingStr);
  const originalData = original[entryId];
  const editingData = editing[entryId];
  const isChanged =
    JSON.stringify(originalData) !== JSON.stringify(editingData);
  return isChanged;
}
/******************************************
 * 完了ボタン制御
 ******************************************/
function updateCompleteButton() {
  const btn = document.querySelector(".js-complete-btn");
  if (!btn) return;

  const headerSetKey = document.body.dataset.appHeaderSet;
  const entryId = getJsonValue("entryId");

  // editAutomation かつ new 以外の場合
  if (headerSetKey === "editAutomation" && entryId !== "new") {
    const changed = isJsonChanged();
    if (changed) {
      // 変更があれば enabled に
      btn.disabled = false;
      btn.classList.add("active");
      btn.classList.remove("disabled");
      btn.setAttribute("aria-disabled", "false");
    } else {
      // 変更がなければ disabled に
      btn.disabled = true;
      btn.classList.remove("active");
      btn.classList.add("disabled");
      btn.setAttribute("aria-disabled", "true");
    }
    return;
  }

  const currentTriggerEvent = getJsonValue("currentTriggerEvent");
  // 値の存在と空でないことを両方チェック
  const actions = getJsonValue(`${entryId}.actions`);
  const hasActions = actions != null && actions.length > 0;
  const locationEvent = getJsonValue(`${entryId}.triggers.location.event`);
  const hasLocation = locationEvent != null && locationEvent.length > 0;
  const deviceCondition = getJsonValue(`${entryId}.triggers.devices.condition`);
  const hasDevices = deviceCondition != null && deviceCondition.length > 0;
  // new の場合（従来の処理）
  if (currentTriggerEvent === "schedule") {
    const changed = isJsonChanged() && hasActions;
    btn.disabled = !changed;
    btn.classList.toggle("active", changed);
    btn.setAttribute("aria-disabled", String(!changed));

  } else if (currentTriggerEvent === "location") {
    const changed = isJsonChanged() && hasActions && hasLocation;
    btn.disabled = !changed;
    btn.classList.toggle("active", changed);
    btn.setAttribute("aria-disabled", String(!changed));

  } else if (currentTriggerEvent === "devices") {
    const changed = isJsonChanged() && hasActions && hasDevices;
    btn.disabled = !changed;
    btn.classList.toggle("active", changed);
    btn.setAttribute("aria-disabled", String(!changed));
  }
}

/******************************************
 * ユーティリティ：ヘッダーのアイテムを設定する
 ******************************************/
function initHeader() {
  // ==============================
  // DOM取得
  // ==============================
  const headerDom = {
    leftBtn: document.getElementById("headerLeftBtn"),
    title: document.getElementById("headerTitle"),
    rightBtn: document.getElementById("headerRightBtn"),
  };

  if (!headerDom.leftBtn || !headerDom.title || !headerDom.rightBtn) {
    console.warn("header DOM がまだ準備できていません");
    return;
  }

  // ==============================
  // headerSetBodyKeyキー取得
  // ==============================
  const currentHeaderSetKey = document.body.dataset.appHeaderSet;
  if (!currentHeaderSetKey) {
    console.warn("data-app-header-set が指定されていません");
    return;
  }

  // ==============================
  // headerSetJson 取得
  // ==============================
  const headerSetJson = getHeaderJsonValue(`${currentHeaderSetKey}`);
  if (!headerSetJson) {
    console.warn(`headerSet.${currentHeaderSetKey} が見つかりません`);
    return;
  }

  // ==============================
  // タイトル
  // ==============================
  headerDom.title.innerHTML = headerSetJson.title;

  // ==============================
  // 左ボタン
  // ==============================
  renderLeftButton(headerSetJson.left?.type, headerDom.leftBtn);
  headerDom.leftBtn.onclick = () =>
    handleHeaderLeftAction(headerSetJson.left?.type);

  // ==============================
  // 右ボタン
  // ==============================
  renderRightButton(headerSetJson.right, headerDom.rightBtn);
  headerDom.rightBtn.onclick = () =>
    handleHeaderRightAction(headerSetJson.right?.action);
}

function initUI() {
  initFooterButtons();
  initFooterButtonsState();
  initHeader();
  bindScheduleTimeModal();
}

function bindScheduleTimeModal() {
  const modalEl = document.getElementById("scheduleTimeModal");
  if (!modalEl) return;
  if (modalEl.dataset.boundScheduleTimeModal === "1") return;
  modalEl.dataset.boundScheduleTimeModal = "1";

  modalEl.addEventListener("show.bs.modal", () => {
    const entryId = getJsonValue("entryId");
    renderScheduleTimeModal(entryId);
  });
}

// ==============================
// 左ボタン描画
// ==============================
// リセット
function renderLeftButton(type, btn) {
  btn.innerHTML = "";
  btn.classList.remove("d-none");
  // アイコン設定
  switch (type) {
    case "back":
      btn.innerHTML = '<i class="bi bi-chevron-left"></i>';
      break;
    case "drawer":
      btn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"><rect x="1" y="2" width="18" height="2.5" rx="1.25" fill="black"/><rect x="1" y="9" width="18" height="2.5" rx="1.25" fill="black"/><rect x="1" y="16" width="18" height="2.5" rx="1.25" fill="black"/></svg>';
      break;
    case "backToAutomation":
      btn.innerHTML = '<i class="bi bi-chevron-left"></i>';
      break;
    default:
      btn.classList.add("d-none");
  }
}

// ==============================
// 左アクション処理
// ==============================
function handleHeaderLeftAction(type) {
  switch (type) {
    case "back":
      if (
        document.body.dataset.appHeaderSet === "editAutomation" &&
        getJsonValue("entryId") !== "new"
      ) {
        setJsonValue("navigationMode", "back");
        window.location.href = "../automation/";
        return;
      }
      // document.addEventListener("DOMContentLoaded", syncToggleFromStorage);
      // window.addEventListener("pageshow", syncToggleFromStorage);
      sessionStorage.setItem("appDataReturnMode", "cancel");
      window.history.back();
      break;

    case "drawer":
      const bsOffcanvas = new bootstrap.Offcanvas("#appOffcanvas");
      bsOffcanvas.show();
      break;
    case "backToAutomation":
      setJsonValue("navigationMode", "back");
      window.location.href = "../automation/";
      break;
  }
}

// ==============================
// 右ボタン描画　headerTitle
// ==============================
function renderRightButton(headerSetJsonRight, headerDomRight) {
  // 右ボタンのプロパティチェック
  if (!headerSetJsonRight || !headerSetJsonRight.visible) {
    headerDomRight.classList.add("d-none");
    headerDomRight.onclick = null;
    return;
  }

  // 表示
  headerDomRight.classList.remove("d-none");
  // text / icon / svg すべて対応
  headerDomRight.innerHTML = headerSetJsonRight.text || "";
  if (headerSetJsonRight.action === "drawer") {
    headerDomRight.disabled = false;
    headerDomRight.classList.remove("disabled");
    headerDomRight.classList.remove("js-complete-btn");
    headerDomRight.setAttribute("aria-disabled", "false");
  }
  // bodyのdata属性チェック
  const headerSetKey = document.body.dataset.appHeaderSet;
  // 以下の場合は右ボタンを有効化する
  if (
    headerSetKey === "setupScene" ||
    headerSetKey === "selectRoomTemperatureStatusOver" ||
    headerSetKey === "selectRoomTemperatureStatusUnder" ||
    headerSetKey === "deviceSettingsRac" ||
    headerSetKey === "deviceSettingsEq" ||
    headerSetKey === "selectNotice" ||
    headerSetKey === "deviceSettingsEqScene" ||
    headerSetKey === "deviceSettingsRacScene"
    // headerSetKey === "editScene"
  ) {
    headerDomRight.disabled = false;
    headerDomRight.classList.add("active");
  } else if (headerSetKey === "editScene") {
    renderSceneEditScreen();
    syncSceneCompleteButtonState();
  }
  

  // 登録済みオートメーションは「編集」、新規オートメーションは「新規」
  const headerTitle = document.getElementById("headerTitle");
  if (headerSetKey === "editAutomation") {
    const entryId = getJsonValue("entryId");
    if (entryId === "new") {
      headerTitle.textContent = "新規オートメーション";
      headerDomRight.disabled = false;
      headerDomRight.classList.remove("disabled");
      headerDomRight.setAttribute("aria-disabled", "false");
    } else {
      headerDomRight.disabled = false;
      headerDomRight.classList.remove("active");
      headerDomRight.classList.add("disabled");
      headerDomRight.setAttribute("aria-disabled", "true");
    }
  }
  // クリック処理（あれば）
  headerDomRight.onclick = () => {
    handleHeaderRightAction(headerSetJsonRight.action, headerSetJsonRight);
  };
}

// ==============================
// 右アクション処理（完了/done | 設定/set | リンク/link | 編集/edit | 決定/ok）
// ==============================
function handleHeaderRightAction(action) {
  switch (action) {
    // メニュー表示
    case "drawer":
      const bsOffcanvas = new bootstrap.Offcanvas("#appOffcanvas");
      bsOffcanvas.show();
      break;

    // アラート表示
    case "alert":
      alert(
        "デモアプリではこのボタンは操作できません。＜ ボタンで戻ってください",
      );
      break;

    // MyMUボタン
    case "mymu":
      const headerEl = document.querySelector(".app-header");
      headerEl.addEventListener("click", (e) => {
        const btn = e.target.closest("#headerRightBtn");
        if (!btn) return;
        alert("デモアプリではこのボタンは操作できません。");
      });
      break;
    // シーン
    case "":
      break;
  }
}

/******************************************
 * イニシャライズ：フッター
 ******************************************/
const initFooterButtons = () => {
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const currentHeaderSetKey = document.body.dataset.appHeaderSet;
      if (
        currentHeaderSetKey === "editAutomation" &&
        btn.dataset.appPage === "automation"
      ) {
        setJsonValue("navigationMode", "back");
      }
      setJsonValue("currentPage", btn.dataset.appPage);
    });
  });
};

/******************************************
 * レンダリング：フッターアイコン表示更新
 ******************************************/
const initFooterButtonsState = () => {
  // フッターが存在しない画面
  const footerElement = document.getElementsByClassName("content-footer")[0];
  if (footerElement.className.includes("d-none")) {
    return;
  }
  // スタイルリセット
  const currentPage = getJsonValue("currentPage");
  const footerButtons = document.querySelectorAll(".footer-button");
  footerButtons.forEach((btn) => {
    btn.classList.remove("active");
  });
  // レンダリング
  footerButtons.forEach((btn) => {
    const page = btn.dataset.appPage;
    if (page === currentPage) {
      btn.classList.add("active");
    }
  });
};

/******************************************
 * マスターデータ
 ******************************************/
const MASTER_DEVICES = {
  "rac-1": {
    name: "エアコン1",
  },
  "rac-2": {
    name: "エアコン2",
  }
}

/******************************************
 * クリックイベント
 ******************************************/
document.addEventListener("click", (e) => {
  const el = e.target;

  // MyMU＋画面｜My家電レポートカード
  const appCardBtn = el.closest(".js-app-card");
  if (appCardBtn) {
    window.location.href = "../select-device/";
  }

  const updateButtonContainer = el.closest(`#UpdateButton`);
  if (updateButtonContainer) {
  }

  // MyMU＋画面｜ハウスクリーニング
  const banner = el.closest(`#banner`);
  if (banner) {
    window.open('https://kuratoku.lcx.mitsubishielectric.co.jp');
  }
  
});

/******************************************
 * ユーティリティbanner
 ******************************************/
function showAlert() {
  alert("デモアプリではこのボタンは操作できません。");
}

document.addEventListener("click", (e) => {
  const el = e.target;
  const showAlertBtn = el.closest(".js-show-alert");
  if (!showAlertBtn) return;
  alert("デモアプリではこのボタンは操作できません。");
});

/******************************************
 * レンダリング
 ******************************************/
// レポート画面｜メンテナンスした日を更新
function renderReportScreen() {
  const lastMonthElectricityBill = document.getElementById("lastMonthElectricityBill");
  const lastMonthOperatingHours = document.getElementById("lastMonthOperatingHours");
  const currentMonthElectricityBill = document.getElementById("currentMonthElectricityBill");
  const currentMonthOperatingHours = document.getElementById("currentMonthOperatingHours");
  console.log(lastMonthElectricityBill.textContent);
  console.log(lastMonthOperatingHours.textContent);
  console.log(currentMonthElectricityBill.textContent);
  console.log(currentMonthOperatingHours.textContent);
}


// 先月の電気代
/******************************************
 * id一覧
 * 先月の電気代： lastMonthElectricityBill
 * 先月の運転時間： lastMonthOperatingHours
 * 今月の電気代： currentMonthElectricityBill
 * 今月の運転時間： currentMonthOperatingHours
 ******************************************/
